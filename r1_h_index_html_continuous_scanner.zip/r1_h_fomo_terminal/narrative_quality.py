#!/usr/bin/env python3
"""Evidence-based narrative, organic-attention, and pre-hype scoring for R1_H.

All scores are transparent ranking signals, NOT probabilities of profit. Missing
social data is treated as missing evidence, never as a positive score.
"""
from __future__ import annotations

from datetime import datetime, timezone
import math
import re
from typing import Any

HYPE_ONLY = (
    "100x", "1000x", "guaranteed", "guaranteed profit", "easy money",
    "risk free", "risk-free", "send it", "moon now", "next 100x", "instant pump",
    "pump it", "can't lose", "cannot lose", "get rich", "buy now", "ape now",
)
PROOF_TERMS = (
    "live", "launch", "launched", "demo", "beta", "product", "app", "platform",
    "github", "open source", "open-source", "integration", "integrated", "partnership",
    "partner", "roadmap", "shipping", "shipped", "users", "developer", "build",
    "built", "release", "release notes", "whitepaper", "docs", "documentation",
    "on-chain", "onchain", "testnet", "mainnet", "mint", "claim",
)
THEMES = {
    "AI / Agents": (" ai ", "agent", "agents", "llm", "model inference", "autonomous"),
    "DePIN / Infrastructure": ("depin", "physical infrastructure", "compute network", "decentralized storage", "bandwidth"),
    "Gaming / Interactive": ("game", "gaming", "play-to-earn", "player", "gameplay", "arcade"),
    "Creator / IP / Culture": ("creator", "artist", "intellectual property", "character", "lore", "mascot", "culture", "community meme"),
    "DeFi / On-chain utility": ("defi", "staking", "liquidity", "lending", "swap", "payments", "yield", "protocol"),
    "RWA / Real world": ("rwa", "real world asset", "tokenized", "tokenization", "treasury", "commodity"),
    "Public catalyst": ("launch date", "launching", "airdrop", "exchange listing", "listing", "partnership", "integration", "announcement"),
    "Community / Meme": ("meme", "memecoin", "viral character", "community", "fan community", "internet culture"),
}
GENERIC_PHRASES = (
    "to the moon", "next doge", "next shib", "community driven", "community-owned",
    "the next big thing", "revolutionary project", "big things coming", "100x gem",
    "join our community", "we are early", "the future of crypto",
)


def _num(value: Any, default: float = 0.0) -> float:
    try:
        n = float(value)
        return n if math.isfinite(n) else default
    except (TypeError, ValueError):
        return default


def _ts(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        result = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if result.tzinfo is None:
            result = result.replace(tzinfo=timezone.utc)
        return result.astimezone(timezone.utc)
    except (TypeError, ValueError):
        return None


def _clean(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9$+#./ -]", " ", value.casefold())).strip()


def _is_match(post: dict[str, Any], mint: str, name: str, symbol: str) -> tuple[float, str]:
    text = str(post.get("text", ""))
    raw = text.casefold()
    mint_hit = bool(mint and mint.casefold() in raw)
    clean_name = _clean(name)
    name_words = clean_name.split()
    # Generic one-word names such as "Runner", "Gem", or "Mayhem" can create
    # false viral signals. Match these only by CA or explicit $cashtag; descriptive
    # names need either 2+ words or at least 8 characters when a single token.
    distinctive_name = len(name_words) >= 2 or len(clean_name) >= 8
    name_hit = bool(distinctive_name and len(clean_name) >= 6 and clean_name in _clean(text))
    clean_symbol = re.sub(r"[^a-z0-9]", "", symbol.casefold())
    cashtag_hit = bool(clean_symbol and re.search(rf"\${re.escape(clean_symbol)}\b", raw))
    # A bare ticker is never counted as community proof; it may be a normal word.
    if mint_hit:
        return 1.0, "exact_CA"
    if cashtag_hit:
        return 0.75, "cashtag_match"
    if name_hit:
        return 0.85, "name_match"
    if post.get("is_official_author"):
        # Official account posts are project context, not community traction.
        return 0.35, "official_account_post"
    return 0.0, "unmatched"


def _narrative_score(name: str, symbol: str, description: str, verified_status: str,
                     organic_score: Any, links: list[dict[str, Any]], sentiment: float) -> tuple[float, list[str], list[str]]:
    desc = (description or "").strip()
    text = f" {desc.casefold()} "
    words = re.findall(r"[a-z][a-z0-9-]{2,}", desc.casefold())
    unique_ratio = len(set(words)) / max(1, len(words))
    score = 18.0
    evidence: list[str] = []
    warnings: list[str] = []

    if len(desc) >= 220:
        score += 15
        evidence.append("detailed project description")
    elif len(desc) >= 100:
        score += 12
        evidence.append("substantive project description")
    elif len(desc) >= 45:
        score += 7
        evidence.append("some project context")
    else:
        score -= 12
        warnings.append("project narrative missing/very short")

    if len(set(words)) >= 18 and unique_ratio >= .48:
        score += 8
        evidence.append("specific vocabulary rather than repeated text")
    elif len(set(words)) < 7 and len(words) >= 10:
        score -= 8
        warnings.append("description has very low vocabulary diversity")

    padded = f" {_clean(desc)} "
    matched_themes = []
    for label, terms in THEMES.items():
        if any(term in padded for term in terms):
            matched_themes.append(label)
    if matched_themes:
        score += min(18, 7 + 4 * (len(matched_themes) - 1))
        evidence.append("narrative themes: " + ", ".join(matched_themes[:3]))
    else:
        score -= 4
        warnings.append("no clear narrative theme detectable in supplied description")

    matched_proof = [term for term in PROOF_TERMS if term in padded]
    if len(matched_proof) >= 3:
        score += 12
        evidence.append("concrete build/catalyst language detected")
    elif matched_proof:
        score += 5
        evidence.append("some build/catalyst language")

    generic_hits = sum(1 for phrase in GENERIC_PHRASES if phrase in padded)
    hype_hits = sum(1 for phrase in HYPE_ONLY if phrase in padded)
    if generic_hits:
        score -= min(16, generic_hits * 5)
        warnings.append("generic promotional copy detected")
    if hype_hits:
        score -= min(25, hype_hits * 9)
        warnings.append("profit/pump-style claims in copy")

    lower_status = (verified_status or "UNAVAILABLE").upper()
    if lower_status == "JUPITER_VERIFIED":
        score += 5
        evidence.append("Jupiter verified status (identity aid, not safety guarantee)")
    elif lower_status == "BANNED_OR_SUSPICIOUS":
        score -= 35
        warnings.append("provider marked token banned/suspicious")

    if organic_score is not None:
        org = _num(organic_score, 50)
        if org >= 75:
            score += 8
            evidence.append(f"Jupiter organic score {org:.0f}")
        elif org >= 60:
            score += 4
            evidence.append(f"Jupiter organic score {org:.0f}")
        elif org < 25:
            score -= 8
            warnings.append(f"low organic score ({org:.0f})")

    # Social-link count is weak, so it is deliberately capped at a small contribution.
    platform_types = {str(x.get("type", x.get("label", ""))).casefold() for x in links if isinstance(x, dict)}
    known_socials = sum(1 for p in platform_types if any(tag in p for tag in ("twitter", "x", "telegram", "discord", "reddit", "website")))
    if known_socials >= 2:
        score += 3
        evidence.append("multiple project links listed (not independently authenticated)")
    if sentiment >= .25:
        score += 2
    elif sentiment <= -.25:
        score -= 7
        warnings.append("available public-post sentiment is negative")

    return max(0.0, min(100.0, score)), evidence, warnings


def _social_metrics(posts: list[dict[str, Any]], mint: str, name: str, symbol: str) -> dict[str, Any]:
    matched: list[dict[str, Any]] = []
    for post in posts:
        if not isinstance(post, dict):
            continue
        strength, match_kind = _is_match(post, mint, name, symbol)
        post = dict(post)
        post["_match_strength"] = strength
        post["_match_kind"] = match_kind
        if strength >= 0.70:
            matched.append(post)

    now = datetime.now(timezone.utc)
    community = []
    for post in matched:
        source = str(post.get("source", "unknown")).casefold()
        official = bool(post.get("is_official_author"))
        author = str(post.get("username") or post.get("author") or "").strip().casefold()
        # A subreddit is a distribution source, not a unique human author.
        if not official:
            community.append((post, source, author))

    authors = {author for _, _, author in community if author}
    sources = {source for _, source, _ in community if source and source != "unknown"}
    engagement_total = 0.0
    view_total = 0.0
    views_known = False
    recency_weighted_posts = 0.0
    posts_last_hour = 0
    recent_last_15m = 0
    engagement_by_author: dict[str, float] = {}
    post_links: list[str] = []

    for post, source, author in community:
        likes = _num(post.get("likes"))
        reposts = _num(post.get("reposts"))
        replies = _num(post.get("replies"))
        quotes = _num(post.get("quotes"))
        reddit_score = _num(post.get("score"))
        comments = _num(post.get("comments"))
        views = post.get("views", post.get("impressions"))
        engagement = likes + 2.2 * reposts + 1.5 * replies + 2.0 * quotes + reddit_score + 1.5 * comments
        engagement_total += engagement
        if views is not None:
            views_known = True
            view_total += max(0.0, _num(views))
        ts = _ts(post.get("created_at"))
        if ts:
            age_hours = max(0.0, (now - ts).total_seconds() / 3600)
            recency_weighted_posts += math.exp(-age_hours / 4.0) * post["_match_strength"]
            if age_hours <= 1:
                posts_last_hour += 1
            if age_hours <= .25:
                recent_last_15m += 1
        if author:
            engagement_by_author[author] = engagement_by_author.get(author, 0.0) + engagement
        url = str(post.get("url", ""))
        if url.startswith("https://"):
            post_links.append(url)

    # Diversity and recency are weighted more than raw likes; raw numbers are easy to fake.
    n = len(community)
    concentration = (max(engagement_by_author.values()) / max(1.0, engagement_total)) if engagement_by_author and engagement_total > 0 else 0.0
    score = 0.0
    score += min(28.0, len(authors) * 7.0)
    score += min(16.0, n * 3.0)
    score += min(15.0, math.log10(1 + engagement_total) * 4.0)
    score += min(14.0, recency_weighted_posts * 5.0)
    score += min(12.0, (math.log10(1 + view_total) * 3.0) if views_known else 0.0)
    score += min(10.0, len(sources) * 5.0)
    score += min(10.0, posts_last_hour * 2.0 + recent_last_15m * 2.0)
    if concentration > .75 and n >= 3:
        score -= 12
    if len(authors) < 2 and n > 0:
        score -= 8
    score = max(0.0, min(100.0, score))

    return {
        "score": round(score, 1), "matched_posts": n, "matched_total_posts": len(matched),
        "unique_community_authors": len(authors), "independent_sources": len(sources),
        "engagement_total": int(engagement_total), "views_total": int(view_total) if views_known else None,
        "views_observed": views_known, "posts_last_hour": posts_last_hour,
        "posts_last_15m": recent_last_15m, "attention_concentration": round(concentration, 3),
        "sentiment": None, "sample_links": list(dict.fromkeys(post_links))[:4],
        "matches": [{"source": p.get("source", "unknown"), "match": p.get("_match_kind"),
                     "author": p.get("username") or p.get("author") or p.get("subreddit") or "unknown",
                     "engagement": round((_num(p.get("likes")) + 2.2*_num(p.get("reposts")) + 1.5*_num(p.get("replies")) + 2*_num(p.get("quotes")) + _num(p.get("score")) + 1.5*_num(p.get("comments"))), 1),
                     "views": p.get("views", p.get("impressions")), "url": p.get("url", "")}
                    for p, _, _ in community[:8]],
    }


def _pre_hype_score(m: Any, trend: dict[str, Any], cfg: dict[str, Any]) -> tuple[float, list[str]]:
    score = 50.0
    reasons: list[str] = []
    ch5 = _num(getattr(m, "change_5m", 0))
    ch1 = _num(getattr(m, "change_1h", 0))
    age = _num(getattr(m, "age_minutes", 999999))
    buy_share = _num(getattr(m, "buy_share_5m", 0.0))
    txns = _num(getattr(m, "txns_5m", _num(getattr(m, "buys_5m", 0)) + _num(getattr(m, "sells_5m", 0))))
    vol_mom = trend.get("volume_momentum_x")
    volat = trend.get("volatility_pct")
    liq_change = trend.get("liquidity_change_pct")

    min_age = _num(cfg.get("narrative_min_pool_age_minutes", 3), 3)
    if age < min_age:
        score -= 18
        reasons.append("pool too new for reliable pattern confirmation")
    elif age <= 45:
        score += 8
        reasons.append("early pool age")
    elif age <= 120:
        score += 4
    else:
        score -= 8
        reasons.append("pool may be past the preferred early window")

    max_ch5 = _num(cfg.get("narrative_max_5m_runup_pct", 4.5), 4.5)
    if 0 <= ch5 <= max_ch5:
        score += 9
        reasons.append("measured early 5m movement")
    elif max_ch5 < ch5 <= max_ch5 * 2:
        score -= 10
        reasons.append("entry timing worsening: 5m move already extended")
    elif ch5 > max_ch5 * 2:
        score -= 24
        reasons.append("late/chasing risk: sharp 5m pump")
    elif ch5 < -15:
        score -= 20
        reasons.append("strong negative 5m price move")

    max_ch1 = _num(cfg.get("narrative_max_1h_runup_pct", 12), 12)
    if -5 <= ch1 <= max_ch1:
        score += 5
    elif ch1 > max_ch1:
        score -= 20
        reasons.append("late/chasing risk: 1h run-up above early-entry limit")
    elif ch1 < -25:
        score -= 12
        reasons.append("negative 1h price structure")

    ch24 = _num(getattr(m, "change_24h", 0))
    max_ch24 = _num(cfg.get("narrative_max_24h_runup_pct", 35), 35)
    if ch24 > max_ch24:
        score -= 22
        reasons.append("late/chasing risk: 24h run-up already extended")
    elif ch24 > max_ch24 * 0.65:
        score -= 6
        reasons.append("24h run-up elevated; entry may be late")

    if vol_mom is not None:
        vm = _num(vol_mom, 0)
        if 1.2 <= vm <= 4.0:
            score += 12
            reasons.append("volume is accelerating without extreme expansion")
        elif vm > 8:
            score -= 10
            reasons.append("volume spike may be unstable/churn")
        elif vm < .75:
            score -= 5
            reasons.append("volume momentum fading")

    if .54 <= buy_share <= .78 and txns >= 8:
        score += 8
        reasons.append("broadening buyer participation")
    elif buy_share > .92 and txns >= 8:
        score -= 7
        reasons.append("buy flow unusually one-sided; possible fragile tape")
    elif buy_share < .48:
        score -= 8
        reasons.append("sell pressure dominates")

    if volat is not None and _num(volat) > 35:
        score -= 12
        reasons.append("high short-term volatility")
    if liq_change is not None and _num(liq_change) <= -20:
        score -= 30
        reasons.append("material liquidity decline")

    return max(0.0, min(100.0, score)), reasons


def analyze_narrative_potential(m: Any, enrichment: dict[str, Any], risk: dict[str, Any] | None,
                                trend: dict[str, Any] | None, cfg: dict[str, Any]) -> dict[str, Any]:
    trend = trend or {}
    description = str(enrichment.get("narrative") or "")
    links = enrichment.get("socials") or []
    sentiment = _num(enrichment.get("social_sentiment"))
    narrative_score, narrative_evidence, narrative_warnings = _narrative_score(
        str(getattr(m, "name", "")), str(getattr(m, "symbol", "")), description,
        str(enrichment.get("verified_status", "UNAVAILABLE")), enrichment.get("organic_score"), links, sentiment)
    social = _social_metrics(enrichment.get("posts") or [], str(getattr(m, "mint", "")),
                             str(getattr(m, "name", "")), str(getattr(m, "symbol", "")))
    social["sentiment"] = sentiment
    pre_hype, pre_hype_reasons = _pre_hype_score(m, trend, cfg)
    potential = round(.38 * narrative_score + .42 * social["score"] + .20 * pre_hype, 1)

    providers = enrichment.get("providers") or {}
    social_api_configured = any(
        str(providers.get(k, "")).casefold() == "configured"
        for k in ("X", "Reddit")
    )
    min_narrative = _num(cfg.get("narrative_min_quality_score", 58), 58)
    min_attention = _num(cfg.get("narrative_min_attention_score", 32), 32)
    min_posts = int(_num(cfg.get("narrative_min_matched_posts", 3), 3))
    min_authors = int(_num(cfg.get("narrative_min_unique_authors", 2), 2))
    min_sources = int(_num(cfg.get("narrative_min_independent_sources", 1), 1))
    min_pre_hype = _num(cfg.get("narrative_min_pre_hype_score", 42), 42)
    max_ch5 = _num(cfg.get("narrative_max_5m_runup_pct", 4.5), 4.5)
    max_ch1 = _num(cfg.get("narrative_max_1h_runup_pct", 12), 12)
    max_ch24 = _num(cfg.get("narrative_max_24h_runup_pct", 35), 35)
    risk_score = (risk or {}).get("score")
    risk_verdict = str((risk or {}).get("verdict", "UNKNOWN")).upper()
    mcap = _num(getattr(m, "market_cap", 0))
    cap_in_band = _num(cfg.get("min_market_cap_usd", 5000)) <= mcap <= _num(cfg.get("max_market_cap_usd", 150000))
    security_known = risk_score is not None and risk_verdict not in ("HIGH_RISK", "DANGER", "RUGGED")
    social_required = bool(cfg.get("require_social_proof_for_call", True))
    checks = [
        (narrative_score >= min_narrative, f"Narrative-Qualität {narrative_score:.0f}/100 unter {min_narrative:.0f}"),
        (social["score"] >= min_attention, f"organische Social-Aufmerksamkeit {social['score']:.0f}/100 unter {min_attention:.0f}"),
        (social["matched_posts"] >= min_posts, f"nur {social['matched_posts']} passende öffentliche Posts; benötigt {min_posts}"),
        (social["unique_community_authors"] >= min_authors, f"nur {social['unique_community_authors']} unabhängige Community-Autoren; benötigt {min_authors}"),
        (social["independent_sources"] >= min_sources, f"zu wenig unabhängige Social-Quellen"),
        (social["posts_last_hour"] >= int(_num(cfg.get("narrative_min_posts_last_hour", 1), 1)),
         "zu wenig frische passende Community-Posts in der letzten Stunde"),
        (social["posts_last_15m"] >= int(_num(cfg.get("narrative_min_posts_last_15m", 1), 1)),
         "keine frische passende Community-Erwähnung in den letzten 15 Minuten"),
        (social["attention_concentration"] <= _num(cfg.get("narrative_max_attention_concentration", 0.82), 0.82),
         "Aufmerksamkeit zu stark auf einzelne Autoren konzentriert"),
        (social_api_configured or not social_required, "X/Reddit-API nicht konfiguriert; echte öffentliche Resonanz nicht prüfbar"),
        (pre_hype >= min_pre_hype, f"Pre-Hype-Setup {pre_hype:.0f}/100 unter {min_pre_hype:.0f}"),
        (getattr(m, "age_minutes", 0) >= _num(cfg.get("narrative_min_pool_age_minutes", 3), 3), "Pool noch zu jung für belastbare Frühphasenbestätigung"),
        (_num(getattr(m, "change_5m", 0)) <= max_ch5, "5m-Anstieg zu stark: möglicher verspäteter Entry"),
        (_num(getattr(m, "change_1h", 0)) <= max_ch1, "1h-Anstieg bereits zu stark für den Pre-Hype-Filter"),
        (_num(getattr(m, "change_24h", 0)) <= max_ch24, "24h-Anstieg bereits zu stark; Anti-Chase-Gate"),
        (_num(getattr(m, "change_24h", 0)) >= -60, "24h-Absturz zu stark; Risiko für Dead-Cat-Bounce/Rug"),
        (cap_in_band, "Market Cap/FDV außerhalb des Frühphasen-Bands"),
        (security_known, "Sicherheitsdaten fehlen oder melden erhöhtes Risiko"),
    ]
    failed = [message for ok, message in checks if not ok]
    return {
        "narrative_score": round(narrative_score, 1),
        "social_attention_score": social["score"],
        "pre_hype_score": round(pre_hype, 1),
        "runner_potential_score": potential,
        "call_eligible": not failed if social_required else not [x for x in failed if not x.startswith("X/Reddit-API")],
        "social_api_configured": social_api_configured,
        "social_proof_required": social_required,
        "matched_posts": social["matched_posts"],
        "unique_community_authors": social["unique_community_authors"],
        "independent_sources": social["independent_sources"],
        "engagement_total": social["engagement_total"],
        "views_total": social["views_total"],
        "views_observed": social["views_observed"],
        "posts_last_hour": social["posts_last_hour"],
        "posts_last_15m": social["posts_last_15m"],
        "attention_concentration": social["attention_concentration"],
        "sample_social_links": social["sample_links"],
        "matched_post_details": social["matches"],
        "narrative_evidence": narrative_evidence[:8],
        "narrative_warnings": narrative_warnings[:8],
        "pre_hype_reasons": pre_hype_reasons[:8],
        "failed_gates": failed,
        "data_note": "Public social metrics are incomplete and manipulable; scores rank evidence, not returns.",
    }
