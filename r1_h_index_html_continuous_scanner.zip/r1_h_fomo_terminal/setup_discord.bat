@echo off
cd /d "%~dp0"
py setup_discord.py
if errorlevel 1 (
  echo Discord setup was not completed. Read the message above.
  pause
  exit /b 1
)
pause
