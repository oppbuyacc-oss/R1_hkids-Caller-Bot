@echo off
cd /d "%~dp0"
echo R1_H Runner Intel // starte Dauer-Scanner und index.html-Web-App...
start "" /b powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 3; Start-Process 'http://127.0.0.1:8765/index.html'"
py sharky_runner.py
if errorlevel 1 (
  echo R1_H Runner exited with an error.
  pause
)
