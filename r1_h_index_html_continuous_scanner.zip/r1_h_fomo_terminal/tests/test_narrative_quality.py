import unittest
from datetime import datetime, timezone

from narrative_quality import _is_match, _social_metrics


class NarrativeQualityTests(unittest.TestCase):
    def test_generic_single_word_name_is_not_viral_proof(self):
        post = {
            "source": "X", "username": "person1",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "text": "I like runners and going for a run, not a coin announcement.",
        }
        strength, kind = _is_match(post, "MintExact123", "Runner", "RUNNER")
        self.assertEqual(strength, 0.0)
        self.assertEqual(kind, "unmatched")

    def test_explicit_cashtag_matches(self):
        post = {"source": "X", "username": "person2",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "text": "Watching $RUNNER before the narrative catches on."}
        strength, kind = _is_match(post, "MintExact123", "Runner", "RUNNER")
        self.assertEqual(strength, 0.75)
        self.assertEqual(kind, "cashtag_match")

    def test_official_account_is_not_counted_as_community_attention(self):
        now = datetime.now(timezone.utc).isoformat()
        posts = [{"source": "X", "username": "projectofficial", "is_official_author": True,
                  "created_at": now, "text": "We are launching $RUNNER"},
                 {"source": "X", "username": "community1", "created_at": now,
                  "text": "I am tracking $RUNNER"}]
        result = _social_metrics(posts, "MintExact123", "Runner", "RUNNER")
        self.assertEqual(result["matched_posts"], 1)
        self.assertEqual(result["unique_community_authors"], 1)

    def test_views_are_not_invented_when_provider_omits_them(self):
        result = _social_metrics([], "MintExact123", "A Very Distinctive Coin", "AVDC")
        self.assertFalse(result["views_observed"])
        self.assertIsNone(result["views_total"])


if __name__ == "__main__":
    unittest.main()
