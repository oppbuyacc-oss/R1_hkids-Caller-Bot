import unittest
import time

from sharky_runner import PairMetrics, RunnerIntel


class PreliminaryGateTests(unittest.TestCase):
    def setUp(self):
        self.app = RunnerIntel.__new__(RunnerIntel)
        self.app.cfg = {
            "min_market_cap_usd": 5000,
            "max_market_cap_usd": 120000,
            "max_pair_age_minutes": 180,
            "narrative_min_pool_age_minutes": 3,
            "min_liquidity_usd": 6000,
            "min_volume_5m_usd": 700,
            "min_transactions_5m": 5,
            "min_buys_5m": 3,
            "min_buy_share_5m": 0.52,
            "narrative_max_5m_runup_pct": 12,
            "narrative_max_1h_runup_pct": 55,
        }

    def make_pair(self, **overrides):
        values = {
            "mint": "testmint", "name": "Test Project", "symbol": "TEST",
            "pair_address": "pair", "dex_url": "https://dexscreener.com/solana/test",
            "price_usd": 0.0001, "market_cap": 20000, "liquidity": 10000,
            "volume_5m": 2500, "buys_5m": 12, "sells_5m": 6,
            "change_5m": 4.0, "age_minutes": 12, "fdv": 25000,
            "source_pair": {}, "market_cap_is_fdv": False,
            "change_1h": 15, "change_24h": 22,
        }
        values.update(overrides)
        return PairMetrics(**values)

    def test_pair_metrics_counts_merged_links_without_name_error(self):
        app = RunnerIntel.__new__(RunnerIntel)
        app.latest_profiles = {
            "testmint": {
                "description": "A test project",
                "links": [
                    {"type": "website", "url": "https://example.org"},
                    {"type": "twitter", "url": "https://x.com/example"},
                ],
            }
        }
        pair = {
            "chainId": "solana",
            "pairAddress": "testpair",
            "url": "https://dexscreener.com/solana/testpair",
            "baseToken": {"address": "testmint", "name": "Test Project", "symbol": "TEST"},
            "pairCreatedAt": int((time.time() - 600) * 1000),
            "priceUsd": "0.0001",
            "marketCap": 20000,
            "fdv": 25000,
            "liquidity": {"usd": 10000},
            "volume": {"m5": 2500},
            "txns": {"m5": {"buys": 12, "sells": 6}},
            "priceChange": {"m5": 4, "h1": 15, "h24": 22},
            "info": {
                "websites": [{"url": "https://site.example"}],
                "socials": [{"url": "https://x.com/project"}],
            },
            "boosts": {"active": 0},
        }
        metrics = app.pair_metrics(pair)
        self.assertIsNotNone(metrics)
        self.assertEqual(metrics.website_count, 2)
        self.assertEqual(metrics.social_count, 2)

    def test_healthy_early_candidate_passes_preliminary_market_filter(self):
        self.assertEqual(self.app.preliminary_gate(self.make_pair())[0], True)

    def test_fdv_proxy_is_not_used_as_true_market_cap_for_strict_calls(self):
        ok, reason = self.app.preliminary_gate(self.make_pair(market_cap_is_fdv=True))
        self.assertFalse(ok)
        self.assertIn("FDV proxies", reason)

    def test_vertical_pump_is_filtered_before_social_api_spend(self):
        ok, reason = self.app.preliminary_gate(self.make_pair(change_5m=25))
        self.assertFalse(ok)
        self.assertIn("overextended", reason)

    def test_early_entry_24h_runup_is_filtered(self):
        self.app.cfg["narrative_max_24h_runup_pct"] = 35
        ok, reason = self.app.preliminary_gate(self.make_pair(change_24h=48))
        self.assertFalse(ok)
        self.assertIn("24h move", reason)

    def test_early_entry_config_blocks_1h_chasing(self):
        self.app.cfg["narrative_max_1h_runup_pct"] = 12
        ok, reason = self.app.preliminary_gate(self.make_pair(change_1h=18))
        self.assertFalse(ok)
        self.assertIn("1h move already overextended", reason)

    def test_crash_like_price_action_is_filtered(self):
        ok, reason = self.app.preliminary_gate(self.make_pair(change_1h=-62))
        self.assertFalse(ok)
        self.assertIn("sharp recent decline", reason)


if __name__ == "__main__":
    unittest.main()
