from __future__ import annotations

import json
import os
import shutil
import tempfile
import unittest
from unittest import mock
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.request import urlopen

from sharky_runner import RunnerIntel

from swarm_intelligence import AGENTS, FEATURE_KEYS, SharedLearner, SwarmEngine, build_features, analyze_roles, coordinate_agency


@dataclass
class FakeMetrics:
    mint: str = "FakeMint123456789"
    name: str = "Sample Meme"
    symbol: str = "SAMPLE"
    pair_address: str = "FakePair"
    dex_url: str = "https://dexscreener.com/solana/FakePair"
    price_usd: float = 0.000012
    market_cap: float = 12000.0
    liquidity: float = 13000.0
    volume_5m: float = 6000.0
    buys_5m: int = 35
    sells_5m: int = 12
    change_5m: float = 5.0
    age_minutes: float = 12.0
    fdv: float = 18000.0
    market_cap_is_fdv: bool = False
    change_1h: float = 11.0
    change_24h: float = 18.0
    website_count: int = 1
    social_count: int = 2
    boosts_active: int = 0
    source_pair: dict = None

    def __post_init__(self):
        if self.source_pair is None:
            self.source_pair = {
                "info": {
                    "description": "Community meme token for an illustrative test.",
                    "websites": [{"label": "Website", "url": "https://example.org"}],
                    "socials": [{"type": "telegram", "url": "https://t.me/example"}],
                }
            }

    @property
    def txns_5m(self):
        return self.buys_5m + self.sells_5m

    @property
    def buy_share_5m(self):
        return self.buys_5m / max(1, self.txns_5m)


def default_trend():
    return {"change_1m": 0.8, "change_5m": 3.2, "change_15m": 8.0,
            "volume_momentum_x": 1.8, "liquidity_change_pct": 0.5,
            "buy_share_delta_pp": 2.5, "volatility_pct": 3.0,
            "sparkline": "▁▂▄▅▆"}


class SwarmTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        shutil.copy(Path(__file__).resolve().parents[1] / "dashboard.html", self.root / "dashboard.html")
        self.cfg = {"dashboard_host": "127.0.0.1", "dashboard_port": 0, "learner_min_samples": 40,
                    "learner_retrain_every": 20, "forecast_min_score": 45,
                    "min_market_cap_usd": 5000, "max_external_calls_per_minute": 2,
                    "enrichment_cache_minutes": 60}
        self.engine = SwarmEngine(self.cfg, self.root)

    def tearDown(self):
        if self.engine.server:
            self.engine.server.shutdown()
            self.engine.server.server_close()
        self.engine.store.close()
        self.tmp.cleanup()

    def process_sample(self, mint="FakeMint123456789", base_score=73, stage="WATCH", risk=None):
        m = FakeMetrics(mint=mint)
        return self.engine.process(m, base_score, stage, risk or {"score": 8, "verdict": "LOWER_REPORTED_RISK",
            "details": {"totalHolders": 1300, "top10HoldersPct": 18, "lpLockedPct": 85}},
            default_trend(), None, ["synthetic test evidence"])

    def test_process_persists_room_notes_and_forecasts(self):
        self.process_sample()
        room = self.engine.store.room("FakeMint123456789")
        self.assertIsNotNone(room)
        self.assertEqual(room["symbol"], "SAMPLE")
        self.assertIn(room["signal_status"], {"CALL", "WATCH", "LOW_SIGNAL", "BLOCKED"})
        detail = self.engine.store.room_detail("FakeMint123456789")
        self.assertGreaterEqual(len(detail["notes"]), len(AGENTS))
        self.assertEqual({row["agent"] for row in detail["notes"]}, set(AGENTS))
        self.assertGreaterEqual(len(detail["forecasts"]), 3)
        self.assertEqual(room["verified_status"], "UNAVAILABLE")

    def test_features_and_roles_have_required_fields(self):
        m = FakeMetrics()
        enrich = {"verified_status": "JUPITER_VERIFIED", "organic_score": 73,
                  "socials": [{"url": "https://x.com/example"}], "posts": [],
                  "narrative": "Official but unverified issuer text", "social_sentiment": 0.1,
                  "social_summary": "test"}
        risk = {"score": 10, "verdict": "LOWER_REPORTED_RISK", "details": {"top10HoldersPct": 20}}
        features = build_features(m, risk, default_trend(), enrich)
        self.assertEqual(set(features), set(FEATURE_KEYS))
        agents = analyze_roles(m, 75, "WATCH", risk, default_trend(), enrich, features)
        self.assertEqual(set(agents), set(AGENTS))
        for agent in agents.values():
            self.assertGreaterEqual(agent["score"], 0)
            self.assertLessEqual(agent["score"], 100)
            self.assertGreater(agent["probability"], 0)
            self.assertIn("note", agent)

    def test_forecast_resolution_uses_peak_and_end_snapshots(self):
        mint = "ForecastMint"
        self.process_sample(mint=mint)
        with self.engine.store.lock, self.engine.store.conn:
            row = self.engine.store.conn.execute("SELECT * FROM forecasts WHERE mint=? AND horizon_minutes=15 LIMIT 1", (mint,)).fetchone()
            self.assertIsNotNone(row)
            now = datetime.now(timezone.utc)
            start = now - timedelta(minutes=40)
            due = start + timedelta(minutes=15)
            start_s = start.isoformat(timespec="seconds")
            due_s = due.isoformat(timespec="seconds")
            self.engine.store.conn.execute("UPDATE forecasts SET ts=?,due_at=?,initial_price=1.0,target_peak_return=.25,status='OPEN' WHERE id=?", (start_s,due_s,row["id"]))
            samples = [(start,1.0),(start+timedelta(minutes=5),1.25),(start+timedelta(minutes=10),2.0),(due,1.6)]
            for stamp,price in samples:
                self.engine.store.conn.execute("""INSERT INTO observations(mint,ts,price,market_cap,liquidity,volume_5m,buys,sells,base_score,swarm_score,stage,features_json)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", (mint,stamp.isoformat(timespec="seconds"),price,10000,5000,2000,10,3,70,70,"WATCH",json.dumps({k:0 for k in FEATURE_KEYS})))
        self.engine.resolve_due_forecasts(mint, now=due + timedelta(seconds=5))
        with self.engine.store.lock:
            result = self.engine.store.conn.execute("SELECT status,peak_return_pct,end_return_pct,label_hit FROM forecasts WHERE id=?", (row["id"],)).fetchone()
        self.assertEqual(result["status"], "RESOLVED")
        self.assertAlmostEqual(result["peak_return_pct"], 100.0, places=1)
        self.assertAlmostEqual(result["end_return_pct"], 60.0, places=1)
        self.assertEqual(result["label_hit"], 1)

    def test_missing_horizon_data_becomes_no_data_not_fabricated(self):
        mint = "NoDataMint"
        self.process_sample(mint=mint)
        with self.engine.store.lock, self.engine.store.conn:
            row = self.engine.store.conn.execute("SELECT * FROM forecasts WHERE mint=? AND horizon_minutes=15 LIMIT 1", (mint,)).fetchone()
            now = datetime.now(timezone.utc)
            start = now - timedelta(minutes=50)
            due = start + timedelta(minutes=15)
            self.engine.store.conn.execute("UPDATE forecasts SET ts=?,due_at=?,initial_price=1.0,status='OPEN' WHERE id=?",
                                           (start.isoformat(timespec="seconds"),due.isoformat(timespec="seconds"),row["id"]))
            self.engine.store.conn.execute("DELETE FROM observations WHERE mint=?", (mint,))
            # A pre-horizon observation alone is not enough to claim a future outcome.
            self.engine.store.conn.execute("""INSERT INTO observations(mint,ts,price,market_cap,liquidity,volume_5m,buys,sells,base_score,swarm_score,stage,features_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", (mint,(start+timedelta(minutes=3)).isoformat(timespec="seconds"),1.1,10000,5000,2000,10,3,70,70,"WATCH",json.dumps({k:0 for k in FEATURE_KEYS})))
        self.engine.resolve_due_forecasts(mint, now=due + timedelta(minutes=20))
        with self.engine.store.lock:
            result = self.engine.store.conn.execute("SELECT status,label_hit,peak_return_pct FROM forecasts WHERE id=?", (row["id"],)).fetchone()
        self.assertEqual(result["status"], "NO_DATA")
        self.assertIsNone(result["label_hit"])
        self.assertIsNone(result["peak_return_pct"])

    def test_base_call_is_downgraded_if_agency_does_not_approve(self):
        self.assertEqual(RunnerIntel._apply_agency_status("CALL", "WATCH"), "WATCH")
        self.assertEqual(RunnerIntel._apply_agency_status("CALL", None), "WATCH")
        self.assertEqual(RunnerIntel._apply_agency_status("CALL", "BLOCKED"), "BLOCK")
        self.assertEqual(RunnerIntel._apply_agency_status("CALL", "CALL"), "CALL")
        self.assertEqual(RunnerIntel._apply_agency_status("FILTERED", "CALL"), "FILTERED")

    def test_team_coordinator_blocks_high_risk_even_if_all_agents_are_positive(self):
        m = FakeMetrics()
        enrich = {"verified_status": "UNAVAILABLE", "organic_score": 70, "socials": [], "posts": [],
                  "social_sentiment": 0.0, "providers": {"dex": "available"}, "jupiter_audit": {}}
        trend = default_trend()
        risk = {"score": 62, "verdict": "HIGH_RISK", "details": {"top10HoldersPct": 20, "lpLockedPct": 80}}
        features = build_features(m, risk, trend, enrich)
        agents = analyze_roles(m, 95, "CALL", risk, trend, enrich, features)
        weights = {role: 1.0 for role in AGENTS}
        decision = coordinate_agency(agents, weights, m, 95, "CALL", risk, trend, enrich, {
            "max_rugcheck_score": 35, "agency_call_score": 80, "agency_min_consensus": 0.1,
            "agency_min_data_coverage": 0.1, "agency_min_safety_score": 1,
            "agency_min_onchain_score": 1, "agency_min_quality_score": 1,
            "min_market_cap_usd": 5000, "max_market_cap_usd": 150000,
            "min_liquidity_usd": 5000, "min_volume_5m_usd": 1500,
            "agency_min_transactions_5m": 1, "agency_min_buy_share_5m": 0.1,
            "max_pair_age_minutes": 90, "agency_max_rugcheck_score_for_call": 25,
        })
        self.assertEqual(decision["verdict"], "BLOCKED")
        self.assertTrue(decision["hard_block"])

    def test_strong_narrative_can_promote_watch_before_price_spike(self):
        m = FakeMetrics(change_5m=5.0, change_1h=11.0, market_cap_is_fdv=False)
        risk = {"score": 8, "verdict": "LOWER_REPORTED_RISK",
                "details": {"totalHolders": 1300, "top10HoldersPct": 18,
                            "topHolderPct": 4, "lpLockedPct": 85}}
        narrative = {"narrative_score": 82, "social_attention_score": 72,
                     "matched_posts": 8, "unique_community_authors": 6,
                     "independent_sources": 2, "social_api_configured": True,
                     "pre_hype_score": 70, "posts_last_hour": 5,
                     "posts_last_15m": 2, "attention_concentration": 0.22}
        enrich = {"verified_status": "JUPITER_VERIFIED", "narrative_analysis": narrative,
                  "providers": {"X": "configured"}, "jupiter_audit": {},
                  "organic_score": 75, "socials": [{"url": "https://x.com/project"}],
                  "posts": [{"text": "matched social evidence"}], "social_sentiment": .2}
        agents = {key: {"score": 90, "probability": .7, "note": "synthetic strong evidence",
                        "verdict": "POSITIVE"} for key in AGENTS}
        cfg = {
            "enable_narrative_first_calls": True, "narrative_first_min_base_score": 55,
            "narrative_first_min_quality_score": 68, "narrative_first_min_attention_score": 55,
            "narrative_first_min_matched_posts": 5, "narrative_first_min_unique_authors": 4,
            "narrative_first_min_pre_hype_score": 48, "require_social_proof_for_call": True,
            "narrative_min_quality_score": 65, "narrative_min_attention_score": 48,
            "narrative_min_matched_posts": 5, "narrative_min_unique_authors": 3,
            "narrative_min_independent_sources": 1, "narrative_min_pre_hype_score": 48,
            "narrative_max_5m_runup_pct": 12, "narrative_max_1h_runup_pct": 55,
            "agency_call_score": 82, "agency_positive_agent_score": 65,
            "agency_min_consensus": .62, "agency_min_data_coverage": .70,
            "agency_max_disagreement": 21, "agency_min_safety_score": 65,
            "agency_min_onchain_score": 58, "agency_min_quality_score": 65,
            "min_liquidity_usd": 6000, "min_volume_5m_usd": 700,
            "agency_min_transactions_5m": 6, "agency_min_buy_share_5m": .53,
            "agency_max_rugcheck_score_for_call": 25, "min_market_cap_usd": 5000,
            "max_market_cap_usd": 120000, "max_pair_age_minutes": 180,
            "agency_max_change_5m_pct": 12, "agency_max_liquidity_drop_for_call_pct": -15,
            "agency_max_top10_for_call_pct": 65, "agency_block_top10_pct": 80,
            "agency_block_liquidity_drop_pct": -30, "agency_min_lp_lock_for_call_pct": 10,
            "max_rugcheck_score": 30, "swarm_watch_score": 58,
            "agency_max_volatility_for_call_pct": 35, "agency_min_liquidity_to_mcap_ratio": 0.05,
        }
        test_trend = default_trend()
        result = coordinate_agency(agents, {key: 1.0 for key in AGENTS}, m, 66, "WATCH",
                                   risk, test_trend, enrich, cfg)
        self.assertEqual(result["verdict"], "CALL")
        self.assertEqual(result["entry_quality"], "NARRATIVE_FIRST_EARLY")

    def test_narrative_first_blocks_stale_or_concentrated_social_attention(self):
        m = FakeMetrics(change_5m=4.0, change_1h=9.0, market_cap_is_fdv=False)
        risk = {"score": 8, "verdict": "LOWER_REPORTED_RISK",
                "details": {"totalHolders": 1300, "top10HoldersPct": 18,
                            "topHolderPct": 4, "lpLockedPct": 85}}
        narrative = {"narrative_score": 88, "social_attention_score": 80,
                     "matched_posts": 9, "unique_community_authors": 7,
                     "independent_sources": 2, "social_api_configured": True,
                     "pre_hype_score": 72, "posts_last_hour": 1,
                     "posts_last_15m": 0, "attention_concentration": 0.91}
        enrich = {"verified_status": "JUPITER_VERIFIED", "narrative_analysis": narrative,
                  "providers": {"X": "configured"}, "jupiter_audit": {},
                  "organic_score": 76, "socials": [{"url": "https://x.com/project"}],
                  "posts": [{"text": "matched social evidence"}], "social_sentiment": .2}
        agents = {key: {"score": 90, "probability": .7, "note": "synthetic", "verdict": "POSITIVE"}
                  for key in AGENTS}
        cfg = {
            "enable_narrative_first_calls": True, "narrative_first_min_base_score": 55,
            "narrative_first_min_quality_score": 68, "narrative_first_min_attention_score": 55,
            "narrative_first_min_matched_posts": 5, "narrative_first_min_unique_authors": 4,
            "narrative_first_min_pre_hype_score": 48, "narrative_first_min_posts_last_hour": 2,
            "narrative_first_min_posts_last_15m": 1, "narrative_first_max_attention_concentration": .75,
            "require_social_proof_for_call": True, "narrative_min_quality_score": 65,
            "narrative_min_attention_score": 48, "narrative_min_matched_posts": 5,
            "narrative_min_unique_authors": 3, "narrative_min_independent_sources": 1,
            "narrative_min_pre_hype_score": 48, "narrative_min_posts_last_hour": 1,
            "narrative_max_attention_concentration": .82, "narrative_max_5m_runup_pct": 12,
            "narrative_max_1h_runup_pct": 55, "agency_call_score": 82,
            "agency_positive_agent_score": 65, "agency_min_consensus": .62,
            "agency_min_data_coverage": .70, "agency_max_disagreement": 21,
            "agency_min_safety_score": 65, "agency_min_onchain_score": 58,
            "agency_min_quality_score": 65, "min_liquidity_usd": 6000,
            "min_volume_5m_usd": 700, "agency_min_transactions_5m": 6,
            "agency_min_buy_share_5m": .53, "agency_max_rugcheck_score_for_call": 25,
            "min_market_cap_usd": 5000, "max_market_cap_usd": 120000,
            "max_pair_age_minutes": 180, "agency_max_change_5m_pct": 12,
            "agency_max_liquidity_drop_for_call_pct": -15, "agency_max_top10_for_call_pct": 65,
            "agency_block_top10_pct": 80, "agency_block_liquidity_drop_pct": -30,
            "agency_min_lp_lock_for_call_pct": 10, "max_rugcheck_score": 30,
            "swarm_watch_score": 58, "agency_max_volatility_for_call_pct": 35,
            "agency_min_liquidity_to_mcap_ratio": .05,
        }
        decision = coordinate_agency(agents, {key: 1.0 for key in AGENTS}, m, 66, "WATCH",
                                     risk, default_trend(), enrich, cfg)
        self.assertNotEqual(decision["verdict"], "CALL")
        joined = " ".join(decision["failed_gates"])
        self.assertTrue("letzten 15 Minuten" in joined or "Autoren" in joined or "konzentriert" in joined)

    def test_narrative_first_does_not_promote_without_real_social_proof(self):
        m = FakeMetrics()
        risk = {"score": 8, "verdict": "LOWER_REPORTED_RISK",
                "details": {"totalHolders": 1300, "top10HoldersPct": 18, "lpLockedPct": 85}}
        narrative = {"narrative_score": 90, "social_attention_score": 15,
                     "matched_posts": 0, "unique_community_authors": 0,
                     "independent_sources": 0, "social_api_configured": False,
                     "pre_hype_score": 70}
        enrich = {"verified_status": "JUPITER_VERIFIED", "narrative_analysis": narrative,
                  "providers": {}, "jupiter_audit": {}, "organic_score": 75,
                  "socials": [], "posts": [], "social_sentiment": 0}
        agents = {key: {"score": 90, "probability": .7, "note": "synthetic", "verdict": "POSITIVE"}
                  for key in AGENTS}
        cfg = {
            "enable_narrative_first_calls": True, "narrative_first_min_base_score": 55,
            "narrative_first_min_quality_score": 68, "narrative_first_min_attention_score": 55,
            "narrative_first_min_matched_posts": 5, "narrative_first_min_unique_authors": 4,
            "narrative_first_min_pre_hype_score": 48, "require_social_proof_for_call": True,
            "narrative_min_quality_score": 65, "narrative_min_attention_score": 48,
            "narrative_min_matched_posts": 5, "narrative_min_unique_authors": 3,
            "narrative_min_independent_sources": 1, "narrative_min_pre_hype_score": 48,
            "narrative_max_5m_runup_pct": 12, "narrative_max_1h_runup_pct": 55,
            "agency_call_score": 82, "agency_positive_agent_score": 65,
            "agency_min_consensus": .62, "agency_min_data_coverage": .70,
            "agency_max_disagreement": 21, "agency_min_safety_score": 65,
            "agency_min_onchain_score": 58, "agency_min_quality_score": 65,
            "min_liquidity_usd": 6000, "min_volume_5m_usd": 700,
            "agency_min_transactions_5m": 6, "agency_min_buy_share_5m": .53,
            "agency_max_rugcheck_score_for_call": 25, "min_market_cap_usd": 5000,
            "max_market_cap_usd": 120000, "max_pair_age_minutes": 180,
            "agency_max_change_5m_pct": 12, "agency_max_liquidity_drop_for_call_pct": -15,
            "agency_max_top10_for_call_pct": 65, "agency_block_top10_pct": 80,
            "agency_block_liquidity_drop_pct": -30, "agency_min_lp_lock_for_call_pct": 10,
            "max_rugcheck_score": 30, "swarm_watch_score": 58,
        }
        result = coordinate_agency(agents, {key: 1.0 for key in AGENTS}, m, 66, "WATCH",
                                   risk, default_trend(), enrich, cfg)
        self.assertNotEqual(result["verdict"], "CALL")
        self.assertTrue(any("Community-Autoren" in item or "Aufmerksamkeit" in item or "Posts" in item
                            for item in result["failed_gates"]))

    def test_watch_can_only_promote_when_coordinator_returns_call(self):
        self.assertEqual(RunnerIntel._apply_agency_status("WATCH", "CALL"), "CALL")
        self.assertEqual(RunnerIntel._apply_agency_status("WATCH", "WATCH"), "WATCH")
        self.assertEqual(RunnerIntel._apply_agency_status("FILTERED", "CALL"), "FILTERED")

    def test_coordinator_reports_dissent_and_data_coverage(self):
        m = FakeMetrics()
        enrich = {"verified_status": "JUPITER_VERIFIED", "organic_score": 70, "socials": [], "posts": [],
                  "social_sentiment": 0.0, "providers": {"dex": "available"}, "jupiter_audit": {}}
        risk = {"score": 8, "verdict": "LOWER_REPORTED_RISK", "details": {"top10HoldersPct": 18, "lpLockedPct": 85}}
        trend = default_trend()
        agents = analyze_roles(m, 80, "CALL", risk, trend, enrich, build_features(m, risk, trend, enrich))
        decision = coordinate_agency(agents, {role: 1.0 for role in AGENTS}, m, 80, "CALL", risk, trend, enrich,
                                     {"max_rugcheck_score": 35, "agency_call_score": 80, "agency_min_consensus": 0.1,
                                      "agency_min_data_coverage": 0.1, "agency_min_safety_score": 1,
                                      "agency_min_onchain_score": 1, "agency_min_quality_score": 1,
                                      "min_market_cap_usd": 5000, "max_market_cap_usd": 150000,
                                      "min_liquidity_usd": 5000, "min_volume_5m_usd": 1500,
                                      "agency_min_transactions_5m": 1, "agency_min_buy_share_5m": 0.1,
                                      "max_pair_age_minutes": 90, "agency_max_rugcheck_score_for_call": 25})
        self.assertGreaterEqual(decision["coverage"], 0.75)
        self.assertIn("consensus", decision)
        self.assertIn("disagreement", decision)
        self.assertTrue(decision["reasons"])

    def test_llm_agent_review_is_bounded_and_advisory(self):
        self.process_sample()
        agents = analyze_roles(FakeMetrics(), 70, "WATCH", {"score": 8, "verdict": "LOWER_REPORTED_RISK", "details": {}},
                               default_trend(), {"verified_status": "UNAVAILABLE", "socials": [], "posts": [], "narrative": "", "social_sentiment": 0},
                               build_features(FakeMetrics(), {"score": 8, "details": {}}, default_trend(), {"verified_status": "UNAVAILABLE", "socials": [], "posts": [], "social_sentiment": 0}))
        before = agents["MOMENTUM"]["score"]
        adjusted = self.engine._apply_llm_agent_review(agents, {"agent_reviews": {"MOMENTUM": {"score": 100, "note": "test opinion"}}})
        self.assertGreater(adjusted["MOMENTUM"]["score"], before)
        self.assertLessEqual(adjusted["MOMENTUM"]["score"], 100)

    def test_shared_learner_trains_after_minimum_labels(self):
        now = datetime.now(timezone.utc)
        with self.engine.store.lock, self.engine.store.conn:
            for i in range(40):
                ts = (now - timedelta(days=4) + timedelta(minutes=i)).isoformat(timespec="seconds")
                features = {key: (((i % 7) / 7) * 2 - 1) for key in FEATURE_KEYS}
                label = int(i % 2 == 0)
                self.engine.store.conn.execute("""INSERT INTO forecasts(mint,ts,horizon_minutes,target_peak_return,initial_price,
                    heuristic_probability,ml_probability,ensemble_probability,probability_type,agent_probabilities_json,
                    features_json,score_at_issue,status,due_at,resolved_at,peak_return_pct,end_return_pct,label_hit)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (f"Mint{i}",ts,60,.5,1,.5,None,.5,"HEURISTIC_NOT_CALIBRATED",json.dumps({a:.5 for a in AGENTS}),
                     json.dumps(features),60,"RESOLVED",ts,ts,60 if label else -20,-3,label))
        self.engine.learner.maybe_train()
        model = self.engine.store.model()
        self.assertIsNotNone(model)
        self.assertEqual(model["trained_n"], 40)
        p = self.engine.learner.predict({k:0.0 for k in FEATURE_KEYS})
        self.assertIsNotNone(p)
        self.assertGreater(p, 0)
        self.assertLess(p, 1)

    def test_helius_transfer_rows_are_recorded_as_per_mint_wallet_signals(self):
        # The current Helius transfer RPC returns one row per transfer (mint/blockTime),
        # unlike the legacy Enhanced Transactions schema with nested tokenTransfers.
        wallet = "11111111111111111111111111111111"
        mint = "FakeMint123456789"
        (self.root / "tracked_wallets.txt").write_text(wallet + ", test wallet\n", encoding="utf-8")
        stamp = int(datetime.now(timezone.utc).timestamp())
        self.engine.enrichment.wallet_transactions = lambda address, limit=25: [{
            "signature": "ExampleSignature1", "blockTime": stamp, "mint": mint,
            "fromUserAccount": "ExamplePoolAddress", "toUserAccount": address,
            "type": "SWAP", "uiAmount": 123.5,
        }]
        with mock.patch.dict(os.environ, {"HELIUS_API_KEY": "test-key"}):
            self.engine.refresh_wallet_activity()
        summary = self.engine.store.wallet_signal_summary(mint)
        self.assertEqual(summary["buys"], 1)
        self.assertEqual(summary["unique_wallets"], 1)
        self.assertEqual(summary["events"][0]["token_amount"], 123.5)

    def test_local_dashboard_api_starts_and_returns_json(self):
        self.process_sample()
        self.engine.start_dashboard()
        self.assertIsNotNone(self.engine.server)
        port = self.engine.server.server_address[1]
        with urlopen(f"http://127.0.0.1:{port}/api/summary", timeout=3) as resp:
            payload = json.loads(resp.read().decode())
        self.assertIn("stats", payload)
        self.assertIn("model", payload)
        with urlopen(f"http://127.0.0.1:{port}/", timeout=3) as resp:
            html = resp.read().decode()
        self.assertIn("R1_H", html)


if __name__ == "__main__":
    unittest.main()
