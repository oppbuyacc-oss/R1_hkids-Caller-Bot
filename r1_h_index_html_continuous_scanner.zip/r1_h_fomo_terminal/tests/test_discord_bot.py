import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from discord_bot import DiscordBot, parse_call_text


SAMPLE = """🚨 R1_H RUNNER SIGNAL — XYZ (Example Coin)
Score: 84/100 · status: research signal, NOT a prediction
CA: So11111111111111111111111111111111111111112
MARKET CAP: $35.0K · FDV: $42.0K · Price: $0.00012
Liquidity: $10K · Volume 5m: $2K · Vol/Liq: 0.20x
5m tx: 40 (buys 27/sells 13) · buy share 68%
Price change: 5m +12.0% · 1h +31.0% · 24h +8.0%
Local trend 1m/5m/15m: +2%/+8%/+15% · chart ▂▄▆█
Pool age: 12.0 min · Website/Social links: 1/2 · DEX boosts: 0
RugCheck: 18/100 (lower reported risk is better) · top holders: 30 · LP locked: 80
Evidence: rising volume; higher buy share
AI qualitative review: CONSIDER (70/100 reviewer confidence, not a profit probability)
AI: Rising flow but still highly speculative.
AI risk: price may reverse fast
DEX chart: https://dexscreener.com/solana/example
Pump.fun: https://pump.fun/coin/example
"""


class DiscordBotTests(unittest.TestCase):
    def test_parse_fields_and_urls(self):
        parsed = parse_call_text(SAMPLE)
        self.assertEqual(parsed["title"], "XYZ (Example Coin)")
        self.assertEqual(parsed["ca"], "So11111111111111111111111111111111111111112")
        self.assertEqual(parsed["market_value"], "$35.0K")
        self.assertEqual(parsed["fdv"], "$42.0K")
        self.assertEqual(parsed["price"], "$0.00012")
        self.assertTrue(parsed["chart_url"].startswith("https://"))
        self.assertEqual(len(parsed["ai_risks"]), 1)

    def test_invalid_links_are_not_exposed_as_buttons(self):
        parsed = parse_call_text(SAMPLE.replace("https://pump.fun/coin/example", "javascript:alert(1)"))
        self.assertEqual(parsed["pump_url"], "")

    def test_auto_discovers_coin_calls_channel_without_setchannel(self):
        class Channel:
            def __init__(self, channel_id, name):
                self.id = channel_id
                self.name = name

            def permissions_for(self, member):
                return SimpleNamespace(view_channel=True, send_messages=True, embed_links=True)

        guild = SimpleNamespace(
            id=123456789012345678,
            name="R1_H Caller Hub",
            me=object(),
            text_channels=[Channel(234567890123456789, "general"), Channel(345678901234567890, "coin-calls")],
        )
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"DISCORD_BOT_TOKEN": "", "DISCORD_GUILD_ID": "", "DISCORD_CHANNEL_ID": ""}, clear=False):
                bot = DiscordBot(Path(directory))
                bot.client = SimpleNamespace(guilds=[guild])
                bot._autodiscover_call_channels()
                self.assertEqual(bot.channels[str(guild.id)], "345678901234567890")
                stored = json.loads((Path(directory) / "discord_state.json").read_text(encoding="utf-8"))
                self.assertEqual(stored["channels"][str(guild.id)], "345678901234567890")

    def test_does_not_override_existing_channel_selection(self):
        class Channel:
            def __init__(self, channel_id, name):
                self.id = channel_id
                self.name = name

        guild = SimpleNamespace(
            id=123456789012345678,
            name="R1_H Caller Hub",
            me=object(),
            text_channels=[Channel(345678901234567890, "coin-calls")],
        )
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"DISCORD_BOT_TOKEN": "", "DISCORD_GUILD_ID": "", "DISCORD_CHANNEL_ID": ""}, clear=False):
                bot = DiscordBot(Path(directory))
                bot.channels[str(guild.id)] = "456789012345678901"
                bot.client = SimpleNamespace(guilds=[guild])
                bot._autodiscover_call_channels()
                self.assertEqual(bot.channels[str(guild.id)], "456789012345678901")

    def test_state_persistence(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"DISCORD_BOT_TOKEN": "", "DISCORD_GUILD_ID": "", "DISCORD_CHANNEL_ID": ""}, clear=False):
                bot = DiscordBot(Path(directory))
                bot.channels["123456789012345678"] = "234567890123456789"
                bot.muted_guilds.add("123456789012345678")
                bot.send_alert(SAMPLE)
                stored = json.loads((Path(directory) / "discord_state.json").read_text(encoding="utf-8"))
                self.assertEqual(stored["channels"]["123456789012345678"], "234567890123456789")
                self.assertEqual(stored["muted_guilds"], ["123456789012345678"])
                self.assertEqual(stored["latest_alerts"][-1]["text"], SAMPLE[:12000])


if __name__ == "__main__":
    unittest.main()
