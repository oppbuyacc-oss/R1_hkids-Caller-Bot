from pathlib import Path
import json
import os
import tempfile
import unittest
import requests
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]

class IOSPwaPushTests(unittest.TestCase):
    def test_pwa_manifest_and_assets_exist(self):
        manifest = json.loads((ROOT / "manifest.webmanifest").read_text(encoding="utf-8"))
        self.assertEqual(manifest["display"], "standalone")
        self.assertTrue((ROOT / "sw.js").exists())
        for name in ("icon-192.png", "icon-512.png", "apple-touch-icon.png"):
            self.assertTrue((ROOT / "icons" / name).exists())

    def test_index_html_is_canonical_dashboard_and_exposes_push(self):
        html = (ROOT / "index.html").read_text(encoding="utf-8")
        self.assertEqual(html, (ROOT / "dashboard.html").read_text(encoding="utf-8"))
        self.assertIn('id="push-toggle"', html)
        self.assertIn('id="push-test"', html)
        self.assertIn("/api/push/subscribe", html)
        self.assertIn("/api/auth/login", html)
        self.assertIn("navigator.standalone", html)

    def test_new_pair_sources_and_fast_poll_are_configured(self):
        config = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
        scanner = (ROOT / "sharky_runner.py").read_text(encoding="utf-8")
        self.assertEqual(config["poll_seconds"], 15)
        self.assertTrue(config["enable_pumpportal_stream"])
        self.assertIn("/token-profiles/latest/v1", scanner)
        self.assertIn("/networks/solana/new_pools", scanner)
        self.assertIn("subscribeNewToken", scanner)

    def test_scanner_pushes_only_after_unique_call(self):
        source = (ROOT / "sharky_runner.py").read_text(encoding="utf-8")
        self.assertIn("self.swarm.notify_call(m.mint, m.name, m.symbol, m.market_cap, score)", source)
        self.assertIn('if stage == "CALL" and not self.store.has_alerted(m.mint):', source)

    def test_http_serves_pwa_and_protects_api(self):
        from swarm_intelligence import SwarmEngine
        with tempfile.TemporaryDirectory() as td, patch.dict(os.environ, {
            "R1H_APP_PASSWORD": "this-is-a-test-password",
            "R1H_SESSION_SECRET": "test-session-secret",
            "R1H_DATA_DIR": td,
            "R1H_PUBLIC_HOSTING": "",
        }, clear=False):
            engine = SwarmEngine({"dashboard_host": "127.0.0.1", "dashboard_port": 0,
                                  "learner_min_samples": 60, "learner_retrain_every": 20}, ROOT)
            engine.start_dashboard()
            port = engine.server.server_address[1]
            base = f"http://127.0.0.1:{port}"
            try:
                root_response = requests.get(base + "/", timeout=3)
                self.assertEqual(root_response.status_code, 200)
                self.assertEqual(root_response.content, (ROOT / "index.html").read_bytes())
                index_response = requests.get(base + "/index.html", timeout=3)
                self.assertEqual(index_response.status_code, 200)
                self.assertEqual(index_response.content, (ROOT / "index.html").read_bytes())
                self.assertEqual(requests.get(base + "/manifest.webmanifest", timeout=3).status_code, 200)
                sw = requests.get(base + "/sw.js", timeout=3)
                self.assertEqual(sw.status_code, 200)
                self.assertIn("showNotification", sw.text)
                self.assertEqual(requests.get(base + "/api/summary", timeout=3).status_code, 401)
                session = requests.Session()
                login = session.post(base + "/api/auth/login", json={"password": "this-is-a-test-password"}, timeout=3)
                self.assertEqual(login.status_code, 200)
                self.assertEqual(session.get(base + "/api/push/public-key", timeout=3).status_code, 200)
            finally:
                engine.server.shutdown()
                engine.server.server_close()
                engine.store.conn.close()

    def test_authenticated_session_cookie(self):
        # Import uses paths from the project, but the isolated state dir is temporary.
        from swarm_intelligence import SwarmEngine
        with tempfile.TemporaryDirectory() as td, patch.dict(os.environ, {"R1H_APP_PASSWORD": "this-is-a-test-password", "R1H_SESSION_SECRET": "test-session-secret", "R1H_DATA_DIR": td}, clear=False):
            engine = SwarmEngine({"learner_min_samples": 60, "learner_retrain_every": 20}, ROOT)
            cookie = engine.make_session_cookie()
            self.assertTrue(engine.valid_session_cookie(cookie))
            self.assertFalse(engine.valid_session_cookie(cookie + "tampered"))
            self.assertFalse(engine.api_is_authorized("", "203.0.113.4"))
            self.assertTrue(engine.api_is_authorized(f"other=x; r1h_session={cookie}", "203.0.113.4"))
            engine.store.conn.close()

if __name__ == "__main__":
    unittest.main()
