from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class SoundAndWebsiteTests(unittest.TestCase):
    def test_scanner_has_local_call_sound(self):
        source = (ROOT / "sharky_runner.py").read_text(encoding="utf-8")
        self.assertIn("def play_call_sound(self)", source)
        self.assertIn("CALL-Soundalarm ausgelöst", source)
        self.assertIn("winsound.Beep", source)

    def test_dashboard_has_sound_toggle_and_call_detection(self):
        html = (ROOT / "dashboard.html").read_text(encoding="utf-8")
        self.assertIn('id="sound-toggle"', html)
        self.assertIn('id="sound-test"', html)
        self.assertIn("announceNewCall(room)", html)
        self.assertIn("seenCallMints", html)
        self.assertIn("/api/rooms?limit=500", html)

    def test_start_opens_local_dashboard(self):
        bat = (ROOT / "start.bat").read_text(encoding="utf-8")
        self.assertIn("127.0.0.1:8765", bat)

if __name__ == "__main__":
    unittest.main()
