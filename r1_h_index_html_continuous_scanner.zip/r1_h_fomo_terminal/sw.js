/* R1_H Runner PWA Service Worker — only API data remains network-first */
'use strict';
const CACHE_NAME = 'r1h-shell-v2';
const SHELL = ['/', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/apple-touch-icon.png'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return;
  if (event.request.method !== 'GET') return;
  if (url.pathname === '/' || url.pathname.startsWith('/icons/') || url.pathname === '/manifest.webmanifest') {
    event.respondWith(fetch(event.request).then(response => {
      if (response && response.ok) { const clone = response.clone(); caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone)); }
      return response;
    }).catch(() => caches.match(event.request).then(response => response || caches.match('/'))));
  }
});
self.addEventListener('push', event => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; } catch (_) { payload = { title: 'R1_H Runner CALL', body: event.data ? event.data.text() : 'Neuer CALL' }; }
  const title = String(payload.title || 'R1_H Runner CALL').slice(0, 120);
  const options = {
    body: String(payload.body || 'Ein neuer Coin hat alle CALL-Gates bestanden.').slice(0, 300),
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    tag: String(payload.tag || 'r1h-new-call').slice(0, 180),
    renotify: true,
    data: { url: payload.url || '/', ...(payload.data || {}) }
  };
  // Safari/iOS requires a user-visible notification for each push event.
  event.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const raw = event.notification.data && event.notification.data.url ? event.notification.data.url : '/';
  const target = new URL(raw, self.registration.scope).href;
  event.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
    for (const client of list) {
      if (client.url.startsWith(self.registration.scope) && 'focus' in client) {
        if ('navigate' in client && client.url !== target) client.navigate(target);
        return client.focus();
      }
    }
    return clients.openWindow(target);
  }));
});
