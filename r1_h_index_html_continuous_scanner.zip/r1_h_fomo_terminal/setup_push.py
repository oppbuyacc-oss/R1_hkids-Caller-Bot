#!/usr/bin/env python3
"""Create VAPID keys and safe app credentials for R1_H iPhone Web Push."""
from __future__ import annotations

import base64
import getpass
import os
import re
import secrets
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENV_PATH = ROOT / ".env"
PRIVATE_PATH = ROOT / "vapid_private.pem"


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if path.exists():
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def write_env(path: Path, updates: dict[str, str]) -> None:
    original = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    remaining = dict(updates)
    output: list[str] = []
    for line in original:
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
            if key in remaining:
                output.append(f"{key}={remaining.pop(key)}")
                continue
        output.append(line)
    if output and output[-1].strip():
        output.append("")
    if remaining:
        output.append("# R1_H iPhone Web Push / public HTTPS deployment")
        output.extend(f"{k}={v}" for k, v in remaining.items())
    path.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass


def public_key_b64(private_key) -> str:
    from cryptography.hazmat.primitives import serialization
    raw = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.UncompressedPoint,
    )
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def main() -> int:
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ec
    except ImportError:
        print("Fehler: cryptography fehlt. Fuehre zuerst install.bat (Windows) bzw. pip install -r requirements.txt in einem venv aus.")
        return 1

    values = read_env(ENV_PATH)
    existing_domain = values.get("SITE_DOMAIN", "")
    domain = input(f"Domain ohne https:// [{existing_domain or 'app.deinedomain.de'}]: ").strip() or existing_domain
    if not domain or "://" in domain or "/" in domain or " " in domain:
        print("Bitte nur den Hostnamen eintragen, z. B. r1h.example.de (ohne https:// und ohne Pfad).")
        return 2
    domain = domain.lower().strip().rstrip(".")

    existing_password = values.get("R1H_APP_PASSWORD", "")
    if existing_password:
        keep = input("Ein Dashboard-Passwort ist bereits gesetzt. Beibehalten? [J/n]: ").strip().lower()
        if keep in {"n", "nein", "no"}:
            password = getpass.getpass("Neues Dashboard-Passwort (mind. 14 Zeichen): ")
            if len(password) < 14:
                print("Das Passwort muss mindestens 14 Zeichen haben.")
                return 2
            confirm = getpass.getpass("Passwort wiederholen: ")
            if password != confirm:
                print("Passwörter stimmen nicht überein.")
                return 2
        else:
            password = existing_password
    else:
        password = getpass.getpass("Dashboard-Passwort festlegen (mind. 14 Zeichen): ")
        if len(password) < 14:
            print("Das Passwort muss mindestens 14 Zeichen haben.")
            return 2
        confirm = getpass.getpass("Passwort wiederholen: ")
        if password != confirm:
            print("Passwörter stimmen nicht überein.")
            return 2

    contact_existing = values.get("PUSH_CONTACT", "")
    contact = input(f"Kontakt-E-Mail fuer Push/VAPID [{contact_existing or 'deine-email@example.com'}]: ").strip() or contact_existing
    if not contact:
        print("Bitte eine Kontakt-E-Mail eingeben.")
        return 2
    if contact.startswith("mailto:"):
        contact_value = contact
    else:
        contact_value = "mailto:" + contact

    try:
        if PRIVATE_PATH.exists():
            private_key = serialization.load_pem_private_key(PRIVATE_PATH.read_bytes(), password=None)
            print("Vorhandenen VAPID-Schluessel beibehalten.")
        else:
            private_key = ec.generate_private_key(ec.SECP256R1())
            pem = private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            )
            PRIVATE_PATH.write_bytes(pem)
            try:
                PRIVATE_PATH.chmod(0o600)
            except OSError:
                pass
        vapid_public = public_key_b64(private_key)
    except Exception as exc:
        print(f"VAPID-Schluessel konnte nicht geladen/erstellt werden: {type(exc).__name__}: {exc}")
        return 1

    updates = {
        "SITE_DOMAIN": domain,
        "R1H_APP_PASSWORD": password,
        "R1H_SESSION_SECRET": values.get("R1H_SESSION_SECRET") or secrets.token_urlsafe(48),
        "PUSH_VAPID_PUBLIC_KEY": vapid_public,
        "PUSH_VAPID_PRIVATE_KEY_PATH": "vapid_private.pem",
        "PUSH_CONTACT": contact_value,
    }
    if not ENV_PATH.exists() and (ROOT / ".env.example").exists():
        shutil.copyfile(ROOT / ".env.example", ENV_PATH)
    write_env(ENV_PATH, updates)

    print("\nWeb-Push eingerichtet. Geheimnisse wurden nicht ausgegeben.")
    print(f"Dashboard-Adresse nach dem Deployment: https://{domain}")
    print("WICHTIG: DNS-A/AAAA muss auf den Server zeigen und Ports 80/443 muessen offen sein.")
    print("Bewahre .env und vapid_private.pem geheim auf; lade sie niemals in ein oeffentliches Repository hoch.")
    print("Naechster Schritt auf einem Ubuntu-VPS: docker compose up -d --build")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
