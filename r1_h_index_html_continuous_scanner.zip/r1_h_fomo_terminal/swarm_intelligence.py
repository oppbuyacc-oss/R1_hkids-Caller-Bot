#!/usr/bin/env python3
"""R1_H Swarm Intelligence: persistent per-token rooms, specialist roles and outcome learning.

This is an original implementation. Local role agents are transparent rule-based analysts;
optional hosted API reviews are called out as optional and are never treated as ground truth.
"""
from __future__ import annotations

import csv
import json
import logging
import math
import os
import re
import hmac
import hashlib
import secrets
import sqlite3
import threading
import time
import urllib.parse
from datetime import datetime, timezone, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Optional

import requests

from narrative_quality import analyze_narrative_potential

# Nine task-specialist viewpoints. These are evidence-driven local agents; a single optional
# LLM review can enrich the team notes, but never overrides deterministic safety gates.
AGENTS = (
    "MOMENTUM", "FLOW", "SAFETY", "CHART", "NARRATIVE", "SKEPTIC",
    "ONCHAIN", "CATALYST", "DATA_QUALITY",
)
FEATURE_KEYS = (
    "log_mcap", "log_liquidity", "log_volume", "buy_pressure", "momentum_5m",
    "momentum_1h", "volume_acceleration", "pool_age", "liquidity_change",
    "risk_score", "social_signal", "verified", "social_links", "volatility", "smart_wallet_signal",
    "top10_concentration", "lp_lock_signal", "organic_score_norm", "risk_data_known", "data_coverage",
    "narrative_quality_norm", "social_attention_norm", "pre_hype_norm", "social_authors_norm",
    "social_attention_delta_norm", "social_mentions_delta_norm",
)
POSITIVE_WORDS = {
    "launch", "launched", "live", "partnership", "partner", "listing", "listed", "community",
    "organic", "growth", "bullish", "build", "shipping", "ship", "utility", "integration",
    "official", "milestone", "milestones", "adoption", "holders", "volume", "airdrop", "burn",
}
NEGATIVE_WORDS = {
    "rug", "rugpull", "scam", "fake", "drain", "drained", "dump", "dumping", "honeypot",
    "sell", "selling", "exploit", "hack", "stolen", "suspicious", "warning", "warning!",
    "insider", "bundler", "sniper", "mint authority", "freeze authority", "liquidity removed",
}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utc_now().isoformat(timespec="seconds")


def parse_ts(value: Any) -> Optional[datetime]:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except (TypeError, ValueError):
        return None


def num(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError):
        return default


def clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))


def sigmoid(value: float) -> float:
    value = clamp(value, -30, 30)
    return 1.0 / (1.0 + math.exp(-value))


def safe_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False, default=str)


def from_json(value: Any, fallback: Any) -> Any:
    try:
        return json.loads(value) if value else fallback
    except (ValueError, TypeError):
        return fallback


def log10_safe(value: float) -> float:
    return math.log10(max(value, 1e-9))


def percent_change(new: float, old: float) -> Optional[float]:
    if old <= 0 or new <= 0:
        return None
    return (new / old - 1.0) * 100.0


def text_sentiment(texts: list[str]) -> tuple[float, str]:
    if not texts:
        return 0.0, "Keine zugänglichen Social-Posts; Sentiment unbekannt."
    pos = neg = total = 0
    for text in texts:
        words = set(re.findall(r"[a-zA-Z][a-zA-Z0-9_'-]*", text.lower()))
        p = len(words & POSITIVE_WORDS)
        n = len(words & NEGATIVE_WORDS)
        pos += p
        neg += n
        total += max(len(words), 1)
    if pos == neg == 0:
        return 0.0, "Posts gefunden, aber einfacher Wortlisten-Scan ergibt kein klares Sentiment."
    score = clamp(50 + 25 * (pos - neg) / max(pos + neg, 1), 0, 100)
    label = "positiv" if score >= 60 else "negativ" if score <= 40 else "gemischt/neutral"
    return (score - 50) / 50, f"Einfache Wortlisten-Heuristik: {label}; kein verlässliches Verständnis von Ironie oder Kontext."


class SwarmStore:
    """Thread-safe persistent store used by the scanner, dashboard and resolver."""

    def __init__(self, path: Path):
        self.path = path
        self.conn = sqlite3.connect(path, check_same_thread=False, timeout=15)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock, self.conn:
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA busy_timeout=15000")
            self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS coin_rooms (
                mint TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', symbol TEXT NOT NULL DEFAULT '',
                first_seen TEXT NOT NULL, last_seen TEXT NOT NULL, pair_address TEXT DEFAULT '', pair_url TEXT DEFAULT '',
                price_usd REAL, market_cap_usd REAL, market_cap_is_fdv_proxy INTEGER DEFAULT 0, fdv_usd REAL,
                liquidity_usd REAL, volume_5m_usd REAL, buys_5m INTEGER, sells_5m INTEGER, buy_share_5m REAL,
                change_5m_pct REAL, change_1h_pct REAL, change_24h_pct REAL, pool_age_min REAL,
                base_score REAL, swarm_score REAL, runner_estimate_pct REAL, ml_probability REAL,
                probability_type TEXT DEFAULT 'HEURISTIC_STARTUP', signal_status TEXT DEFAULT 'WATCH',
                risk_score REAL, risk_verdict TEXT DEFAULT 'UNKNOWN', holder_count REAL, top_holder_pct REAL,
                top10_holder_pct REAL, lp_locked_pct REAL, verified_status TEXT DEFAULT 'UNAVAILABLE',
                organic_score REAL, social_mentions_24h INTEGER DEFAULT 0, social_sentiment REAL,
                social_summary TEXT DEFAULT '', narrative TEXT DEFAULT '', watched_wallet_buys INTEGER DEFAULT 0,
                watched_wallet_sells INTEGER DEFAULT 0, watched_wallet_count INTEGER DEFAULT 0, wallet_signal_summary TEXT DEFAULT '',
                websites_json TEXT DEFAULT '[]',
                socials_json TEXT DEFAULT '[]', posts_json TEXT DEFAULT '[]', metadata_json TEXT DEFAULT '{}',
                local_chart TEXT DEFAULT '', ai_verdict TEXT DEFAULT '', ai_confidence REAL, ai_thesis TEXT DEFAULT '',
                agent_scores_json TEXT DEFAULT '{}', agent_weights_json TEXT DEFAULT '{}',
                team_consensus REAL DEFAULT 0, data_coverage REAL DEFAULT 0,
                agent_disagreement REAL DEFAULT 0, entry_quality TEXT DEFAULT 'UNKNOWN',
                agency_verdict TEXT DEFAULT 'WATCH', decision_reasons_json TEXT DEFAULT '[]',
                reasons_json TEXT DEFAULT '[]', updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_rooms_update ON coin_rooms(updated_at);
            CREATE INDEX IF NOT EXISTS idx_rooms_rank ON coin_rooms(swarm_score DESC);
            CREATE TABLE IF NOT EXISTS observations (
                id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT NOT NULL, ts TEXT NOT NULL, price REAL,
                market_cap REAL, liquidity REAL, volume_5m REAL, buys INTEGER, sells INTEGER,
                base_score REAL, swarm_score REAL, stage TEXT, features_json TEXT NOT NULL,
                FOREIGN KEY(mint) REFERENCES coin_rooms(mint)
            );
            CREATE INDEX IF NOT EXISTS idx_obs_mint_ts ON observations(mint,ts);
            CREATE TABLE IF NOT EXISTS agent_notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT NOT NULL, ts TEXT NOT NULL, agent TEXT NOT NULL,
                score REAL, verdict TEXT, note TEXT NOT NULL, evidence_json TEXT DEFAULT '{}',
                FOREIGN KEY(mint) REFERENCES coin_rooms(mint)
            );
            CREATE INDEX IF NOT EXISTS idx_notes_mint_ts ON agent_notes(mint,ts DESC);
            CREATE TABLE IF NOT EXISTS forecasts (
                id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT NOT NULL, ts TEXT NOT NULL,
                horizon_minutes INTEGER NOT NULL, target_peak_return REAL NOT NULL, initial_price REAL NOT NULL,
                heuristic_probability REAL, ml_probability REAL, ensemble_probability REAL NOT NULL,
                probability_type TEXT NOT NULL, agent_probabilities_json TEXT NOT NULL, features_json TEXT NOT NULL,
                score_at_issue REAL, status TEXT NOT NULL DEFAULT 'OPEN', due_at TEXT NOT NULL,
                resolved_at TEXT, peak_return_pct REAL, end_return_pct REAL, label_hit INTEGER,
                end_observation_ts TEXT, no_data_reason TEXT DEFAULT '',
                FOREIGN KEY(mint) REFERENCES coin_rooms(mint)
            );
            CREATE INDEX IF NOT EXISTS idx_forecasts_mint_ts ON forecasts(mint,ts DESC);
            CREATE INDEX IF NOT EXISTS idx_forecasts_due ON forecasts(status,due_at);
            CREATE TABLE IF NOT EXISTS model_state (
                model_key TEXT PRIMARY KEY, weights_json TEXT NOT NULL, trained_n INTEGER NOT NULL,
                trained_at TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS provider_cache (
                mint TEXT NOT NULL, provider TEXT NOT NULL, fetched_at TEXT NOT NULL, data_json TEXT NOT NULL,
                PRIMARY KEY(mint,provider)
            );
            CREATE TABLE IF NOT EXISTS wallet_signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT, signature TEXT NOT NULL, wallet_address TEXT NOT NULL,
                wallet_label TEXT NOT NULL DEFAULT '', mint TEXT NOT NULL, direction TEXT NOT NULL, token_amount REAL,
                observed_at TEXT NOT NULL, description TEXT DEFAULT '', tx_type TEXT DEFAULT '', explorer_url TEXT DEFAULT '',
                UNIQUE(signature,wallet_address,mint,direction)
            );
            CREATE INDEX IF NOT EXISTS idx_wallet_signals_mint_time ON wallet_signals(mint,observed_at DESC);
            CREATE TABLE IF NOT EXISTS meta (
                key TEXT PRIMARY KEY, value TEXT NOT NULL
            );
            """)
            # Safe lightweight migrations if a room DB from an earlier test build exists.
            columns = {row[1] for row in self.conn.execute("PRAGMA table_info(coin_rooms)")}
            for column, declaration in (("watched_wallet_buys", "INTEGER DEFAULT 0"),
                                        ("watched_wallet_sells", "INTEGER DEFAULT 0"),
                                        ("watched_wallet_count", "INTEGER DEFAULT 0"),
                                        ("wallet_signal_summary", "TEXT DEFAULT ''"),
                                        ("team_consensus", "REAL DEFAULT 0"),
                                        ("data_coverage", "REAL DEFAULT 0"),
                                        ("agent_disagreement", "REAL DEFAULT 0"),
                                        ("entry_quality", "TEXT DEFAULT 'UNKNOWN'"),
                                        ("agency_verdict", "TEXT DEFAULT 'WATCH'"),
                                        ("decision_reasons_json", "TEXT DEFAULT '[]'")):
                if column not in columns:
                    self.conn.execute(f"ALTER TABLE coin_rooms ADD COLUMN {column} {declaration}")

    def close(self) -> None:
        with self.lock:
            self.conn.close()

    def get_cache(self, mint: str, provider: str, max_age_minutes: int) -> Optional[dict[str, Any]]:
        cutoff = (utc_now() - timedelta(minutes=max_age_minutes)).isoformat(timespec="seconds")
        with self.lock:
            row = self.conn.execute(
                "SELECT data_json FROM provider_cache WHERE mint=? AND provider=? AND fetched_at>=?",
                (mint, provider, cutoff),
            ).fetchone()
        return from_json(row[0], {}) if row else None

    def put_cache(self, mint: str, provider: str, data: dict[str, Any]) -> None:
        with self.lock, self.conn:
            self.conn.execute("""INSERT INTO provider_cache(mint,provider,fetched_at,data_json) VALUES(?,?,?,?)
            ON CONFLICT(mint,provider) DO UPDATE SET fetched_at=excluded.fetched_at,data_json=excluded.data_json""",
                              (mint, provider, iso_now(), safe_json(data)))

    def upsert_room(self, row: dict[str, Any]) -> None:
        fields = list(row.keys())
        placeholders = ",".join("?" for _ in fields)
        updates = ",".join(f"{f}=excluded.{f}" for f in fields if f not in {"mint", "first_seen"})
        with self.lock, self.conn:
            self.conn.execute(
                f"INSERT INTO coin_rooms({','.join(fields)}) VALUES({placeholders}) "
                f"ON CONFLICT(mint) DO UPDATE SET {updates}",
                [row[f] for f in fields],
            )

    def room(self, mint: str) -> Optional[dict[str, Any]]:
        with self.lock:
            row = self.conn.execute("SELECT * FROM coin_rooms WHERE mint=?", (mint,)).fetchone()
        return self._room_dict(dict(row)) if row else None

    @staticmethod
    def _room_dict(row: dict[str, Any]) -> dict[str, Any]:
        for key in ("websites_json", "socials_json", "posts_json", "metadata_json", "agent_scores_json",
                    "agent_weights_json", "reasons_json", "decision_reasons_json"):
            if key in row:
                row[key.removesuffix("_json")] = from_json(row[key], [] if key.endswith(("websites_json", "socials_json", "posts_json", "reasons_json", "decision_reasons_json")) else {})
        return row

    def record_observation(self, mint: str, ts: str, price: float, market_cap: float, liquidity: float,
                           volume_5m: float, buys: int, sells: int, base_score: float, swarm_score: float,
                           stage: str, features: dict[str, float]) -> None:
        with self.lock, self.conn:
            self.conn.execute("""INSERT INTO observations(mint,ts,price,market_cap,liquidity,volume_5m,buys,sells,
            base_score,swarm_score,stage,features_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                              (mint, ts, price, market_cap, liquidity, volume_5m, buys, sells,
                               base_score, swarm_score, stage, safe_json(features)))
            # Keep local detail history bounded; forecast records are preserved separately.
            self.conn.execute("""DELETE FROM observations WHERE mint=? AND id NOT IN
                (SELECT id FROM observations WHERE mint=? ORDER BY ts DESC LIMIT 1500)""", (mint, mint))

    def write_notes(self, mint: str, ts: str, agents: dict[str, dict[str, Any]], force: bool = False) -> None:
        with self.lock:
            row = self.conn.execute("SELECT MAX(ts) FROM agent_notes WHERE mint=?", (mint,)).fetchone()
            previous = parse_ts(row[0] if row else None)
            if not force and previous and (utc_now() - previous).total_seconds() < 150:
                # Still allow major verdict/score changes to be written immediately.
                old = self.conn.execute("""SELECT agent,score,verdict FROM agent_notes WHERE mint=? AND ts=?""",
                                        (mint, row[0])).fetchall()
                old_map = {r["agent"]: (num(r["score"]), r["verdict"]) for r in old}
                major = any(abs(num(agents[a]["score"]) - old_map.get(a, (num(agents[a]["score"]), ""))[0]) >= 8
                            or agents[a]["verdict"] != old_map.get(a, (0, ""))[1] for a in agents)
                if not major:
                    return
        with self.lock, self.conn:
            for agent, detail in agents.items():
                self.conn.execute("""INSERT INTO agent_notes(mint,ts,agent,score,verdict,note,evidence_json)
                    VALUES(?,?,?,?,?,?,?)""", (mint, ts, agent, detail["score"], detail["verdict"],
                                                  detail["note"], safe_json(detail.get("evidence", {}))))
            self.conn.execute("DELETE FROM agent_notes WHERE id NOT IN (SELECT id FROM agent_notes ORDER BY id DESC LIMIT 25000)")

    def add_wallet_signal(self, signature: str, wallet_address: str, wallet_label: str, mint: str,
                          direction: str, token_amount: Optional[float], observed_at: str,
                          description: str = "", tx_type: str = "") -> None:
        if not signature or not mint:
            return
        with self.lock, self.conn:
            self.conn.execute("""INSERT OR IGNORE INTO wallet_signals(signature,wallet_address,wallet_label,mint,direction,
                token_amount,observed_at,description,tx_type,explorer_url) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (signature, wallet_address, wallet_label, mint, direction, token_amount, observed_at,
                 description[:600], tx_type, f"https://solscan.io/tx/{signature}"))

    def wallet_signal_summary(self, mint: str, hours: int = 24) -> dict[str, Any]:
        cutoff = (utc_now() - timedelta(hours=hours)).isoformat(timespec="seconds")
        with self.lock:
            rows = self.conn.execute("SELECT direction,wallet_address,wallet_label,observed_at,signature,token_amount,description,tx_type,explorer_url FROM wallet_signals WHERE mint=? AND observed_at>=? ORDER BY observed_at DESC LIMIT 100", (mint, cutoff)).fetchall()
        records = [dict(r) for r in rows]
        buys = sum(1 for r in records if r["direction"] == "BUY_LIKE")
        sells = sum(1 for r in records if r["direction"] == "SELL_LIKE")
        inbound = sum(1 for r in records if r["direction"] == "INBOUND")
        outbound = sum(1 for r in records if r["direction"] == "OUTBOUND")
        unique = len({r["wallet_address"] for r in records})
        return {"buys": buys, "sells": sells, "inbound": inbound, "outbound": outbound,
                "unique_wallets": unique, "event_count": len(records), "events": records[:20],
                "summary": f"Watchlist: {buys} swap-buy-like / {sells} swap-sell-like; {inbound} weitere inbound / {outbound} outbound Transfers von {unique} konfigurierten Wallet(s) in {hours}h."}

    def get_role_weights(self) -> dict[str, float]:
        # Every role starts neutral; role weights are adjusted only after enough closed forecasts.
        with self.lock:
            rows = self.conn.execute("""SELECT agent_probabilities_json,label_hit FROM forecasts
                WHERE horizon_minutes=60 AND status='RESOLVED' AND label_hit IS NOT NULL
                ORDER BY resolved_at DESC LIMIT 500""").fetchall()
        briers: dict[str, list[float]] = {a: [] for a in AGENTS}
        for row in rows:
            probs = from_json(row["agent_probabilities_json"], {})
            label = float(row["label_hit"])
            for agent in AGENTS:
                if agent in probs:
                    briers[agent].append((num(probs[agent], 0.5) - label) ** 2)
        raw = {}
        for agent in AGENTS:
            if len(briers[agent]) >= 8:
                avg = sum(briers[agent]) / len(briers[agent])
                raw[agent] = clamp(1.0 / (avg + 0.12), 0.5, 2.8)
            else:
                raw[agent] = {
                    "MOMENTUM": 1.0, "FLOW": 1.1, "SAFETY": 1.3,
                    "CHART": 1.0, "NARRATIVE": 0.8, "SKEPTIC": 1.25,
                    "ONCHAIN": 1.25, "CATALYST": 0.7, "DATA_QUALITY": 1.2,
                }[agent]
        mean = sum(raw.values()) / max(len(raw), 1)
        return {key: value / mean for key, value in raw.items()}

    def role_performance(self) -> dict[str, dict[str, Any]]:
        """Outcome-based role scorecard; scores are retrospective diagnostics, not guaranteed skill."""
        with self.lock:
            rows = self.conn.execute("""SELECT agent_probabilities_json,label_hit FROM forecasts
                WHERE horizon_minutes=60 AND status='RESOLVED' AND label_hit IS NOT NULL
                ORDER BY resolved_at DESC LIMIT 1000""").fetchall()
        results: dict[str, dict[str, Any]] = {}
        for agent in AGENTS:
            probs: list[float] = []
            labels: list[float] = []
            for row in rows:
                data = from_json(row["agent_probabilities_json"], {})
                if agent in data:
                    probs.append(clamp(num(data[agent], 0.5), 0.0, 1.0))
                    labels.append(float(row["label_hit"]))
            n = len(probs)
            results[agent] = {
                "n": n,
                "brier": sum((p-y)**2 for p, y in zip(probs, labels)) / n if n else None,
                "hit_rate": sum(labels) / n if n else None,
                "calibrated": n >= 40,
            }
        return results

    def make_forecast(self, mint: str, ts: str, horizon: int, target: float, initial_price: float,
                      heuristic_p: float, ml_p: Optional[float], ensemble_p: float, probability_type: str,
                      agent_probs: dict[str, float], features: dict[str, float], score: float,
                      cooldown_minutes: int) -> bool:
        cutoff = (utc_now() - timedelta(minutes=cooldown_minutes)).isoformat(timespec="seconds")
        with self.lock, self.conn:
            existing = self.conn.execute("""SELECT 1 FROM forecasts WHERE mint=? AND horizon_minutes=?
                AND ts>=? LIMIT 1""", (mint, horizon, cutoff)).fetchone()
            if existing or initial_price <= 0:
                return False
            due_at = (parse_ts(ts) + timedelta(minutes=horizon)).isoformat(timespec="seconds")
            self.conn.execute("""INSERT INTO forecasts(mint,ts,horizon_minutes,target_peak_return,initial_price,
                heuristic_probability,ml_probability,ensemble_probability,probability_type,agent_probabilities_json,
                features_json,score_at_issue,status,due_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (mint, ts, horizon, target, initial_price, heuristic_p, ml_p, ensemble_p, probability_type,
                 safe_json(agent_probs), safe_json(features), score, "OPEN", due_at))
            return True

    def due_forecasts(self, mint: str) -> list[dict[str, Any]]:
        with self.lock:
            rows = self.conn.execute("SELECT * FROM forecasts WHERE mint=? AND status='OPEN'", (mint,)).fetchall()
        return [dict(r) for r in rows]

    def observations_for(self, mint: str, start: str, end: str) -> list[dict[str, Any]]:
        with self.lock:
            rows = self.conn.execute("""SELECT ts,price FROM observations WHERE mint=? AND ts>=? AND ts<=?
                AND price>0 ORDER BY ts ASC""", (mint, start, end)).fetchall()
        return [dict(r) for r in rows]

    def resolve_forecast(self, forecast_id: int, status: str, resolved_at: str, peak: Optional[float] = None,
                         end_return: Optional[float] = None, label: Optional[int] = None,
                         end_observation_ts: Optional[str] = None, reason: str = "") -> None:
        with self.lock, self.conn:
            self.conn.execute("""UPDATE forecasts SET status=?,resolved_at=?,peak_return_pct=?,end_return_pct=?,
                label_hit=?,end_observation_ts=?,no_data_reason=? WHERE id=? AND status='OPEN'""",
                (status, resolved_at, peak, end_return, label, end_observation_ts, reason, forecast_id))

    def model(self) -> Optional[dict[str, Any]]:
        with self.lock:
            row = self.conn.execute("SELECT * FROM model_state WHERE model_key='runner_v1'").fetchone()
        if not row:
            return None
        d = dict(row)
        d["weights"] = from_json(d["weights_json"], None)
        return d

    def save_model(self, weights: list[float], n: int, version: int) -> None:
        with self.lock, self.conn:
            self.conn.execute("""INSERT INTO model_state(model_key,weights_json,trained_n,trained_at,version)
                VALUES('runner_v1',?,?,?,?) ON CONFLICT(model_key) DO UPDATE SET
                weights_json=excluded.weights_json,trained_n=excluded.trained_n,trained_at=excluded.trained_at,
                version=excluded.version""", (safe_json(weights), n, iso_now(), version))

    def stats(self) -> dict[str, Any]:
        with self.lock:
            rooms = self.conn.execute("SELECT COUNT(*) FROM coin_rooms").fetchone()[0]
            recent = self.conn.execute("SELECT COUNT(*) FROM coin_rooms WHERE updated_at>=?", ((utc_now()-timedelta(minutes=10)).isoformat(timespec="seconds"),)).fetchone()[0]
            calls = self.conn.execute("SELECT COUNT(*) FROM coin_rooms WHERE signal_status='CALL'").fetchone()[0]
            open_fc = self.conn.execute("SELECT COUNT(*) FROM forecasts WHERE status='OPEN'").fetchone()[0]
            resolved = self.conn.execute("SELECT COUNT(*) FROM forecasts WHERE status='RESOLVED'").fetchone()[0]
            no_data = self.conn.execute("SELECT COUNT(*) FROM forecasts WHERE status='NO_DATA'").fetchone()[0]
            rows = self.conn.execute("SELECT label_hit,ensemble_probability FROM forecasts WHERE horizon_minutes=60 AND status='RESOLVED' AND label_hit IS NOT NULL ORDER BY resolved_at DESC LIMIT 1000").fetchall()
            counts_by_horizon = self.conn.execute("SELECT horizon_minutes,status,COUNT(*) n FROM forecasts GROUP BY horizon_minutes,status").fetchall()
        brier = (sum((num(r["ensemble_probability"]) - num(r["label_hit"]))**2 for r in rows) / len(rows)) if rows else None
        hit_rate = (sum(num(r["label_hit"]) for r in rows) / len(rows)) if rows else None
        return {"rooms": rooms, "updated_10m": recent, "calls": calls, "open_forecasts": open_fc,
                "resolved_forecasts": resolved, "no_data_forecasts": no_data,
                "60m_resolved_n": len(rows), "60m_hit_rate": hit_rate, "60m_brier": brier,
                "horizon_counts": [dict(r) for r in counts_by_horizon]}

    def all_rooms(self, limit: int = 500) -> list[dict[str, Any]]:
        with self.lock:
            rows = self.conn.execute("""SELECT * FROM coin_rooms ORDER BY
                CASE signal_status WHEN 'CALL' THEN 0 WHEN 'WATCH' THEN 1 WHEN 'BLOCKED' THEN 2 ELSE 3 END,
                swarm_score DESC, updated_at DESC LIMIT ?""", (limit,)).fetchall()
        return [self._room_dict(dict(r)) for r in rows]

    def room_detail(self, mint: str) -> dict[str, Any]:
        room = self.room(mint)
        if not room:
            return {}
        with self.lock:
            notes = self.conn.execute("SELECT * FROM agent_notes WHERE mint=? ORDER BY ts DESC,id DESC LIMIT 120", (mint,)).fetchall()
            forecasts = self.conn.execute("SELECT * FROM forecasts WHERE mint=? ORDER BY ts DESC LIMIT 150", (mint,)).fetchall()
            observations = self.conn.execute("SELECT ts,price,market_cap,liquidity,volume_5m,buys,sells,swarm_score,stage FROM observations WHERE mint=? ORDER BY ts DESC LIMIT 200", (mint,)).fetchall()
        return {"room": room, "notes": [dict(n) | {"evidence": from_json(n["evidence_json"], {})} for n in notes],
                "forecasts": [dict(f) | {"agent_probabilities": from_json(f["agent_probabilities_json"], {}), "features": from_json(f["features_json"], {})} for f in forecasts],
                "observations": [dict(o) for o in reversed(observations)],
                "wallet_activity": self.wallet_signal_summary(mint)}


class ExternalEnrichment:
    """Optional documented providers. API keys and social access are user-configured."""

    def __init__(self, cfg: dict[str, Any], store: SwarmStore):
        self.cfg = cfg
        self.store = store
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "R1_H-Runner-Intel/3.0 read-only research"})
        self.lock = threading.Lock()
        self.window_started = time.monotonic()
        self.calls_in_window = 0
        self.max_calls = int(cfg.get("max_external_calls_per_minute", 10))

    def _budget(self) -> bool:
        with self.lock:
            now = time.monotonic()
            if now - self.window_started >= 60:
                self.window_started = now
                self.calls_in_window = 0
            if self.calls_in_window >= self.max_calls:
                return False
            self.calls_in_window += 1
            return True

    def _get(self, url: str, headers: Optional[dict[str, str]] = None, params: Optional[dict[str, Any]] = None,
             timeout: int = 8) -> Any:
        if not self._budget():
            return None
        try:
            resp = self.session.get(url, headers=headers, params=params, timeout=timeout)
            if resp.status_code in (401, 403, 429):
                logging.debug("External provider status %s for %s", resp.status_code, url)
                return None
            resp.raise_for_status()
            return resp.json()
        except (requests.RequestException, ValueError) as exc:
            logging.debug("Enrichment request failed %s: %s", url, exc)
            return None

    def _post(self, url: str, body: dict[str, Any], timeout: int = 8) -> Any:
        if not self._budget():
            return None
        try:
            resp = self.session.post(url, json=body, timeout=timeout)
            if resp.status_code in (401, 403, 429):
                logging.debug("External provider status %s for %s", resp.status_code, url)
                return None
            resp.raise_for_status()
            return resp.json()
        except (requests.RequestException, ValueError) as exc:
            logging.debug("Enrichment request failed %s: %s", url, exc)
            return None

    def _cached_or_fetch(self, mint: str, provider: str, ttl: int, fetcher) -> dict[str, Any]:
        cached = self.store.get_cache(mint, provider, ttl)
        if cached is not None:
            return cached
        data = fetcher()
        if isinstance(data, dict):
            data.setdefault("_fetched_at", iso_now())
            self.store.put_cache(mint, provider, data)
            return data
        # Cache empty failure briefly to avoid banging a provider during outages.
        self.store.put_cache(mint, provider, {"_unavailable": True, "_fetched_at": iso_now()})
        return {"_unavailable": True}

    def jupiter_token(self, mint: str) -> dict[str, Any]:
        key = os.getenv("JUPITER_API_KEY", "").strip()
        if not key:
            return {"configured": False, "status": "UNAVAILABLE"}
        def fetch() -> dict[str, Any]:
            data = self._get("https://api.jup.ag/tokens/v2/search", headers={"x-api-key": key}, params={"query": mint})
            records = data if isinstance(data, list) else data.get("data", []) if isinstance(data, dict) else []
            token = next((x for x in records if isinstance(x, dict) and str(x.get("id", x.get("address", ""))).lower() == mint.lower()), None)
            if token is None and records and isinstance(records[0], dict):
                # Search may rank a related token first; never misattribute that record.
                token = next((x for x in records if str(x.get("mint", "")).lower() == mint.lower()), None)
            if not token:
                return {"configured": True, "status": "NOT_RETURNED"}
            audit = token.get("audit") or {}
            verified = token.get("isVerified", token.get("verified"))
            tags = token.get("tags") or []
            banned = bool(token.get("isBanned") or token.get("banned") or "banned" in tags)
            if banned or audit.get("isSus"):
                status = "BANNED_OR_SUSPICIOUS"
            elif verified is True or "verified" in tags:
                status = "JUPITER_VERIFIED"
            elif verified is False:
                status = "UNVERIFIED"
            else:
                status = "UNKNOWN"
            return {"configured": True, "status": status, "is_verified": verified,
                    "organic_score": token.get("organicScore"), "holder_count": token.get("holderCount"),
                    "market_cap": token.get("mcap", token.get("marketCap")), "liquidity": token.get("liquidity"),
                    "audit": audit, "tags": tags, "name": token.get("name"), "symbol": token.get("symbol"),
                    "source": "Jupiter Tokens API v2"}
        return self._cached_or_fetch(mint, "jupiter", int(self.cfg.get("jupiter_cache_minutes", 60)), fetch)

    def helius_asset(self, mint: str) -> dict[str, Any]:
        key = os.getenv("HELIUS_API_KEY", "").strip()
        if not key:
            return {"configured": False, "status": "UNAVAILABLE"}
        def fetch() -> dict[str, Any]:
            data = self._post(f"https://mainnet.helius-rpc.com/?api-key={urllib.parse.quote(key)}",
                              {"jsonrpc": "2.0", "id": "r1_h", "method": "getAsset", "params": {"id": mint}})
            asset = data.get("result") if isinstance(data, dict) else None
            if not isinstance(asset, dict):
                return {"configured": True, "status": "NOT_RETURNED"}
            content = asset.get("content") or {}
            metadata = content.get("metadata") or {}
            links = content.get("links") or {}
            files = content.get("files") or []
            out_links = []
            for keyname, value in links.items():
                if isinstance(value, str) and value.startswith(("http://", "https://")):
                    out_links.append({"type": keyname, "label": keyname, "url": value})
            return {"configured": True, "status": "RETURNED", "name": metadata.get("name", ""),
                    "symbol": metadata.get("symbol", ""), "description": metadata.get("description", ""),
                    "json_uri": content.get("json_uri", ""), "links": out_links,
                    "token_info": asset.get("token_info") or {}, "authorities": asset.get("authorities") or [],
                    "files": files, "source": "Helius DAS getAsset"}
        return self._cached_or_fetch(mint, "helius", int(self.cfg.get("helius_cache_minutes", 120)), fetch)

    def x_posts(self, mint: str, symbol: str, name: str, links: list[dict[str, Any]]) -> dict[str, Any]:
        token = os.getenv("X_BEARER_TOKEN", "").strip()
        if not token:
            return {"configured": False, "posts": [], "summary": "X-API nicht konfiguriert."}
        handle = ""
        for link in links:
            url = str(link.get("url", "") or "")
            direct_handle = str(link.get("handle", "") or "")
            platform = str(link.get("platform", link.get("type", "")) or "").casefold()
            if "x.com/" in url or "twitter.com/" in url:
                handle = url.split("x.com/", 1)[-1] if "x.com/" in url else url.split("twitter.com/", 1)[-1]
                handle = re.split(r"[/?#]", handle)[0].lstrip("@")
                break
            if direct_handle and any(tag in platform for tag in ("x", "twitter")):
                handle = re.split(r"[/?#]", direct_handle)[0].lstrip("@")
                if handle:
                    break
        # Search the token itself, its explicit cashtag, and project name. The linked
        # official account is recorded separately; searching only `from:handle` would
        # let issuer posts crowd out independent community attention.
        query_parts = [f'"{mint}"']
        if symbol and re.fullmatch(r"[A-Za-z0-9_]{2,12}", symbol):
            query_parts.append(f'${symbol}')
        if name and len(name.strip()) >= 4:
            query_parts.append(f'"{name.strip()[:60]}"')
        query = " OR ".join(dict.fromkeys(query_parts)) + " -is:retweet"
        def fetch() -> dict[str, Any]:
            data = self._get("https://api.x.com/2/tweets/search/recent",
                             headers={"Authorization": f"Bearer {token}"},
                             params={"query": query, "max_results": 10,
                                     "tweet.fields": "created_at,public_metrics,lang,author_id",
                                     "expansions": "author_id", "user.fields": "username,verified"})
            if not isinstance(data, dict):
                return {"configured": True, "posts": [], "summary": "X-Abfrage nicht verfügbar oder kein Zugriff."}
            users = {u.get("id"): u for u in ((data.get("includes") or {}).get("users") or []) if isinstance(u, dict)}
            posts = []
            for item in data.get("data") or []:
                if not isinstance(item, dict):
                    continue
                author = users.get(item.get("author_id"), {})
                metrics = item.get("public_metrics") or {}
                username = str(author.get("username", ""))
                official_match = bool(handle and username.casefold() == handle.casefold())
                views = metrics.get("view_count", metrics.get("impression_count"))
                posts.append({"text": item.get("text", ""), "created_at": item.get("created_at"),
                              "likes": metrics.get("like_count", 0), "reposts": metrics.get("retweet_count", 0),
                              "replies": metrics.get("reply_count", 0), "quotes": metrics.get("quote_count", 0),
                              "bookmarks": metrics.get("bookmark_count", 0), "views": views,
                              "username": username, "author_id": item.get("author_id"),
                              "verified_author": author.get("verified"), "is_official_author": official_match,
                              "url": f"https://x.com/{username or 'i'}/status/{item.get('id','')}"})
            return {"configured": True, "posts": posts, "summary": f"{len(posts)} öffentliche X-Posts; Suche: {query}", "query": query}
        return self._cached_or_fetch(mint, "x_posts", int(self.cfg.get("x_cache_minutes", 15)), fetch)

    def reddit_posts(self, mint: str, symbol: str, name: str) -> dict[str, Any]:
        cid, secret = os.getenv("REDDIT_CLIENT_ID", "").strip(), os.getenv("REDDIT_CLIENT_SECRET", "").strip()
        if not cid or not secret:
            return {"configured": False, "posts": [], "summary": "Reddit-API nicht konfiguriert."}
        user_agent = os.getenv("REDDIT_USER_AGENT", "R1_H-RunnerIntel/3.0 research by user")
        def fetch() -> dict[str, Any]:
            if not self._budget():
                return {"configured": True, "posts": [], "summary": "Rate-Limit für externe Quellen erreicht."}
            try:
                token_resp = self.session.post("https://www.reddit.com/api/v1/access_token",
                    auth=(cid, secret), data={"grant_type": "client_credentials"},
                    headers={"User-Agent": user_agent}, timeout=8)
                if token_resp.status_code != 200:
                    return {"configured": True, "posts": [], "summary": "Reddit-OAuth nicht verfügbar."}
                token = token_resp.json().get("access_token")
                if not token:
                    return {"configured": True, "posts": [], "summary": "Reddit-OAuth lieferte kein Token."}
                terms = [f'"{mint}"']
                if name and len(name.strip()) >= 3:
                    terms.append(f'"{name.strip()[:80]}"')
                if symbol and re.fullmatch(r"[A-Za-z0-9_]{2,12}", symbol):
                    terms.append(f"{symbol}")
                query = " OR ".join(terms)
                result = self.session.get("https://oauth.reddit.com/search.json",
                    params={"q": query, "sort": "new", "t": "day", "limit": 10},
                    headers={"Authorization": f"Bearer {token}", "User-Agent": user_agent}, timeout=8)
                if result.status_code != 200:
                    return {"configured": True, "posts": [], "summary": "Reddit-Suche nicht verfügbar."}
                items = ((result.json().get("data") or {}).get("children") or [])
                posts = []
                for child in items:
                    d = child.get("data") or {}
                    posts.append({"text": (d.get("title", "") + "\n" + d.get("selftext", ""))[:2000],
                                  "created_at": datetime.fromtimestamp(num(d.get("created_utc")), timezone.utc).isoformat(),
                                  "score": d.get("score", 0), "comments": d.get("num_comments", 0),
                                  "author": d.get("author", ""), "subreddit": d.get("subreddit", ""),
                                  "url": "https://reddit.com" + d.get("permalink", "")})
                return {"configured": True, "posts": posts, "summary": f"{len(posts)} öffentliche Reddit-Treffer; Suchtreffer können gleichnamige Themen verwechseln."}
            except (requests.RequestException, ValueError) as exc:
                return {"configured": True, "posts": [], "summary": f"Reddit nicht verfügbar: {type(exc).__name__}."}
        return self._cached_or_fetch(mint, "reddit_posts", int(self.cfg.get("reddit_cache_minutes", 30)), fetch)

    def wallet_transactions(self, wallet: str, limit: int = 25) -> Optional[list[dict[str, Any]]]:
        """Read recent public wallet activity using Helius' transfer API, then fallback to Enhanced Transactions."""
        key = os.getenv("HELIUS_API_KEY", "").strip()
        if not key:
            return None
        url = f"https://mainnet.helius-rpc.com/?api-key={urllib.parse.quote(key)}"
        data = self._post(url, {"jsonrpc": "2.0", "id": "r1_h-wallet", "method": "getTransfersByAddress",
                                "params": [wallet, {"limit": min(100, max(1, limit))}]}, timeout=10)
        if isinstance(data, dict):
            result = data.get("result")
            if isinstance(result, list):
                return result
            if isinstance(result, dict):
                records = result.get("data") or result.get("transactions") or []
                if isinstance(records, list):
                    return records
        # Compatibility fallback; the newer Helius transfer API may not be enabled on every key/tier.
        data = self._get(f"https://api-mainnet.helius-rpc.com/v0/addresses/{urllib.parse.quote(wallet)}/transactions",
                         params={"api-key": key, "limit": min(100, max(1, limit))}, timeout=10)
        return data if isinstance(data, list) else None

    def enrich(self, mint: str, m: Any, force: bool = False, include_external: bool = True) -> dict[str, Any]:
        src = m.source_pair or {}
        info = src.get("info") or {}
        description = str(info.get("description") or "")
        websites = [x for x in (info.get("websites") or []) if isinstance(x, dict) and x.get("url")]
        socials = [x for x in (info.get("socials") or []) if isinstance(x, dict) and (x.get("url") or x.get("handle"))]
        external_calls_enabled = any(os.getenv(k, "").strip() for k in ("JUPITER_API_KEY", "HELIUS_API_KEY", "X_BEARER_TOKEN", "REDDIT_CLIENT_ID"))
        cache_ttl = int(self.cfg.get("enrichment_cache_minutes", 60))
        cached_combined = self.store.get_cache(mint, "combined_enrichment", cache_ttl)
        if cached_combined and not force:
            # Cached source responses keep rate use bounded, but don't let a profile
            # snapshot masquerade as measured community traction.
            ext = cached_combined
        elif include_external:
            jupiter = self.jupiter_token(mint) if os.getenv("JUPITER_API_KEY", "").strip() else {"configured": False, "status": "UNAVAILABLE"}
            helius = self.helius_asset(mint) if os.getenv("HELIUS_API_KEY", "").strip() else {"configured": False, "status": "UNAVAILABLE"}
            combined_links = websites + socials + (helius.get("links") or [])
            social_gate = (m.market_cap > 0 and m.liquidity >= float(self.cfg.get("social_min_liquidity_usd", 2500)))
            if os.getenv("X_BEARER_TOKEN", "").strip() and social_gate:
                x_data = self.x_posts(mint, m.symbol, m.name, combined_links)
            else:
                x_data = {"configured": bool(os.getenv("X_BEARER_TOKEN", "").strip()), "posts": [], "summary": "X nicht abgefragt (API-Key fehlt oder Liquiditätsfilter nicht bestanden)."}
            if os.getenv("REDDIT_CLIENT_ID", "").strip() and social_gate:
                reddit = self.reddit_posts(mint, m.symbol, m.name)
            else:
                reddit = {"configured": bool(os.getenv("REDDIT_CLIENT_ID", "").strip()), "posts": [], "summary": "Reddit nicht abgefragt (API-Zugang fehlt oder Liquiditätsfilter nicht bestanden)."}
            ext = {"jupiter": jupiter, "helius": helius, "x": x_data, "reddit": reddit,
                   "_fetched_at": iso_now(), "_social_enrichment_done": True}
            if external_calls_enabled:
                self.store.put_cache(mint, "combined_enrichment", ext)
        else:
            # Avoid wasting provider quota on tiny pools and dead/failed candidates.
            # Do not cache this placeholder: a later, stronger candidate must be enriched.
            ext = {"jupiter": {"configured": bool(os.getenv("JUPITER_API_KEY", "").strip()), "status": "NOT_FETCHED"},
                   "helius": {"configured": bool(os.getenv("HELIUS_API_KEY", "").strip()), "status": "NOT_FETCHED", "links": []},
                   "x": {"configured": bool(os.getenv("X_BEARER_TOKEN", "").strip()), "posts": [], "summary": "Social API-Scan für diesen Kandidaten übersprungen."},
                   "reddit": {"configured": bool(os.getenv("REDDIT_CLIENT_ID", "").strip()), "posts": [], "summary": "Social API-Scan für diesen Kandidaten übersprungen."},
                   "_fetched_at": iso_now(), "_social_enrichment_done": False}
        helius = ext.get("helius") or {}
        jupiter = ext.get("jupiter") or {}
        x_data = ext.get("x") or {"posts": []}
        reddit = ext.get("reddit") or {"posts": []}
        # Narrative is project-supplied copy, not independently verified evidence.
        issuer_description = description or str(helius.get("description") or "")
        if not description and not issuer_description:
            issuer_description = "Keine lesbare Projektbeschreibung in den abgefragten Metadaten gefunden."
        link_urls = websites + socials + (helius.get("links") or [])
        dedup = {}
        for link in link_urls:
            url = str(link.get("url", "")).strip()
            if url.startswith(("https://", "http://")):
                dedup[url] = {"type": str(link.get("type") or "link"), "label": str(link.get("label") or link.get("type") or "Link"), "url": url}
        x_posts = [p for p in (x_data.get("posts") or []) if isinstance(p, dict)]
        reddit_posts = [p for p in (reddit.get("posts") or []) if isinstance(p, dict)]
        all_posts = [{**p, "source": "X"} for p in x_posts] + [{**p, "source": "Reddit"} for p in reddit_posts]
        texts = [str(p.get("text", "")) for p in all_posts]
        sentiment, sentiment_note = text_sentiment(texts)
        social_summary = "; ".join(x for x in [x_data.get("summary", ""), reddit.get("summary", ""), sentiment_note] if x)
        status = str(jupiter.get("status") or "UNAVAILABLE")
        return {"narrative": issuer_description, "websites": list({x["url"]: x for x in dedup.values() if x.get("type", "").lower() in ("website", "web") or "http" in x.get("url", "")}.values())[:12],
                "socials": list(dedup.values())[:30], "posts": all_posts[:20], "social_sentiment": sentiment,
                "social_summary": social_summary[:1200], "verified_status": status,
                "organic_score": jupiter.get("organic_score"), "holder_count_provider": jupiter.get("holder_count"),
                "provider_market_cap": jupiter.get("market_cap"), "provider_liquidity": jupiter.get("liquidity"),
                "jupiter_audit": jupiter.get("audit") or {}, "jupiter_tags": jupiter.get("tags") or [],
                "helius_metadata": {"description": helius.get("description", ""), "json_uri": helius.get("json_uri", ""),
                                    "name": helius.get("name", ""), "symbol": helius.get("symbol", "")},
                "providers": {"Jupiter": jupiter.get("source", "not configured"), "Helius": helius.get("source", "not configured"),
                              "X": "configured" if x_data.get("configured") else "not configured",
                              "Reddit": "configured" if reddit.get("configured") else "not configured",
                              "external_fetched": bool(ext.get("_social_enrichment_done", False)),
                              "external_fetched_at": ext.get("_fetched_at") if ext.get("_social_enrichment_done", False) else None}}


def build_features(m: Any, risk: Optional[dict[str, Any]], trend: dict[str, Any], enrich: dict[str, Any]) -> dict[str, float]:
    risk_details = (risk or {}).get("details") or {}
    risk_score = num((risk or {}).get("score"), 50.0) if (risk or {}).get("score") is not None else 50.0
    top10 = num(risk_details.get("top10HoldersPct", risk_details.get("topHoldersPct", risk_details.get("top10_holders_pct"))), 0)
    liq_change = trend.get("liquidity_change_pct")
    vol_mom = trend.get("volume_momentum_x")
    age = max(num(m.age_minutes), 0)
    status = enrich.get("verified_status", "UNAVAILABLE")
    verified = 1.0 if status == "JUPITER_VERIFIED" else -1.0 if status == "BANNED_OR_SUSPICIOUS" else 0.0
    posts = enrich.get("posts") or []
    sentiment = num(enrich.get("social_sentiment"), 0.0)
    wallet_activity = enrich.get("wallet_activity") or {}
    wallet_signal = clamp((num(wallet_activity.get("buys")) - num(wallet_activity.get("sells"))) / 3, -1, 1)
    return {
        "log_mcap": clamp((log10_safe(num(m.market_cap, 1)) - 4.5) / 2.5, -1, 1),
        "log_liquidity": clamp((log10_safe(num(m.liquidity, 1)) - 4.0) / 2.0, -1, 1),
        "log_volume": clamp((log10_safe(num(m.volume_5m, 1)) - 3.5) / 3.0, -1, 1),
        "buy_pressure": clamp((num(m.buy_share_5m, .5) - .5) * 2, -1, 1),
        "momentum_5m": clamp(num(m.change_5m) / 50, -1, 1),
        "momentum_1h": clamp(num(m.change_1h) / 100, -1, 1),
        "volume_acceleration": clamp(math.log(max(num(vol_mom, 1.0), 0.1)) / 2, -1, 1) if vol_mom is not None else 0.0,
        "pool_age": clamp(math.log10(age + 1) / 3.5, 0, 1),
        "liquidity_change": clamp(num(liq_change) / 50, -1, 1) if liq_change is not None else 0.0,
        "risk_score": clamp((risk_score - 50) / 50, -1, 1),
        "social_signal": clamp(sentiment * min(1.0, len(posts) / 5.0), -1, 1),
        "verified": verified,
        "social_links": clamp(len(enrich.get("socials") or []) / 3, 0, 1),
        "volatility": clamp(num(trend.get("volatility_pct")) / 20, 0, 1),
        "smart_wallet_signal": wallet_signal,
        "top10_concentration": clamp(top10 / 50.0 - 1.0, -1, 1) if top10 > 0 else 0.0,
        "lp_lock_signal": clamp(num((risk_details.get("lpLockedPct", risk_details.get("lp_locked_pct"))), 50.0) / 50.0 - 1.0, -1, 1)
            if ("lpLockedPct" in risk_details or "lp_locked_pct" in risk_details) else 0.0,
        "organic_score_norm": clamp((num(enrich.get("organic_score"), 50.0) - 50.0) / 50.0, -1, 1)
            if enrich.get("organic_score") is not None else 0.0,
        "narrative_quality_norm": clamp((num((enrich.get("narrative_analysis") or {}).get("narrative_score"), 50) - 50) / 50, -1, 1),
        "social_attention_norm": clamp((num((enrich.get("narrative_analysis") or {}).get("social_attention_score"), 0)) / 100, 0, 1),
        "pre_hype_norm": clamp((num((enrich.get("narrative_analysis") or {}).get("pre_hype_score"), 50) - 50) / 50, -1, 1),
        "social_authors_norm": clamp(num((enrich.get("narrative_analysis") or {}).get("unique_community_authors"), 0) / 8, 0, 1),
        "social_attention_delta_norm": clamp(num((enrich.get("narrative_analysis") or {}).get("attention_delta"), 0) / 30, -1, 1),
        "social_mentions_delta_norm": clamp(num((enrich.get("narrative_analysis") or {}).get("mentions_delta"), 0) / 6, -1, 1),
        "risk_data_known": 1.0 if risk is not None and (risk or {}).get("score") is not None else -1.0,
        "data_coverage": _data_coverage(m, risk, trend, enrich),
    }


def _data_coverage(m: Any, risk: Optional[dict[str, Any]], trend: dict[str, Any], enrich: dict[str, Any]) -> float:
    """Coverage of decision-critical evidence fields, not an estimate of token quality."""
    details = (risk or {}).get("details") or {}
    checks = [
        num(getattr(m, "price_usd", 0)) > 0,
        num(getattr(m, "market_cap", 0)) > 0,
        num(getattr(m, "liquidity", 0)) > 0,
        num(getattr(m, "volume_5m", 0)) > 0,
        (num(getattr(m, "buys_5m", 0)) + num(getattr(m, "sells_5m", 0))) > 0,
        risk is not None and (risk or {}).get("score") is not None,
        any(k in details for k in ("top10HoldersPct", "topHoldersPct", "top10_holders_pct")),
        any(k in details for k in ("lpLockedPct", "lp_locked_pct")),
    ]
    return sum(1 for check in checks if check) / len(checks)


def analyze_roles(m: Any, base_score: float, base_stage: str, risk: Optional[dict[str, Any]],
                  trend: dict[str, Any], enrich: dict[str, Any], features: dict[str, float]) -> dict[str, dict[str, Any]]:
    risk_details = (risk or {}).get("details") or {}
    risk_score_val = (risk or {}).get("score")
    high_risk = bool((risk or {}).get("rugged")) or str((risk or {}).get("verdict", "")).upper() in ("HIGH_RISK", "DANGER")
    if risk_score_val is not None and num(risk_score_val) > 35:
        high_risk = True
    if enrich.get("verified_status") == "BANNED_OR_SUSPICIOUS":
        high_risk = True
    buy_share = num(m.buy_share_5m)
    txns = num(m.buys_5m) + num(m.sells_5m)
    vol_mom = trend.get("volume_momentum_x")
    local5 = trend.get("change_5m")
    local15 = trend.get("change_15m")
    liquidity_change = trend.get("liquidity_change_pct")
    volat = num(trend.get("volatility_pct"))
    top10 = num(risk_details.get("top10HoldersPct", risk_details.get("topHoldersPct", risk_details.get("top10_holders_pct"))), 0)
    lp_lock = risk_details.get("lpLockedPct", risk_details.get("lp_locked_pct"))
    narrative = str(enrich.get("narrative") or "")
    post_count = len(enrich.get("posts") or [])
    sentiment = num(enrich.get("social_sentiment"), 0.0)
    verified = enrich.get("verified_status") == "JUPITER_VERIFIED"
    suspect = enrich.get("verified_status") == "BANNED_OR_SUSPICIOUS"

    momentum = 54.0 + clamp(num(m.change_5m), -15, 25) * 0.45 + clamp(num(m.change_1h), -15, 35) * 0.25
    momentum += (clamp(num(vol_mom, 1), 0, 3) - 1) * 6 if vol_mom is not None else 0
    if num(m.change_5m) > 50: momentum -= 18
    if num(m.change_5m) < -10: momentum -= 14
    if liquidity_change is not None and num(liquidity_change) < -20: momentum -= 18
    momentum = clamp(momentum)

    flow = 35 + buy_share * 42 + min(txns, 100) * 0.17
    flow += (clamp(num(vol_mom, 1), 0, 3) - 1) * 5 if vol_mom is not None else 0
    wallet_activity = enrich.get("wallet_activity") or {}
    flow += min(3, num(wallet_activity.get("buys"))) * 3
    flow -= min(3, num(wallet_activity.get("sells"))) * 4
    if m.liquidity > 0 and m.volume_5m / m.liquidity > 4: flow -= 10
    flow = clamp(flow)

    safety = 70.0
    if risk is None or risk_score_val is None: safety -= 15
    elif num(risk_score_val) > 50: safety -= 35
    elif num(risk_score_val) > 35: safety -= 20
    elif num(risk_score_val) <= 10: safety += 7
    if high_risk: safety -= 35
    if top10 > 70: safety -= 28
    elif top10 > 50: safety -= 18
    elif top10 > 30: safety -= 10
    if lp_lock is not None and num(lp_lock) < 20: safety -= 10
    if m.liquidity < 5000: safety -= 18
    if verified: safety += 5
    safety = clamp(safety)

    chart = 55 + clamp(num(local5, num(m.change_5m)), -15, 20) * 0.55 + clamp(num(local15, num(m.change_1h)), -30, 35) * 0.18
    chart += 4 if num(m.change_5m) > 0 and num(m.change_1h) > 0 else 0
    chart -= min(20, volat * 0.8)
    if liquidity_change is not None and num(liquidity_change) < -15: chart -= 18
    if num(m.change_5m) > 40: chart -= 12
    chart = clamp(chart)

    narrative_report = enrich.get("narrative_analysis") or {}
    narrative_score = num(narrative_report.get("narrative_score"), 18)
    # Community interest is evaluated separately from issuer/project copy.
    narrative_score += min(10, num(narrative_report.get("unique_community_authors")) * 1.5)
    if verified and narrative_report.get("narrative_score", 0) >= 55:
        narrative_score += 2
    if suspect:
        narrative_score -= 25
    narrative_score = clamp(narrative_score)

    skepticism = 75.0
    if m.market_cap_is_fdv: skepticism -= 10
    if m.liquidity < 10000: skepticism -= 16
    if m.liquidity > 0 and m.market_cap > 0 and m.liquidity / m.market_cap < 0.04: skepticism -= 18
    if m.change_5m > 35: skepticism -= 18
    if m.change_5m > 80: skepticism -= 20
    if txns > 0 and buy_share > .85: skepticism -= 7  # intense buy skew may mean a crowded/fragile tape
    if num(m.boosts_active) > 0: skepticism -= min(10, num(m.boosts_active) * 2)  # paid promotion is not organic proof
    if vol_mom is not None and num(vol_mom) > 8: skepticism -= 12
    if high_risk or suspect: skepticism -= 35
    if num(features["social_signal"]) < -0.3: skepticism -= 12
    if num(wallet_activity.get("sells")) > num(wallet_activity.get("buys")) and num(wallet_activity.get("sells")) > 0:
        skepticism -= 12
    skepticism = clamp(skepticism)

    def detail(score: float, label: str, note: str, evidence: dict[str, Any]) -> dict[str, Any]:
        verdict = "POSITIVE" if score >= 70 else "CAUTION" if score >= 50 else "NEGATIVE"
        return {"score": round(score, 1), "verdict": verdict, "note": note,
                "evidence": evidence, "probability": round(clamp(0.08 + score / 100 * 0.68, .03, .78), 4)}

    result = {
        "MOMENTUM": detail(momentum, "momentum", f"Momentum-Rollup: 5m {num(m.change_5m):+.1f}%, 1h {num(m.change_1h):+.1f}%; Volumenmultiplikator {('unbekannt' if vol_mom is None else f'{num(vol_mom):.2f}x')}.",
                            {"change_5m_pct": num(m.change_5m), "change_1h_pct": num(m.change_1h), "volume_momentum_x": vol_mom}),
        "FLOW": detail(flow, "flow", f"Flow: {int(num(m.buys_5m))} Käufe / {int(num(m.sells_5m))} Verkäufe in 5m; Buy-Anteil {buy_share*100:.1f}%. {wallet_activity.get('summary', 'Keine Smart-Wallet-Watchlist konfiguriert oder keine Events.')}",
                        {"buys_5m": int(num(m.buys_5m)), "sells_5m": int(num(m.sells_5m)), "buy_share": buy_share, "volume_5m_usd": num(m.volume_5m), "watched_wallet_activity": wallet_activity}),
        "SAFETY": detail(safety, "safety", f"Safety: RugCheck {('unbekannt' if risk_score_val is None else str(risk_score_val))}; Jupiter-Status {enrich.get('verified_status','UNAVAILABLE')}; Top-10-Angabe {top10 or 'unbekannt'}.",
                           {"risk_score": risk_score_val, "risk_verdict": (risk or {}).get("verdict", "UNKNOWN"), "top10_pct": top10 or None, "lp_locked_pct": lp_lock, "verified_status": enrich.get("verified_status")}),
        "CHART": detail(chart, "chart", f"Chart: lokale 5m-Veränderung {('unbekannt' if local5 is None else f'{num(local5):+.1f}%')}; Volatilität {volat:.2f}; Liquiditätsänderung {('unbekannt' if liquidity_change is None else f'{num(liquidity_change):+.1f}%')}.",
                         {"local_change_5m_pct": local5, "local_change_15m_pct": local15, "volatility_pct": volat, "liquidity_change_pct": liquidity_change, "sparkline": trend.get("sparkline", "")}),
        "NARRATIVE": detail(narrative_score, "narrative", f"Narrative quality {narrative_report.get('narrative_score', 'n/a')}/100; organic attention {narrative_report.get('social_attention_score', 'n/a')}/100 from {narrative_report.get('matched_posts', 0)} matching posts and {narrative_report.get('unique_community_authors', 0)} community authors. {enrich.get('social_summary','Social-Daten unvollständig')}. Project descriptions are claims, not verification.",
                             {"description_excerpt": narrative[:500], "social_links": enrich.get("socials", []), "post_count": post_count, "social_sentiment": sentiment, "verified_status": enrich.get("verified_status"), "narrative_analysis": narrative_report}),
        "SKEPTIC": detail(skepticism, "skeptic", f"Gegenprüfung: {('bekannte Risikosignale vorhanden' if high_risk or suspect else 'keine harte Risikoflag aus den aktuell verfügbaren Feldern')}; MC-Quelle {'FDV-Proxy' if m.market_cap_is_fdv else 'Market Cap API'}; bezahlte Boosts {int(num(m.boosts_active))}.",
                           {"high_risk": high_risk, "market_cap_is_fdv_proxy": bool(m.market_cap_is_fdv), "boosts_active": int(num(m.boosts_active)), "liquidity_to_marketcap": m.liquidity / m.market_cap if m.market_cap > 0 else None, "watched_wallet_activity": wallet_activity}),
    }

    # ONCHAIN specialist: concentration, LP evidence, watched-wallet direction and liquidity behaviour.
    onchain = 58.0
    if risk_score_val is None: onchain -= 18
    elif num(risk_score_val) <= 10: onchain += 12
    elif num(risk_score_val) > 25: onchain -= min(28, (num(risk_score_val) - 20) * 1.1)
    if top10 >= 70: onchain -= 32
    elif top10 >= 50: onchain -= 20
    elif top10 >= 35: onchain -= 10
    top1 = num(risk_details.get("topHolderPct", risk_details.get("top_holder_pct")), 0)
    if top1 >= 25: onchain -= 20
    elif top1 >= 15: onchain -= 10
    if lp_lock is not None:
        if num(lp_lock) < 10: onchain -= 22
        elif num(lp_lock) < 30: onchain -= 12
        elif num(lp_lock) >= 80: onchain += 7
    if liquidity_change is not None and num(liquidity_change) <= -20: onchain -= 30
    if m.liquidity > 0 and m.market_cap > 0 and m.liquidity / m.market_cap < .025: onchain -= 12
    if num(wallet_activity.get("buys")) > num(wallet_activity.get("sells")) and num(wallet_activity.get("unique_wallets")) >= 2:
        onchain += 7
    elif num(wallet_activity.get("sells")) > num(wallet_activity.get("buys")) and num(wallet_activity.get("sells")) >= 2:
        onchain -= 12
    result["ONCHAIN"] = detail(clamp(onchain), "onchain", f"On-chain/Walet-Lens: RugCheck {('unbekannt' if risk_score_val is None else str(risk_score_val))}; Top10 {top10 or 'unbekannt'}%; LP-lock {('unbekannt' if lp_lock is None else str(lp_lock)+'%')}; beobachtete Watchlist-Signale {int(num(wallet_activity.get('buys')))} Buy-like / {int(num(wallet_activity.get('sells')))} Sell-like.",
                               {"risk_score": risk_score_val, "top10_pct": top10 or None, "top1_pct": top1 or None, "lp_locked_pct": lp_lock, "liquidity_change_pct": liquidity_change, "wallet_activity": wallet_activity})

    # CATALYST specialist evaluates public evidence only; social links are not proof of authenticity.
    catalyst = 43.0
    organic = enrich.get("organic_score")
    if organic is not None:
        if num(organic) >= 75: catalyst += 15
        elif num(organic) >= 55: catalyst += 8
        elif num(organic) < 25: catalyst -= 8
    if verified: catalyst += 8
    if len(enrich.get("socials") or []) >= 2: catalyst += 2
    social_attention = num(narrative_report.get("social_attention_score"))
    if social_attention >= 55: catalyst += 15
    elif social_attention >= 35: catalyst += 8
    elif post_count == 0: catalyst -= 6
    if post_count >= 5: catalyst += 4
    elif post_count >= 2: catalyst += 2
    if sentiment >= .25: catalyst += 6
    elif sentiment <= -.25: catalyst -= 12
    if suspect: catalyst -= 30
    result["CATALYST"] = detail(clamp(catalyst), "catalyst", f"Catalyst/Public-Evidence: Organic Score {('unbekannt' if organic is None else str(organic))}; Jupiter {enrich.get('verified_status', 'UNAVAILABLE')}; {post_count} abrufbare Posts und {len(enrich.get('socials') or [])} Social-Links. Verifizierung/Posts sind kein Beweis für eine offizielle Identität oder einen künftigen Listing-Katalysator.",
                                {"organic_score": organic, "verified_status": enrich.get("verified_status"), "post_count": post_count, "social_links": enrich.get("socials") or [], "sentiment": sentiment, "narrative": narrative[:500], "narrative_analysis": narrative_report})

    # DATA_QUALITY specialist explicitly prices missingness into the decision.
    quality = 45.0
    if num(m.price_usd) > 0: quality += 8
    if num(m.market_cap) > 0: quality += 7
    if num(m.liquidity) >= 5000: quality += 8
    if num(m.volume_5m) >= 1500: quality += 6
    if txns >= 12: quality += 6
    if risk is not None and risk_score_val is not None: quality += 12
    else: quality -= 20
    if top10 > 0: quality += 4
    if lp_lock is not None: quality += 4
    if enrich.get("organic_score") is not None: quality += 3
    if m.market_cap_is_fdv: quality -= 8
    if not enrich.get("providers"): quality -= 3
    quality = clamp(quality)
    coverage = _data_coverage(m, risk, trend, enrich)
    result["DATA_QUALITY"] = detail(quality, "data_quality", f"Daten-QA: {coverage*100:.0f}% der kritischen Felder befüllt; Markt-Cap-Quelle {'FDV-Proxy' if m.market_cap_is_fdv else 'Market-Cap-Feld'}; RugCheck {'vorhanden' if risk_score_val is not None else 'fehlt'}; Holder/LP-Daten {'teilweise vorhanden' if top10 > 0 or lp_lock is not None else 'fehlen'}.",
                                    {"coverage": coverage, "risk_data_known": risk_score_val is not None, "holder_data_known": top10 > 0, "lp_data_known": lp_lock is not None, "market_cap_is_fdv_proxy": bool(m.market_cap_is_fdv), "provider_status": enrich.get("providers", {})})
    return result


class SharedLearner:
    """Small from-scratch logistic learner; trained only on resolved 60m forecasts."""

    def __init__(self, store: SwarmStore, minimum_samples: int = 40, retrain_every: int = 20):
        self.store = store
        self.minimum_samples = minimum_samples
        self.retrain_every = retrain_every

    def predict(self, features: dict[str, float]) -> Optional[float]:
        model = self.store.model()
        if not model or int(model["trained_n"]) < self.minimum_samples or not isinstance(model.get("weights"), list):
            return None
        weights = model["weights"]
        x = [1.0] + [num(features.get(k)) for k in FEATURE_KEYS]
        if len(weights) != len(x):
            return None
        return clamp(sigmoid(sum(a*b for a, b in zip(weights, x))), 0.001, 0.999)

    def maybe_train(self) -> None:
        with self.store.lock:
            rows = self.store.conn.execute("""SELECT features_json,label_hit FROM forecasts WHERE horizon_minutes=60
                AND status='RESOLVED' AND label_hit IS NOT NULL ORDER BY resolved_at ASC""").fetchall()
        n = len(rows)
        if n < self.minimum_samples:
            return
        current = self.store.model()
        trained_n = int(current["trained_n"]) if current else 0
        expected_weights = len(FEATURE_KEYS) + 1
        old_shape = bool(current and (not isinstance(current.get("weights"), list) or len(current["weights"]) != expected_weights))
        if current and not old_shape and n < trained_n + self.retrain_every:
            return
        X: list[list[float]] = []
        y: list[float] = []
        for row in rows:
            feat = from_json(row["features_json"], {})
            X.append([1.0] + [num(feat.get(k)) for k in FEATURE_KEYS])
            y.append(float(row["label_hit"]))
        weights = [0.0] * (len(FEATURE_KEYS) + 1)
        # Batch logistic regression with L2 regularization. Normalized features keep optimization stable.
        lr, l2, epochs = 0.08, 0.025, 700
        for epoch in range(epochs):
            grads = [0.0] * len(weights)
            for x, target in zip(X, y):
                p = sigmoid(sum(a*b for a, b in zip(weights, x)))
                err = p - target
                for j, value in enumerate(x):
                    grads[j] += err * value
            scale = 1.0 / n
            for j in range(len(weights)):
                reg = 0 if j == 0 else l2 * weights[j]
                weights[j] -= lr * (grads[j] * scale + reg)
            if epoch in (199, 399):
                lr *= 0.75
        version = int(current["version"]) + 1 if current else 1
        self.store.save_model(weights, n, version)
        logging.info("Swarm learner trainiert: %d abgeschlossene 60m-Labels; Modellversion %d", n, version)


def coordinate_agency(agents: dict[str, dict[str, Any]], role_weights: dict[str, float], m: Any,
                      base_score: float, base_stage: str, risk: Optional[dict[str, Any]],
                      trend: dict[str, Any], enrich: dict[str, Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """CIO-style coordination: weighted consensus + dissent + explicit, non-negotiable gates."""
    keys = [k for k in AGENTS if k in agents]
    total_weight = sum(max(0.01, num(role_weights.get(k, 1.0))) for k in keys) or 1.0
    weighted_score = sum(num(agents[k].get("score")) * max(0.01, num(role_weights.get(k, 1.0))) for k in keys) / total_weight
    scores = [num(agents[k].get("score")) for k in keys]
    mean_score = sum(scores) / max(1, len(scores))
    disagreement = math.sqrt(sum((x - mean_score) ** 2 for x in scores) / max(1, len(scores)))
    consensus_threshold = float(cfg.get("agency_positive_agent_score", 62))
    consensus_weight = sum(max(0.01, num(role_weights.get(k, 1.0))) for k in keys if num(agents[k].get("score")) >= consensus_threshold)
    consensus = consensus_weight / total_weight
    coverage = _data_coverage(m, risk, trend, enrich)
    confidence = clamp(coverage * 65 + consensus * 35 - max(0.0, disagreement - 18) * 0.55)

    details = (risk or {}).get("details") or {}
    risk_score = (risk or {}).get("score")
    risk_verdict = str((risk or {}).get("verdict", "UNKNOWN")).upper()
    verified_status = str(enrich.get("verified_status", "UNAVAILABLE")).upper()
    top10_raw = details.get("top10HoldersPct", details.get("topHoldersPct", details.get("top10_holders_pct")))
    holder_total_raw = details.get("totalHolders", details.get("total_holders"))
    top10 = num(top10_raw, 0.0)
    lp_lock = details.get("lpLockedPct", details.get("lp_locked_pct"))
    lp_lock_num = num(lp_lock, -1.0) if lp_lock is not None else None
    liq_change = trend.get("liquidity_change_pct")
    change5 = num(m.change_5m)
    txns = num(m.buys_5m) + num(m.sells_5m)
    buy_share = num(m.buy_share_5m)
    liq_mcap_ratio = num(m.liquidity) / num(m.market_cap) if num(m.market_cap) > 0 else 0.0
    reasons: list[str] = []
    hard_block = base_stage == "BLOCK" or risk_verdict in {"HIGH_RISK", "DANGER", "RUGGED"} or verified_status == "BANNED_OR_SUSPICIOUS"
    rugged_flag = details.get("rugged")
    if rugged_flag is True or str(rugged_flag).strip().lower() in {"1", "true", "yes"}:
        hard_block = True
        reasons.append("Sicherheitsquelle meldet bereits einen Rug")
    if num((enrich.get("jupiter_audit") or {}).get("isSus")) == 1:
        hard_block = True
        reasons.append("Jupiter audit flag isSus aktiv")
    if risk_score is not None and num(risk_score) > float(cfg.get("max_rugcheck_score", 35)):
        hard_block = True
        reasons.append(f"RugCheck-Score {num(risk_score):.0f} über hartem Basis-Limit")
    if liq_change is not None and num(liq_change) <= float(cfg.get("agency_block_liquidity_drop_pct", -35)):
        hard_block = True
        reasons.append(f"Liquidität ist seit dem vorherigen Snapshot um {num(liq_change):.1f}% gefallen")
    if top10 >= float(cfg.get("agency_block_top10_pct", 85)):
        hard_block = True
        reasons.append(f"Top-10-Holder-Konzentration extrem ({top10:.1f}%)")

    failed: list[str] = []
    def require(condition: bool, message: str) -> None:
        if not condition:
            failed.append(message)
    min_call_score = float(cfg.get("agency_call_score", cfg.get("swarm_call_score", 78)))
    min_consensus = float(cfg.get("agency_min_consensus", 0.56))
    min_coverage = float(cfg.get("agency_min_data_coverage", 0.62))
    max_disagreement = float(cfg.get("agency_max_disagreement", 25))
    max_chase = float(cfg.get("agency_max_change_5m_pct", 4.5))
    max_chase_1h = float(cfg.get("agency_max_change_1h_pct", cfg.get("narrative_max_1h_runup_pct", 12)))
    max_chase_24h = float(cfg.get("agency_max_change_24h_pct", cfg.get("narrative_max_24h_runup_pct", 35)))
    min_safety = float(cfg.get("agency_min_safety_score", 60))
    min_onchain = float(cfg.get("agency_min_onchain_score", 52))
    min_quality = float(cfg.get("agency_min_quality_score", 55))
    min_liquidity = float(cfg.get("min_liquidity_usd", 5000))
    min_volume = float(cfg.get("min_volume_5m_usd", 1500))
    min_txns = float(cfg.get("agency_min_transactions_5m", cfg.get("min_transactions_5m", 12)))
    min_buys_share = float(cfg.get("agency_min_buy_share_5m", cfg.get("min_buy_share_5m", .56)))
    max_rug = float(cfg.get("agency_max_rugcheck_score_for_call", 25))
    min_mc = float(cfg.get("min_market_cap_usd", 5000))
    max_mc = float(cfg.get("max_market_cap_usd", 150000))

    narrative_report = enrich.get("narrative_analysis") or {}
    narrative_first_path = (
        bool(cfg.get("enable_narrative_first_calls", True))
        and base_stage == "WATCH"
        and num(base_score) >= float(cfg.get("narrative_first_min_base_score", 55))
    )
    require(base_stage == "CALL" or narrative_first_path,
            "Weder klassischer CALL noch ausreichender Score für den kontrollierten Narrative-First-Pfad")
    if narrative_first_path:
        require(num(narrative_report.get("narrative_score")) >= float(cfg.get("narrative_first_min_quality_score", 68)),
                "Narrative-First-Pfad: Narrative-Qualität zu niedrig")
        require(num(narrative_report.get("social_attention_score")) >= float(cfg.get("narrative_first_min_attention_score", 55)),
                "Narrative-First-Pfad: unabhängige Social-Aufmerksamkeit zu niedrig")
        require(num(narrative_report.get("matched_posts")) >= float(cfg.get("narrative_first_min_matched_posts", 5)),
                "Narrative-First-Pfad: zu wenige konkrete Coin-Mentions")
        require(num(narrative_report.get("unique_community_authors")) >= float(cfg.get("narrative_first_min_unique_authors", 4)),
                "Narrative-First-Pfad: zu wenige unabhängige Community-Autoren")
        require(num(narrative_report.get("pre_hype_score")) >= float(cfg.get("narrative_first_min_pre_hype_score", 48)),
                "Narrative-First-Pfad: Chart-/Pre-Hype-Struktur nicht ausreichend")
        require(num(narrative_report.get("posts_last_hour")) >= float(cfg.get("narrative_first_min_posts_last_hour", 2)),
                "Narrative-First-Pfad: Community-Aktivität der letzten Stunde noch zu schwach")
        require(num(narrative_report.get("posts_last_15m")) >= float(cfg.get("narrative_first_min_posts_last_15m", 1)),
                "Narrative-First-Pfad: keine frische Erwähnung in den letzten 15 Minuten")
        require(num(narrative_report.get("attention_concentration")) <= float(cfg.get("narrative_first_max_attention_concentration", 0.75)),
                "Narrative-First-Pfad: Resonanz konzentriert sich zu stark auf einzelne Autoren")
    ensemble_score = clamp(weighted_score * 0.58 + num(base_score) * 0.30 + consensus * 100 * 0.12
                           - max(0.0, disagreement - 18) * 0.20)
    require(ensemble_score >= min_call_score, f"Koordinierter Score {ensemble_score:.1f} unter CALL-Schwelle {min_call_score:.0f}")
    require(consensus >= min_consensus, f"Team-Konsens {consensus*100:.0f}% unter {min_consensus*100:.0f}%")
    require(coverage >= min_coverage, f"Datenabdeckung {coverage*100:.0f}% unter {min_coverage*100:.0f}%")
    require(disagreement <= max_disagreement, f"Analysten widersprechen sich stark (Streuung {disagreement:.1f})")
    require(num(agents.get("SAFETY", {}).get("score")) >= min_safety, "Safety-Analyst ist nicht ausreichend positiv")
    require(num(agents.get("ONCHAIN", {}).get("score")) >= min_onchain, "On-chain-Analyst erkennt zu viele Risiken/fehlende Daten")
    require(num(agents.get("DATA_QUALITY", {}).get("score")) >= min_quality, "Datenqualität unter CALL-Schwelle")
    require(risk_score is not None and num(risk_score) <= max_rug, "RugCheck fehlt oder liegt über dem strengeren CALL-Limit")
    require(num(m.price_usd) > 0, "Preis fehlt")
    require(num(m.age_minutes) <= float(cfg.get("max_pair_age_minutes", 90)), "Pool liegt außerhalb des maximalen Frühphasen-Alters")
    require(min_mc <= num(m.market_cap) <= max_mc, "Market Cap/FDV liegt außerhalb des konfigurierten Early-Entry-Bands")
    require(num(m.liquidity) >= min_liquidity, f"Liquidität unter ${min_liquidity:,.0f}")
    require(num(m.volume_5m) >= min_volume, f"5m-Volumen unter ${min_volume:,.0f}")
    require(txns >= min_txns, f"Zu wenig beobachtete 5m-Transaktionen ({int(txns)})")
    require(buy_share >= min_buys_share, f"Buy-Anteil {buy_share*100:.0f}% unter Mindestwert")
    require(change5 <= max_chase, f"5m-Anstieg {change5:.1f}%: zu spät/überdehnt für frühen Entry")
    require(num(m.change_1h) <= max_chase_1h, f"1h-Anstieg {num(m.change_1h):.1f}%: Momentum bereits gelaufen; Anti-Chase")
    require(num(m.change_24h) <= max_chase_24h, f"24h-Anstieg {num(m.change_24h):.1f}%: Hype möglicherweise bereits eingepreist")
    require(num(m.change_24h) >= -60, f"24h-Absturz {num(m.change_24h):.1f}%: crash-/rug-ähnliche Bewegung")
    require(change5 >= -18, f"5m-Absturz {change5:.1f}%: crash-/rug-ähnliche Bewegung")
    require(num(m.change_1h) >= -45, f"1h-Absturz {num(m.change_1h):.1f}%: crash-/rug-ähnliche Bewegung")
    require(liq_change is None or num(liq_change) > float(cfg.get("agency_max_liquidity_drop_for_call_pct", -20)), "Liquidität ist merklich gefallen")
    require(top10 <= float(cfg.get("agency_max_top10_for_call_pct", 70)) or top10 <= 0, "Top-10-Konzentration über CALL-Limit")
    require(lp_lock_num is None or lp_lock_num >= float(cfg.get("agency_min_lp_lock_for_call_pct", 10)), "Gemeldeter LP-Lock unter CALL-Limit")
    require(not bool((enrich.get("jupiter_audit") or {}).get("isSus")), "Jupiter meldet verdächtiges Audit-Merkmal")
    require(verified_status != "BANNED_OR_SUSPICIOUS", "Token als gebannt/verdächtig markiert")
    # In strict mode, absent holder/LP data is not silently treated as safe.
    if bool(cfg.get("require_social_proof_for_call", True)):
        require(holder_total_raw is not None and num(holder_total_raw) > 0,
                "Holder-Daten fehlen; Konzentrationsrisiko nicht prüfbar")
        require(top10_raw is not None,
                "Top-10-Holder-Konzentration fehlt; Risiko nicht prüfbar")
        require(lp_lock_num is not None,
                "LP-Lock-Daten fehlen; Liquiditätsschutz nicht prüfbar")
        require(trend.get("volatility_pct") is not None,
                "Zu wenig lokale Chart-Historie für Volatilitätsprüfung")
        require(num(trend.get("volatility_pct"), 999) <= float(cfg.get("agency_max_volatility_for_call_pct", 35)),
                "Lokale Kursvolatilität ist für einen frühen Entry zu hoch")
        require(liq_mcap_ratio >= float(cfg.get("agency_min_liquidity_to_mcap_ratio", 0.05)),
                "Liquidität im Verhältnis zur Market Cap zu dünn")
        require(num(narrative_report.get("narrative_score")) >= float(cfg.get("narrative_min_quality_score", 58)),
                f"Narrative-Qualität {num(narrative_report.get('narrative_score')):.0f}/100 unter Schwelle")
        require(num(narrative_report.get("social_attention_score")) >= float(cfg.get("narrative_min_attention_score", 32)),
                f"Organische Aufmerksamkeit {num(narrative_report.get('social_attention_score')):.0f}/100 unter Schwelle")
        require(num(narrative_report.get("matched_posts")) >= float(cfg.get("narrative_min_matched_posts", 3)),
                "Zu wenige passende öffentliche Posts zum Coin")
        require(num(narrative_report.get("unique_community_authors")) >= float(cfg.get("narrative_min_unique_authors", 2)),
                "Zu wenige unabhängige Community-Autoren")
        require(num(narrative_report.get("independent_sources")) >= float(cfg.get("narrative_min_independent_sources", 1)),
                "Öffentliche Aufmerksamkeit nicht durch unabhängige Quelle gestützt")
        require(num(narrative_report.get("posts_last_hour")) >= float(cfg.get("narrative_min_posts_last_hour", 1)),
                "Zu wenig frische passende Community-Posts in der letzten Stunde")
        require(num(narrative_report.get("posts_last_15m")) >= float(cfg.get("narrative_min_posts_last_15m", 1)),
                "Keine frische passende Community-Erwähnung in den letzten 15 Minuten")
        require(num(narrative_report.get("attention_concentration")) <= float(cfg.get("narrative_max_attention_concentration", 0.82)),
                "Community-Aufmerksamkeit ist zu stark auf einzelne Autoren konzentriert")
        require(bool(narrative_report.get("social_api_configured")),
                "X/Reddit-Zugang fehlt: echte öffentliche Resonanz kann nicht geprüft werden")
        require(num(narrative_report.get("pre_hype_score")) >= float(cfg.get("narrative_min_pre_hype_score", 42)),
                "Pre-Hype-Setup nicht ausreichend")
        require(num(m.change_5m) <= float(cfg.get("narrative_max_5m_runup_pct", 18)),
                "Entry-Filter: 5m-Anstieg bereits zu explosiv")
        require(num(m.change_1h) <= float(cfg.get("narrative_max_1h_runup_pct", 80)),
                "Entry-Filter: 1h-Anstieg bereits zu weit gelaufen")
        require(not bool(m.market_cap_is_fdv), "Echte Market Cap fehlt; nur FDV-Proxy vorhanden")

    # Human-readable scorecard, separating measured evidence and gate failures.
    reasons.append(f"Team-Konsens {consensus*100:.0f}% ({sum(1 for v in scores if v >= consensus_threshold)}/{len(scores)} Rollen über {consensus_threshold:.0f})")
    reasons.append(f"Datenabdeckung {coverage*100:.0f}% · Dissens {disagreement:.1f}/100 · Team-Konfidenzindex {confidence:.0f}/100 (kein Gewinnwahrscheinlichkeitswert)")
    reasons.extend(f"Gate: {x}" for x in failed[:12])
    if hard_block:
        verdict = "BLOCKED"
        entry_quality = "BLOCKED_BY_RISK"
    elif not failed:
        verdict = "CALL"
        if narrative_first_path and base_stage != "CALL":
            entry_quality = "NARRATIVE_FIRST_EARLY"
        else:
            entry_quality = "EARLY_CANDIDATE" if change5 <= 12 else "MOMENTUM_ENTRY"
    elif change5 > max_chase:
        verdict = "WATCH"
        entry_quality = "CHASED"
    elif coverage < min_coverage or risk_score is None:
        verdict = "WATCH"
        entry_quality = "INSUFFICIENT_EVIDENCE"
    elif base_stage in ("CALL", "WATCH") or weighted_score >= float(cfg.get("swarm_watch_score", 58)):
        verdict = "WATCH"
        entry_quality = "DEVELOPING"
    else:
        verdict = "LOW_SIGNAL"
        entry_quality = "LOW_SIGNAL"

    return {"verdict": verdict, "entry_quality": entry_quality, "score": round(ensemble_score, 2),
            "specialist_mean": round(weighted_score, 2), "consensus": round(consensus, 4), "coverage": round(coverage, 4),
            "disagreement": round(disagreement, 2), "confidence_index": round(confidence, 2),
            "reasons": reasons, "failed_gates": failed, "hard_block": hard_block,
            "positive_agents": sum(1 for v in scores if v >= consensus_threshold), "agents_total": len(scores),
            "liquidity_to_marketcap": round(liq_mcap_ratio, 5), "market_cap_source": "FDV_PROXY" if m.market_cap_is_fdv else "MARKET_CAP_FIELD"}


class WebPushManager:
    """Persistent Web Push subscriptions and delivery for installed PWA clients."""
    def __init__(self, root: Path, data_root: Optional[Path] = None):
        self.root = Path(root)  # static app files and VAPID private key
        self.data_root = Path(data_root or root)
        self.data_root.mkdir(parents=True, exist_ok=True)
        self.path = self.data_root / "r1h_push_subscriptions.json"
        self.lock = threading.RLock()
        self.public_key = os.getenv("PUSH_VAPID_PUBLIC_KEY", "").strip()
        raw_private = os.getenv("PUSH_VAPID_PRIVATE_KEY_PATH", "vapid_private.pem").strip()
        private_path = Path(raw_private)
        self.private_key = private_path if private_path.is_absolute() else self.root / private_path
        self.contact = os.getenv("PUSH_CONTACT", "mailto:admin@example.com").strip()
        self._warned_unconfigured = False
        self._subscriptions: dict[str, dict[str, Any]] = {}
        self._load()

    @property
    def enabled(self) -> bool:
        return bool(self.public_key and self.private_key.is_file())

    def _load(self) -> None:
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(payload, list):
                self._subscriptions = {
                    str(x.get("endpoint")): x for x in payload
                    if isinstance(x, dict) and isinstance(x.get("endpoint"), str)
                    and x.get("endpoint", "").startswith("https://")
                    and isinstance(x.get("keys"), dict)
                }
        except FileNotFoundError:
            return
        except (OSError, json.JSONDecodeError) as exc:
            logging.warning("Web-Push-Abonnements konnten nicht geladen werden (%s).", type(exc).__name__)

    def _save(self) -> None:
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(list(self._subscriptions.values()), ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.path)

    def subscribe(self, subscription: Any) -> tuple[bool, str]:
        if not self.enabled:
            return False, "Push ist nicht konfiguriert. VAPID-Schlüssel fehlen."
        if not isinstance(subscription, dict):
            return False, "Ungültiges Abonnement."
        endpoint = subscription.get("endpoint")
        keys = subscription.get("keys")
        if not isinstance(endpoint, str) or not endpoint.startswith("https://") or not isinstance(keys, dict):
            return False, "Das Abonnement enthält keine gültige HTTPS-Adresse oder Schlüssel."
        if not keys.get("p256dh") or not keys.get("auth"):
            return False, "Das Abonnement enthält erforderliche Verschlüsselungsschlüssel nicht."
        clean = {"endpoint": endpoint, "keys": {"p256dh": str(keys["p256dh"]), "auth": str(keys["auth"])}}
        with self.lock:
            self._subscriptions[endpoint] = clean
            self._save()
            count = len(self._subscriptions)
        logging.info("Web-Push-Abonnement gespeichert (aktive Geräte: %d).", count)
        return True, "Push-Benachrichtigungen sind für dieses Gerät aktiviert."

    def unsubscribe(self, endpoint: str) -> None:
        with self.lock:
            if endpoint in self._subscriptions:
                del self._subscriptions[endpoint]
                self._save()

    def send(self, payload: dict[str, Any]) -> tuple[int, int]:
        if not self.enabled:
            if not self._warned_unconfigured:
                logging.warning("Web-Push nicht gesendet: VAPID-Schlüssel sind nicht konfiguriert.")
                self._warned_unconfigured = True
            return 0, 0
        try:
            from pywebpush import webpush, WebPushException
        except ImportError:
            logging.error("Web-Push nicht verfügbar: pywebpush ist nicht installiert. install.bat erneut ausführen.")
            return 0, 0
        with self.lock:
            subscriptions = list(self._subscriptions.values())
        ok, failed, expired = 0, 0, []
        encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        for sub in subscriptions:
            try:
                webpush(
                    subscription_info=sub,
                    data=encoded,
                    vapid_private_key=str(self.private_key),
                    vapid_claims={"sub": self.contact or "mailto:admin@example.com"},
                    ttl=60,
                    timeout=8,
                )
                ok += 1
            except WebPushException as exc:
                failed += 1
                status = getattr(getattr(exc, "response", None), "status_code", None)
                if status in (404, 410):
                    expired.append(sub.get("endpoint", ""))
                logging.warning("Web-Push-Zustellung fehlgeschlagen (HTTP %s).", status or "unknown")
            except Exception as exc:
                failed += 1
                logging.warning("Web-Push-Zustellung fehlgeschlagen (%s).", type(exc).__name__)
        for endpoint in expired:
            self.unsubscribe(endpoint)
        return ok, failed

    def notify_call(self, token: dict[str, Any]) -> None:
        name = str(token.get("symbol") or token.get("name") or "New coin")[:80]
        mint = str(token.get("mint") or "")
        mcap = token.get("market_cap")
        score = token.get("score")
        mcap_text = "MC n/a" if not isinstance(mcap, (int, float)) else f"MC ${mcap:,.0f}"
        score_text = "Score n/a" if not isinstance(score, (int, float)) else f"Score {score:.0f}/100"
        short = mint[:5] + "…" + mint[-5:] if len(mint) > 14 else mint
        payload = {
            "title": f"🚨 R1_H CALL: {name}",
            "body": f"{mcap_text} · {score_text} · {short}",
            "url": "/?mint=" + urllib.parse.quote(mint, safe=""),
            "tag": "r1h-call-" + (mint or str(time.time())),
            "data": {"mint": mint},
        }
        ok, failed = self.send(payload)
        logging.info("Web-Push CALL: delivered=%d failed=%d subscriptions=%d", ok, failed, ok + failed)


class SwarmEngine:
    def __init__(self, cfg: dict[str, Any], root: Path):
        self.cfg = cfg
        self.root = root
        self.data_root = Path(os.getenv("R1H_DATA_DIR", str(root))).resolve()
        self.data_root.mkdir(parents=True, exist_ok=True)
        self.store = SwarmStore(self.data_root / "sharky_swarm.sqlite3")
        self.web_push = WebPushManager(root, self.data_root)
        self.session_secret = self._load_session_secret()
        self.app_password = os.getenv("R1H_APP_PASSWORD", "").strip()
        self.enrichment = ExternalEnrichment(cfg, self.store)
        self.learner = SharedLearner(self.store, int(cfg.get("learner_min_samples", 40)), int(cfg.get("learner_retrain_every", 20)))
        self.server: Optional[ThreadingHTTPServer] = None
        self._last_csv_export = 0.0
        self._last_prune = 0.0
        self._last_processed: dict[str, float] = {}
        self._wallet_thread_started = False
        self._wallet_cursor = 0

    def _load_session_secret(self) -> bytes:
        configured = os.getenv("R1H_SESSION_SECRET", "").strip()
        if configured:
            return configured.encode("utf-8")
        path = self.data_root / ".r1h_session_secret"
        try:
            if path.exists():
                value = path.read_bytes().strip()
                if value:
                    return value
            value = secrets.token_urlsafe(48).encode("ascii")
            path.write_bytes(value)
            try:
                path.chmod(0o600)
            except OSError:
                pass
            return value
        except OSError:
            return secrets.token_bytes(48)

    def make_session_cookie(self) -> str:
        expires = int(time.time()) + 7 * 24 * 3600
        nonce = secrets.token_urlsafe(18)
        content = f"{expires}.{nonce}"
        signature = hmac.new(self.session_secret, content.encode(), hashlib.sha256).hexdigest()
        return f"{content}.{signature}"

    def valid_session_cookie(self, raw: str) -> bool:
        try:
            expires_s, nonce, signature = raw.split(".", 2)
            expires = int(expires_s)
            if expires < int(time.time()) or expires > int(time.time()) + 8 * 24 * 3600:
                return False
            content = f"{expires_s}.{nonce}"
            expected = hmac.new(self.session_secret, content.encode(), hashlib.sha256).hexdigest()
            return hmac.compare_digest(signature, expected)
        except (ValueError, TypeError):
            return False

    def is_loopback_client(self, address: str) -> bool:
        return address in {"127.0.0.1", "::1", "::ffff:127.0.0.1"}

    def api_is_authorized(self, cookie_header: str, client_address: str) -> bool:
        if not self.app_password:
            return self.is_loopback_client(client_address)
        cookie = ""
        for part in (cookie_header or "").split(";"):
            name, _, value = part.strip().partition("=")
            if name == "r1h_session":
                cookie = value
                break
        return bool(cookie and self.valid_session_cookie(cookie))

    def start_dashboard(self) -> None:
        if self.server:
            return
        host = str(self.cfg.get("dashboard_host", "127.0.0.1"))
        port = int(self.cfg.get("dashboard_port", 8765))
        public_mode = os.getenv("R1H_PUBLIC_HOSTING", "").strip().lower() in {"1", "true", "yes"}
        if (host not in {"127.0.0.1", "localhost", "::1"} or public_mode) and not self.app_password:
            logging.error("Dashboard verweigert öffentliche/PWA-Bindung: R1H_APP_PASSWORD muss gesetzt sein.")
            return
        handler = self._handler_class()
        try:
            self.server = ThreadingHTTPServer((host, port), handler)
            self.server.daemon_threads = True
            thread = threading.Thread(target=self.server.serve_forever, name="r1_h-dashboard", daemon=True)
            thread.start()
            logging.info("R1_H-Dashboard aktiv: %s:%d", host, port)
            self.start_wallet_watcher()
        except OSError as exc:
            logging.warning("Dashboard konnte Port %d nicht binden: %s", port, exc)
            self.server = None

    def _configured_wallets(self) -> list[tuple[str, str]]:
        path = self.data_root / "tracked_wallets.txt"
        if not path.exists():
            return []
        wallets: list[tuple[str, str]] = []
        try:
            for raw in path.read_text(encoding="utf-8").splitlines():
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                parts = [x.strip() for x in line.split(",", 1)]
                address = parts[0]
                label = parts[1] if len(parts) > 1 and parts[1] else address[:6] + "…" + address[-4:]
                if re.fullmatch(r"[1-9A-HJ-NP-Za-km-z]{32,44}", address):
                    wallets.append((address, label))
        except OSError as exc:
            logging.warning("tracked_wallets.txt konnte nicht gelesen werden: %s", exc)
        return wallets

    def start_wallet_watcher(self) -> None:
        if self._wallet_thread_started or not os.getenv("HELIUS_API_KEY", "").strip() or not self._configured_wallets():
            return
        self._wallet_thread_started = True
        def loop() -> None:
            interval = max(60, int(self.cfg.get("wallet_poll_seconds", 120)))
            while True:
                try:
                    self.refresh_wallet_activity()
                except Exception:
                    logging.exception("Watchlist wallet refresh failed")
                time.sleep(interval)
        threading.Thread(target=loop, name="r1_h-wallet-watcher", daemon=True).start()
        logging.info("J7-inspirierte Helius-Wallet-Watchlist aktiv: %d Adressen", len(self._configured_wallets()))

    def refresh_wallet_activity(self) -> None:
        wallets = self._configured_wallets()
        if not wallets or not os.getenv("HELIUS_API_KEY", "").strip():
            return
        max_wallets = max(1, min(int(self.cfg.get("max_wallets_per_poll", 5)), len(wallets)))
        selected = [wallets[(self._wallet_cursor + i) % len(wallets)] for i in range(max_wallets)]
        self._wallet_cursor = (self._wallet_cursor + max_wallets) % len(wallets)
        for address, label in selected:
            transactions = self.enrichment.wallet_transactions(address, limit=25)
            if not transactions:
                continue
            for tx in transactions:
                if not isinstance(tx, dict):
                    continue
                # Helius getTransfersByAddress returns one transfer per row (mint/from/to/blockTime),
                # while the older Enhanced Transactions endpoint nests transfers in tokenTransfers.
                signature = str(tx.get("signature") or tx.get("transactionSignature") or "")
                stamp = num(tx.get("timestamp") or tx.get("blockTime"))
                if not signature or stamp <= 0:
                    continue
                observed = datetime.fromtimestamp(stamp, timezone.utc).isoformat(timespec="seconds")
                tx_type = str(tx.get("type") or tx.get("source") or "UNKNOWN").upper()
                description = str(tx.get("description") or "")
                is_swap = tx_type == "SWAP" or "swap" in description.lower()
                transfers = [tx] if tx.get("mint") else (tx.get("tokenTransfers") or [])
                for transfer in transfers:
                    if not isinstance(transfer, dict):
                        continue
                    mint = str(transfer.get("mint") or "")
                    if not mint or mint in {
                        "So11111111111111111111111111111111111111112",
                        "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
                        "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
                    }:
                        continue
                    incoming = str(transfer.get("toUserAccount") or "") == address
                    outgoing = str(transfer.get("fromUserAccount") or "") == address
                    if incoming and not outgoing:
                        direction = "BUY_LIKE" if is_swap else "INBOUND"
                    elif outgoing and not incoming:
                        direction = "SELL_LIKE" if is_swap else "OUTBOUND"
                    else:
                        continue
                    amount = num(transfer.get("uiAmount") or transfer.get("tokenAmount") or transfer.get("amount"), 0.0)
                    self.store.add_wallet_signal(signature, address, label, mint, direction, amount, observed, description, tx_type)

    def notify_call(self, mint: str, name: str, symbol: str, market_cap: float, score: float) -> None:
        """Notify subscribed PWA devices after a unique CALL clears all scanner gates."""
        self.web_push.notify_call({
            "mint": mint, "name": name, "symbol": symbol,
            "market_cap": market_cap, "score": score,
        })

    def _handler_class(self):
        engine = self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt: str, *args: Any) -> None:
                logging.debug("Dashboard: " + fmt, *args)

            def _send(self, code: int, body: bytes, content_type: str, extra_headers: Optional[dict[str, str]] = None) -> None:
                self.send_response(code)
                self.send_header("Content-Type", content_type)
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Referrer-Policy", "same-origin")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("Content-Length", str(len(body)))
                for key, value in (extra_headers or {}).items():
                    self.send_header(key, value)
                self.end_headers()
                self.wfile.write(body)

            def _json(self, code: int, data: Any, extra_headers: Optional[dict[str, str]] = None) -> None:
                self._send(code, safe_json(data).encode("utf-8"), "application/json; charset=utf-8", extra_headers)

            def _authorized(self) -> bool:
                return engine.api_is_authorized(self.headers.get("Cookie", ""), self.client_address[0])

            def _read_json(self) -> dict[str, Any]:
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    if length < 1 or length > 128_000:
                        return {}
                    payload = json.loads(self.rfile.read(length).decode("utf-8"))
                    return payload if isinstance(payload, dict) else {}
                except (ValueError, UnicodeDecodeError):
                    return {}

            def do_GET(self) -> None:  # noqa: N802
                parsed = urllib.parse.urlparse(self.path)
                if parsed.path in {"/", "/index.html"}:
                    # index.html is the canonical GitHub/PWA entry point. Keep dashboard.html
                    # as a legacy fallback so older project copies still start after upgrading.
                    file = engine.root / "index.html"
                    if not file.is_file():
                        file = engine.root / "dashboard.html"
                    try:
                        payload = file.read_bytes()
                    except OSError:
                        payload = b"R1_H index.html not found. Re-extract the complete package."
                        self._send(500, payload, "text/plain; charset=utf-8")
                        return
                    self._send(200, payload, "text/html; charset=utf-8")
                elif parsed.path == "/dashboard.html":
                    # Legacy route retained for links from earlier versions.
                    file = engine.root / "dashboard.html"
                    try:
                        payload = file.read_bytes()
                    except OSError:
                        payload = b"R1_H legacy dashboard file not found."
                        self._send(404, payload, "text/plain; charset=utf-8")
                        return
                    self._send(200, payload, "text/html; charset=utf-8")
                elif parsed.path in {"/manifest.webmanifest", "/manifest.json"}:
                    file = engine.root / "manifest.webmanifest"
                    try:
                        self._send(200, file.read_bytes(), "application/manifest+json; charset=utf-8")
                    except OSError:
                        self._send(404, b"{}", "application/json; charset=utf-8")
                elif parsed.path == "/sw.js":
                    try:
                        self._send(200, (engine.root / "sw.js").read_bytes(), "application/javascript; charset=utf-8", {"Service-Worker-Allowed": "/"})
                    except OSError:
                        self._send(404, b"", "text/plain; charset=utf-8")
                elif parsed.path.startswith("/icons/"):
                    name = parsed.path.removeprefix("/icons/")
                    if name not in {"icon-192.png", "icon-512.png", "apple-touch-icon.png", "icon.svg"}:
                        self._send(404, b"", "text/plain; charset=utf-8")
                        return
                    file = engine.root / "icons" / name
                    try:
                        ctype = "image/png" if name.endswith(".png") else "image/svg+xml"
                        self._send(200, file.read_bytes(), ctype)
                    except OSError:
                        self._send(404, b"", "text/plain; charset=utf-8")
                elif parsed.path == "/api/auth/status":
                    authorized = engine.api_is_authorized(self.headers.get("Cookie", ""), self.client_address[0])
                    # Auth is required whenever a password is configured. On local-only setups
                    # loopback is allowed without login. Non-loopback mode is refused at startup without a password.
                    self._json(200, {"required": bool(engine.app_password), "authenticated": authorized})
                elif parsed.path.startswith("/api/") and not self._authorized():
                    self._json(401, {"error": "authentication_required"})
                elif parsed.path == "/api/summary":
                    self._json(200, engine.summary())
                elif parsed.path == "/api/rooms":
                    query = urllib.parse.parse_qs(parsed.query)
                    try:
                        limit = min(500, max(1, int((query.get("limit") or ["250"])[0])))
                    except ValueError:
                        limit = 250
                    self._json(200, engine.store.all_rooms(limit))
                elif parsed.path == "/api/room":
                    query = urllib.parse.parse_qs(parsed.query)
                    mint = (query.get("mint") or [""])[0]
                    detail = engine.store.room_detail(mint)
                    self._json(200 if detail else 404, detail if detail else {"error": "room_not_found"})
                elif parsed.path == "/api/metrics":
                    self._json(200, engine.metrics())
                elif parsed.path == "/api/push/public-key":
                    self._json(200, {"enabled": engine.web_push.enabled, "publicKey": engine.web_push.public_key if engine.web_push.enabled else ""})
                else:
                    self._json(404, {"error": "not_found"})

            def do_POST(self) -> None:  # noqa: N802
                parsed = urllib.parse.urlparse(self.path)
                body = self._read_json()
                if parsed.path == "/api/auth/login":
                    given = str(body.get("password") or "")
                    if not engine.app_password:
                        self._json(200, {"ok": True, "message": "Lokaler Modus: Passwortschutz ist nicht aktiviert."})
                        return
                    if not hmac.compare_digest(given, engine.app_password):
                        self._json(403, {"ok": False, "error": "Falsches Passwort."})
                        return
                    cookie = "r1h_session=" + engine.make_session_cookie() + "; Path=/; HttpOnly; SameSite=Strict; Max-Age=604800"
                    if self.headers.get("X-Forwarded-Proto", "").lower() == "https":
                        cookie += "; Secure"
                    self._json(200, {"ok": True}, {"Set-Cookie": cookie})
                    return
                if parsed.path == "/api/auth/logout":
                    self._json(200, {"ok": True}, {"Set-Cookie": "r1h_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"})
                    return
                if parsed.path.startswith("/api/") and not self._authorized():
                    self._json(401, {"error": "authentication_required"})
                    return
                if parsed.path == "/api/push/subscribe":
                    ok, message = engine.web_push.subscribe(body.get("subscription"))
                    self._json(200 if ok else 400, {"ok": ok, "message": message})
                elif parsed.path == "/api/push/unsubscribe":
                    endpoint = str(body.get("endpoint") or "")
                    if endpoint.startswith("https://"):
                        engine.web_push.unsubscribe(endpoint)
                    self._json(200, {"ok": True})
                elif parsed.path == "/api/push/test":
                    ok, failed = engine.web_push.send({"title": "R1_H Push-Test", "body": "Push-Benachrichtigungen sind eingerichtet.", "url": "/", "tag": "r1h-push-test"})
                    self._json(200, {"ok": ok > 0, "delivered": ok, "failed": failed, "subscriptions": ok + failed})
                else:
                    self._json(404, {"error": "not_found"})
        return Handler

    def local_ollama_review(self, m: Any, base_score: float, risk: Optional[dict[str, Any]],
                           trend: dict[str, Any], enrich: dict[str, Any], reasons: list[str]) -> Optional[dict[str, Any]]:
        """Optional local LLM review via Ollama. No hosted API key required, but user must run a model locally."""
        model_name = os.getenv("OLLAMA_MODEL", "").strip()
        if not model_name or base_score < float(self.cfg.get("local_ai_min_score", 55)):
            return None
        ttl = int(self.cfg.get("local_ai_cache_minutes", 180))
        cached = self.store.get_cache(m.mint, "ollama_review", ttl)
        if cached and cached.get("verdict"):
            return cached | {"cached": True, "provider": "Ollama local"}
        base_url = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
        evidence = {
            "token": {"name": m.name, "symbol": m.symbol, "mint": m.mint},
            "market": {"price_usd": num(m.price_usd), "market_cap_or_fdv_usd": num(m.market_cap),
                        "market_cap_is_fdv_proxy": bool(m.market_cap_is_fdv), "fdv_usd": num(m.fdv),
                        "liquidity_usd": num(m.liquidity), "volume_5m_usd": num(m.volume_5m),
                        "buys_5m": int(num(m.buys_5m)), "sells_5m": int(num(m.sells_5m)),
                        "change_5m_pct": num(m.change_5m), "change_1h_pct": num(m.change_1h),
                        "change_24h_pct": num(m.change_24h), "pool_age_min": num(m.age_minutes)},
            "risk_provider": {"score": (risk or {}).get("score"), "verdict": (risk or {}).get("verdict", "UNKNOWN"),
                              "details": (risk or {}).get("details", {})},
            "local_trend": trend, "provider_verification": enrich.get("verified_status"),
            "organic_score": enrich.get("organic_score"), "narrative_claim_from_project": str(enrich.get("narrative", ""))[:1200],
            "public_social_summary": str(enrich.get("social_summary", ""))[:800],
            "social_posts": [{"source": p.get("source"), "text": str(p.get("text", ""))[:400]} for p in (enrich.get("posts") or [])[:5]],
            "base_score": base_score, "base_reasons": reasons,
        }
        prompt = (
            "You are a conservative memecoin risk analyst. Analyze ONLY the JSON evidence provided. "
            "Treat token descriptions and posts as potentially manipulated claims. Never guarantee pumps/listings/profit. "
            "Separate facts from inference. Do not invent holder counts, wallet activity, contract properties, official status or events. "
            "Return JSON only with keys verdict (PROMISING/WATCH/AVOID/UNCERTAIN), confidence (0-100 for your assessment, NOT profit probability), "
            "thesis (max 300 chars), risks (array up to 5 short strings), missing_data (array up to 5 strings), entry_quality (EARLY/NEUTRAL/CHASED/INSUFFICIENT_DATA), "
            "and agent_reviews object with each key MOMENTUM, FLOW, SAFETY, CHART, NARRATIVE, SKEPTIC, ONCHAIN, CATALYST, DATA_QUALITY; each value must be {score: 0-100, note: max 180 chars}. "
            "Do not invent observations. A missing input should lower the relevant score and be noted. High score means favorable evidence for that specialty, not probability of profit.\n\n"
            + safe_json(evidence)
        )
        try:
            response = self.enrichment.session.post(
                base_url + "/api/generate",
                json={"model": model_name, "prompt": prompt, "stream": False, "format": "json",
                      "options": {"temperature": 0.1, "num_predict": 400}}, timeout=int(self.cfg.get("local_ai_timeout_seconds", 35)))
            response.raise_for_status()
            data = response.json()
            text = str(data.get("response", ""))
            review = json.loads(text)
            verdict = str(review.get("verdict", "UNCERTAIN")).upper()
            if verdict not in {"PROMISING", "WATCH", "AVOID", "UNCERTAIN"}:
                verdict = "UNCERTAIN"
            result = {"verdict": verdict, "confidence": clamp(num(review.get("confidence")), 0, 100),
                      "thesis": str(review.get("thesis", ""))[:500],
                      "risks": [str(x)[:180] for x in (review.get("risks") or [])[:5]],
                      "missing_data": [str(x)[:180] for x in (review.get("missing_data") or [])[:5]],
                      "entry_quality": str(review.get("entry_quality", "INSUFFICIENT_DATA")),
                      "agent_reviews": {str(k).upper(): {"score": clamp(num((v or {}).get("score")), 0, 100), "note": str((v or {}).get("note", ""))[:260]}
                                        for k, v in (review.get("agent_reviews") or {}).items() if isinstance(v, dict)},
                      "provider": "Ollama local", "model": model_name, "cached": False}
            self.store.put_cache(m.mint, "ollama_review", result)
            return result
        except (requests.RequestException, ValueError, TypeError) as exc:
            logging.debug("Local Ollama review unavailable for %s: %s", m.mint, exc)
            return {"verdict": "UNCERTAIN", "confidence": 0, "thesis": "Lokales Ollama-Modell nicht erreichbar oder ungültige JSON-Antwort.",
                    "risks": [], "missing_data": ["Ollama ist lokal nicht erreichbar; Rollen-Analysen laufen weiter."],
                    "entry_quality": "INSUFFICIENT_DATA", "provider": "Ollama local", "cached": False}

    def _apply_llm_agent_review(self, agents: dict[str, dict[str, Any]], review: Optional[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        """Blend validated, optional LLM specialist opinions into local scores without bypassing gates."""
        if not isinstance(review, dict):
            return agents
        specialist_reviews = review.get("agent_reviews") or {}
        if not isinstance(specialist_reviews, dict):
            return agents
        blend = clamp(num(self.cfg.get("llm_agent_score_blend", 0.20)), 0.0, 0.35)
        for role in AGENTS:
            item = specialist_reviews.get(role)
            if not isinstance(item, dict) or role not in agents:
                continue
            try:
                llm_score = float(item.get("score"))
            except (TypeError, ValueError):
                continue
            if not math.isfinite(llm_score) or not 0 <= llm_score <= 100:
                continue
            local_score = num(agents[role].get("score"), 50.0)
            merged_score = clamp(local_score * (1.0 - blend) + llm_score * blend)
            short_note = str(item.get("note", "")).strip()[:260]
            if short_note:
                agents[role]["note"] = (str(agents[role].get("note", "")) + " | KI-Zweitmeinung: " + short_note)[:850]
            agents[role]["evidence"] = dict(agents[role].get("evidence") or {}) | {
                "llm_score": round(llm_score, 1), "llm_role_note": short_note,
                "llm_model": review.get("model") or review.get("provider", "optional LLM"),
                "blend_weight": blend,
            }
            agents[role]["score"] = round(merged_score, 1)
            agents[role]["verdict"] = "POSITIVE" if merged_score >= 70 else "CAUTION" if merged_score >= 50 else "NEGATIVE"
            agents[role]["probability"] = round(clamp(0.08 + merged_score / 100 * 0.68, .03, .78), 4)
        return agents

    def process(self, m: Any, base_score: float, base_stage: str, risk: Optional[dict[str, Any]],
                trend: dict[str, Any], ai_review: Optional[dict[str, Any]], reasons: list[str],
                collect_external: bool = True) -> dict[str, Any]:
        ts = iso_now()
        now_mono = time.monotonic()
        try:
            enrich = self.enrichment.enrich(m.mint, m, include_external=collect_external)
        except Exception:
            logging.exception("Enrichment failed for %s", m.mint)
            enrich = {"narrative": "Metadaten konnten gerade nicht geladen werden.", "websites": [], "socials": [],
                      "posts": [], "social_sentiment": 0, "social_summary": "Enrichment-Fehler; Social-Daten unbekannt.",
                      "verified_status": "UNAVAILABLE", "organic_score": None, "holder_count_provider": None,
                      "provider_market_cap": None, "jupiter_audit": {}, "jupiter_tags": [], "helius_metadata": {}, "providers": {}}
        wallet_activity = self.store.wallet_signal_summary(m.mint)
        enrich["wallet_activity"] = wallet_activity
        previous_room_state = self.store.room(m.mint)
        previous_metadata = from_json((previous_room_state or {}).get("metadata_json"), {})
        previous_narrative = previous_metadata.get("narrative_analysis") or {}
        previous_providers = previous_metadata.get("providers") or {}
        current_providers = enrich.get("providers") or {}
        narrative_analysis = analyze_narrative_potential(m, enrich, risk, trend, self.cfg)
        current_fetch_at = current_providers.get("external_fetched_at")
        previous_fetch_at = previous_providers.get("external_fetched_at")
        fresh_social_batch = bool(current_fetch_at and current_fetch_at != previous_fetch_at)
        if fresh_social_batch and previous_narrative:
            attention_delta = num(narrative_analysis.get("social_attention_score")) - num(previous_narrative.get("social_attention_score"))
            mentions_delta = num(narrative_analysis.get("matched_posts")) - num(previous_narrative.get("matched_posts"))
            authors_delta = num(narrative_analysis.get("unique_community_authors")) - num(previous_narrative.get("unique_community_authors"))
            narrative_analysis["attention_delta"] = round(attention_delta, 1)
            narrative_analysis["mentions_delta"] = int(mentions_delta)
            narrative_analysis["authors_delta"] = int(authors_delta)
            narrative_analysis["attention_trend"] = "rising" if attention_delta >= 5 and (mentions_delta > 0 or authors_delta > 0) else "fading" if attention_delta <= -5 else "mixed/steady"
        else:
            narrative_analysis["attention_delta"] = None
            narrative_analysis["mentions_delta"] = None
            narrative_analysis["authors_delta"] = None
            narrative_analysis["attention_trend"] = "not enough comparable provider snapshots"
        enrich["narrative_analysis"] = narrative_analysis
        verified_status = str(enrich.get("verified_status", "UNAVAILABLE"))
        features = build_features(m, risk, trend, enrich)
        agents = analyze_roles(m, base_score, base_stage, risk, trend, enrich, features)
        if ai_review is None:
            ai_review = self.local_ollama_review(m, base_score, risk, trend, enrich, reasons)
        # Optional LLM outputs are advisory notes only; the fixed safety gate below still decides.
        agents = self._apply_llm_agent_review(agents, ai_review)
        role_weights = self.store.get_role_weights()
        agency = coordinate_agency(agents, role_weights, m, base_score, base_stage, risk, trend, enrich, self.cfg)
        weighted = sum(num(agents[k]["score"]) * role_weights.get(k, 1.0) for k in AGENTS) / max(0.01, sum(role_weights.get(k, 1.0) for k in AGENTS))
        # The coordinator adds consensus and disagreement penalties to the aggregate score.
        swarm_score = clamp(weighted * 0.58 + num(base_score) * 0.30 + agency["consensus"] * 100 * 0.12
                            - max(0.0, agency["disagreement"] - 18) * 0.20)
        # Use the stricter coordinator verdict. A base scanner CALL can be downgraded to WATCH;
        # no AI text/model is permitted to override a hard safety failure.
        call_status = agency["verdict"]

        # If no trained model exists, report only an explicitly labelled heuristic estimate.
        ml_probability = self.learner.predict(features)
        # Fraction in [0.12, 0.70]; explicitly heuristic until enough outcomes train the model.
        heuristic_probability = clamp(0.12 + (swarm_score / 100) * 0.58, 0.12, 0.70)
        runner_prob = ml_probability if ml_probability is not None else heuristic_probability
        prob_type = "SHARED_MODEL" if ml_probability is not None else "HEURISTIC_NOT_CALIBRATED"
        agent_probs = {k: num(agents[k]["probability"], 0.5) for k in AGENTS}
        # Each room gets its notes continually, but repeated unchanged content is rate-limited.
        prior = previous_room_state
        force_notes = prior is None or prior.get("signal_status") != call_status or abs(num(prior.get("swarm_score")) - swarm_score) >= 8
        self.store.write_notes(m.mint, ts, agents, force=force_notes)

        risk_details = (risk or {}).get("details") or {}
        social_posts = enrich.get("posts") or []
        old_room = previous_room_state
        first_seen = (old_room or {}).get("first_seen") or ts
        room_row = {
            "mint": m.mint, "name": m.name or "Unknown", "symbol": m.symbol or "???",
            "first_seen": first_seen, "last_seen": ts, "pair_address": m.pair_address or "", "pair_url": m.dex_url or "",
            "price_usd": num(m.price_usd), "market_cap_usd": num(m.market_cap), "market_cap_is_fdv_proxy": int(bool(m.market_cap_is_fdv)),
            "fdv_usd": num(m.fdv), "liquidity_usd": num(m.liquidity), "volume_5m_usd": num(m.volume_5m),
            "buys_5m": int(num(m.buys_5m)), "sells_5m": int(num(m.sells_5m)), "buy_share_5m": num(m.buy_share_5m),
            "change_5m_pct": num(m.change_5m), "change_1h_pct": num(m.change_1h), "change_24h_pct": num(m.change_24h),
            "pool_age_min": num(m.age_minutes), "base_score": num(base_score), "swarm_score": round(swarm_score, 2),
            "runner_estimate_pct": round(runner_prob * 100, 2), "ml_probability": ml_probability,
            "probability_type": prob_type, "signal_status": call_status,
            "risk_score": (risk or {}).get("score"), "risk_verdict": (risk or {}).get("verdict", "UNKNOWN"),
            "holder_count": risk_details.get("totalHolders", enrich.get("holder_count_provider")),
            "top_holder_pct": risk_details.get("topHolderPct", risk_details.get("top_holder_pct")),
            "top10_holder_pct": risk_details.get("top10HoldersPct", risk_details.get("topHoldersPct", risk_details.get("top10_holders_pct"))),
            "lp_locked_pct": risk_details.get("lpLockedPct", risk_details.get("lp_locked_pct")),
            "verified_status": verified_status, "organic_score": enrich.get("organic_score"),
            "social_mentions_24h": len(social_posts), "social_sentiment": num(enrich.get("social_sentiment")),
            "social_summary": str(enrich.get("social_summary", ""))[:1200], "narrative": str(enrich.get("narrative", ""))[:3000],
            "watched_wallet_buys": int(num(wallet_activity.get("buys"))), "watched_wallet_sells": int(num(wallet_activity.get("sells"))),
            "watched_wallet_count": int(num(wallet_activity.get("unique_wallets"))), "wallet_signal_summary": str(wallet_activity.get("summary", ""))[:800],
            "websites_json": safe_json(enrich.get("websites") or []), "socials_json": safe_json(enrich.get("socials") or []),
            "posts_json": safe_json(social_posts[:20]), "metadata_json": safe_json({"providers": enrich.get("providers", {}),
                "jupiter_tags": enrich.get("jupiter_tags", []), "jupiter_audit": enrich.get("jupiter_audit", {}),
                "helius_metadata": enrich.get("helius_metadata", {}), "source_description_is_project_claim": True,
                "reasons": reasons, "base_stage": base_stage, "agency": agency,
                "narrative_analysis": narrative_analysis}),
            "local_chart": str(trend.get("sparkline", "")), "ai_verdict": str((ai_review or {}).get("verdict", "LOCAL_ROLES_ACTIVE")),
            "ai_confidence": (ai_review or {}).get("confidence"), "ai_thesis": str((ai_review or {}).get("thesis", ""))[:1000],
            "agent_scores_json": safe_json({k: {"score": v["score"], "verdict": v["verdict"], "note": v["note"], "evidence": v.get("evidence", {})} for k, v in agents.items()}),
            "agent_weights_json": safe_json(role_weights),
            "team_consensus": agency["consensus"], "data_coverage": agency["coverage"],
            "agent_disagreement": agency["disagreement"], "entry_quality": agency["entry_quality"],
            "agency_verdict": agency["verdict"], "decision_reasons_json": safe_json(agency["reasons"]),
            "reasons_json": safe_json(reasons), "updated_at": ts,
        }
        self.store.upsert_room(room_row)
        self.store.record_observation(m.mint, ts, num(m.price_usd), num(m.market_cap), num(m.liquidity), num(m.volume_5m),
                                      int(num(m.buys_5m)), int(num(m.sells_5m)), num(base_score), swarm_score, call_status, features)
        self.resolve_due_forecasts(m.mint, now=utc_now())
        if call_status != "BLOCKED" and num(m.price_usd) > 0 and num(m.market_cap) >= float(self.cfg.get("min_market_cap_usd", 5000)):
            for horizon, target, cooldown in ((15, .25, 15), (60, .50, 60), (360, 1.00, 360)):
                if swarm_score >= float(self.cfg.get("forecast_min_score", 45)):
                    # For 60m use trained model if available; other windows remain explicitly heuristic.
                    p = ml_probability if horizon == 60 and ml_probability is not None else heuristic_probability
                    self.store.make_forecast(m.mint, ts, horizon, target, num(m.price_usd), heuristic_probability,
                                             ml_probability if horizon == 60 else None, p, prob_type if horizon == 60 else "HEURISTIC_NOT_CALIBRATED",
                                             agent_probs, features, swarm_score, cooldown)
        self.learner.maybe_train()
        self._maybe_exports()
        # One-line persistent call notes in console only when a candidate reaches/loses CALL status.
        if call_status == "CALL" and (prior is None or prior.get("signal_status") != "CALL"):
            prob_label = f"ML {runner_prob*100:.1f}%" if ml_probability is not None else f"heuristic score {swarm_score:.1f}/100 (not calibrated)"
            logging.info("AGENCY CALL CANDIDATE | %s (%s) | MC/FDV $%.0f | LP $%.0f | Vol5m $%.0f | %s | consensus=%.0f%% | coverage=%.0f%% | CA=%s | %s",
                         m.symbol, m.name, num(m.market_cap), num(m.liquidity), num(m.volume_5m), prob_label,
                         agency["consensus"] * 100, agency["coverage"] * 100, m.mint, m.dex_url)
        elif call_status == "WATCH" and base_stage == "CALL" and (prior is None or prior.get("signal_status") != "WATCH"):
            logging.info("AGENCY DOWNGRADE TO WATCH | %s | score=%.1f | consensus=%.0f%% | coverage=%.0f%% | failed=%s",
                         m.symbol, swarm_score, agency["consensus"] * 100, agency["coverage"] * 100,
                         "; ".join(agency["failed_gates"][:3]))
        self._last_processed[m.mint] = now_mono
        return {"score": swarm_score, "status": call_status, "agents": agents, "features": features,
                "enrichment": enrich, "agency": agency, "ai_review": ai_review,
                "narrative_analysis": narrative_analysis}

    def resolve_due_forecasts(self, mint: str, now: Optional[datetime] = None) -> None:
        now = (now or utc_now()).astimezone(timezone.utc)
        forecasts = self.store.due_forecasts(mint)
        for forecast in forecasts:
            issued = parse_ts(forecast["ts"])
            due = parse_ts(forecast["due_at"])
            initial = num(forecast["initial_price"])
            if not issued or not due or now < due or initial <= 0:
                continue
            horizon = int(forecast["horizon_minutes"])
            tolerance = max(90, min(600, int(horizon * 60 * .05)))
            # Peak is strictly limited to the forecast window; no future price leaks into the label.
            window_rows = self.store.observations_for(mint, issued.isoformat(timespec="seconds"), due.isoformat(timespec="seconds"))
            peak_price = max((num(r["price"]) for r in window_rows), default=initial)
            peak_return = (peak_price / initial - 1) * 100
            nearby_end: Optional[dict[str, Any]] = None
            min_diff = None
            with self.store.lock:
                samples = self.store.conn.execute("SELECT ts,price FROM observations WHERE mint=? AND price>0", (mint,)).fetchall()
            for sample in samples:
                stamp = parse_ts(sample["ts"])
                if not stamp or abs((stamp - due).total_seconds()) > tolerance:
                    continue
                diff = abs((stamp - due).total_seconds())
                if min_diff is None or diff < min_diff:
                    min_diff, nearby_end = diff, dict(sample)
            grace = max(600, int(horizon * 60 * .25))
            if nearby_end:
                end_return = (num(nearby_end["price"]) / initial - 1) * 100
                hit = int(peak_return >= num(forecast["target_peak_return"]) * 100)
                self.store.resolve_forecast(int(forecast["id"]), "RESOLVED", now.isoformat(timespec="seconds"), peak_return,
                                            end_return, hit, nearby_end["ts"], "")
            elif now > due + timedelta(seconds=grace):
                self.store.resolve_forecast(int(forecast["id"]), "NO_DATA", now.isoformat(timespec="seconds"),
                                            None, None, None, None, "Keine Preisbeobachtung nahe dem Prognosehorizont; nicht geraten.")

    def _maybe_exports(self) -> None:
        now = time.monotonic()
        if now - self._last_csv_export < 60:
            return
        self._last_csv_export = now
        try:
            rooms = self.store.all_rooms(5000)
            if rooms:
                with (self.data_root / "coin_rooms.csv").open("w", newline="", encoding="utf-8-sig") as f:
                    fields = ["mint", "name", "symbol", "updated_at", "signal_status", "base_score", "swarm_score", "team_consensus", "data_coverage", "agent_disagreement", "entry_quality", "agency_verdict", "decision_reasons_json", "runner_estimate_pct", "ml_probability", "probability_type", "market_cap_usd", "market_cap_is_fdv_proxy", "fdv_usd", "price_usd", "liquidity_usd", "volume_5m_usd", "buys_5m", "sells_5m", "risk_score", "risk_verdict", "verified_status", "organic_score", "social_mentions_24h", "social_sentiment", "pair_url"]
                    w = csv.DictWriter(f, fieldnames=fields)
                    w.writeheader()
                    for r in rooms: w.writerow({k: r.get(k) for k in fields})
            with self.store.lock:
                note_rows = self.store.conn.execute("SELECT ts,mint,agent,score,verdict,note,evidence_json FROM agent_notes ORDER BY id DESC LIMIT 25000").fetchall()
                forecast_rows = self.store.conn.execute("SELECT * FROM forecasts ORDER BY id DESC LIMIT 50000").fetchall()
            with (self.data_root / "agent_notes.csv").open("w", newline="", encoding="utf-8-sig") as f:
                fields = ["ts", "mint", "agent", "score", "verdict", "note", "evidence_json"]
                w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows([dict(x) for x in note_rows])
            with (self.data_root / "swarm_forecasts.csv").open("w", newline="", encoding="utf-8-sig") as f:
                fields = ["id", "mint", "ts", "horizon_minutes", "target_peak_return", "initial_price", "heuristic_probability", "ml_probability", "ensemble_probability", "probability_type", "score_at_issue", "status", "due_at", "resolved_at", "peak_return_pct", "end_return_pct", "label_hit", "end_observation_ts", "no_data_reason", "agent_probabilities_json", "features_json"]
                w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows([dict(x) for x in forecast_rows])
        except OSError as exc:
            logging.warning("Swarm CSV export failed: %s", exc)

    def summary(self) -> dict[str, Any]:
        model = self.store.model()
        return {"generated_at": iso_now(), "stats": self.store.stats(),
                "model": {"trained": bool(model and int(model["trained_n"]) >= self.learner.minimum_samples),
                          "trained_n": int(model["trained_n"]) if model else 0,
                          "trained_at": model.get("trained_at") if model else None,
                          "version": int(model["version"]) if model else 0,
                          "minimum_samples": self.learner.minimum_samples,
                          "target": "+50% observed peak within 60 minutes; historical target, not guaranteed profit"},
                "agent_weights": self.store.get_role_weights(),
                "agent_performance": self.store.role_performance(),
                "roles": list(AGENTS),
                "features": list(FEATURE_KEYS),
                "agency": {"mode": "specialist-consensus", "llm_enabled": bool(os.getenv("OLLAMA_MODEL", "").strip() or os.getenv("OPENAI_API_KEY", "").strip()),
                           "note": "Specialized agent roles + shared outcome learner; calls remain blocked by hard safety gates."}}

    def metrics(self) -> dict[str, Any]:
        return self.summary()
