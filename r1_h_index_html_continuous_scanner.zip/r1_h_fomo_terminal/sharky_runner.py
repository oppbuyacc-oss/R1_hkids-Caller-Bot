#!/usr/bin/env python3
"""R1_H Runner Intel + Swarm Rooms — read-only Solana memecoin research scanner.

Read-only alerts only. It never holds keys, signs transactions, or trades.
Market discovery uses documented public APIs; security data is heuristic.
"""
from __future__ import annotations

import json
import logging
import math
import os
import queue
import sqlite3
import sys
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Optional

import requests

ROOT = Path(__file__).resolve().parent
DATA_ROOT = Path(os.getenv("R1H_DATA_DIR", str(ROOT))).resolve()
DATA_ROOT.mkdir(parents=True, exist_ok=True)
CONFIG_PATH = ROOT / "config.json"
DB_PATH = DATA_ROOT / "r1_h_runner.sqlite3"
LOG_PATH = DATA_ROOT / "r1_h_runner.log"
DEX_BASE = "https://api.dexscreener.com"
GECKO_BASE = "https://api.geckoterminal.com/api/v2"
RUGCHECK_BASE = "https://api.rugcheck.xyz/v1"
PUMPPORTAL_WS = "wss://pumpportal.fun/api/data?api-key={}"

DEFAULT_CONFIG: dict[str, Any] = {'poll_seconds': 15,
 'max_candidates_per_cycle': 150,
 'candidate_lookback_hours': 3,
 'min_market_cap_usd': 5000,
 'max_market_cap_usd': 25000,
 'min_liquidity_usd': 4000,
 'min_volume_5m_usd': 500,
 'min_transactions_5m': 6,
 'min_buys_5m': 3,
 'min_buy_share_5m': 0.52,
 'max_pair_age_minutes': 90,
 'min_signal_score': 72,
 'max_rugcheck_score': 30,
 'max_rug_checks_per_cycle': 4,
 'max_full_analysis_per_cycle': 5,
 'enable_ai_analysis': True,
 'ai_min_score': 62,
 'ai_cache_minutes': 120,
 'risk_cache_minutes': 15,
 'request_timeout_seconds': 10,
 'enable_geckoterminal': True,
 'enable_rugcheck': True,
 'enable_pumpportal_stream': True,
 'watch_alert_score': 0,
 'minimum_alert_gap_seconds': 900,
 'export_csv': True,
 'tracked_token_cap': 500,
 'min_history_for_trend_points': 2,
 'show_every_candidate': False,
 'dashboard_host': '127.0.0.1',
 'dashboard_port': 8765,
 'swarm_call_score': 80,
 'swarm_min_safety_score': 65,
 'swarm_watch_score': 58,
 'forecast_min_score': 45,
 'learner_min_samples': 60,
 'learner_retrain_every': 20,
 'max_external_calls_per_minute': 10,
 'enrichment_cache_minutes': 10,
 'jupiter_cache_minutes': 30,
 'helius_cache_minutes': 60,
 'x_cache_minutes': 5,
 'reddit_cache_minutes': 10,
 'social_min_liquidity_usd': 3000,
 'local_ai_min_score': 55,
 'local_ai_cache_minutes': 60,
 'local_ai_timeout_seconds': 35,
 'wallet_poll_seconds': 120,
 'max_wallets_per_poll': 5,
 'agency_call_score': 76,
 'agency_positive_agent_score': 65,
 'agency_min_consensus': 0.64,
 'agency_min_data_coverage': 0.72,
 'agency_max_disagreement': 21,
 'agency_max_change_5m_pct': 4.5,
 'agency_min_safety_score': 65,
 'agency_min_onchain_score': 60,
 'agency_min_quality_score': 65,
 'agency_max_rugcheck_score_for_call': 25,
 'agency_min_transactions_5m': 6,
 'agency_min_buy_share_5m': 0.54,
 'agency_block_liquidity_drop_pct': -30,
 'agency_max_liquidity_drop_for_call_pct': -15,
 'agency_block_top10_pct': 80,
 'agency_max_top10_for_call_pct': 65,
 'agency_min_lp_lock_for_call_pct': 10,
 'llm_agent_score_blend': 0.15,
 'social_scan_min_base_score': 20,
 'narrative_min_pool_age_minutes': 3,
 'narrative_max_5m_runup_pct': 4.5,
 'narrative_max_1h_runup_pct': 12,
 'narrative_min_quality_score': 62,
 'narrative_min_attention_score': 32,
 'narrative_min_matched_posts': 2,
 'narrative_min_unique_authors': 2,
 'narrative_min_independent_sources': 1,
 'narrative_min_pre_hype_score': 50,
 'require_social_proof_for_call': True,
 'candidate_watch_log_score': 55,
 'candidate_watch_log_potential': 52,
 'enable_narrative_first_calls': True,
 'narrative_first_min_base_score': 50,
 'narrative_first_min_quality_score': 65,
 'narrative_first_min_attention_score': 34,
 'narrative_first_min_matched_posts': 2,
 'narrative_first_min_unique_authors': 2,
 'narrative_first_min_pre_hype_score': 52,
 'narrative_min_posts_last_hour': 1,
 'narrative_max_attention_concentration': 0.80,
 'narrative_first_min_posts_last_hour': 1,
 'narrative_first_min_posts_last_15m': 1,
 'narrative_first_max_attention_concentration': 0.80,
 'agency_max_volatility_for_call_pct': 28,
 'agency_min_liquidity_to_mcap_ratio': 0.05,
 'narrative_min_posts_last_15m': 1,
 'early_entry_mode': True,
 'early_entry_max_market_cap_usd': 25000,
 'early_entry_max_change_24h_pct': 35,
 'agency_max_change_1h_pct': 12,
 'agency_max_change_24h_pct': 35,
 'narrative_max_24h_runup_pct': 35}

# These are quote/stable assets, not meme-token candidates.
NON_CANDIDATE_MINTS = {
    "So11111111111111111111111111111111111111112",  # wrapped SOL
    "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC
    "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",  # USDT
}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utc_now().isoformat(timespec="seconds")


def parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def number(value: Any, default: float = 0.0) -> float:
    try:
        n = float(value)
        return n if math.isfinite(n) else default
    except (TypeError, ValueError):
        return default


def short_usd(value: float) -> str:
    if value >= 1_000_000:
        return f"${value / 1_000_000:.2f}M"
    if value >= 1_000:
        return f"${value / 1_000:.1f}K"
    return f"${value:.0f}"


def mint_from_gecko_id(value: Any) -> Optional[str]:
    if not isinstance(value, str):
        return None
    prefix = "solana_"
    if value.startswith(prefix):
        mint = value[len(prefix):]
        if mint and mint not in NON_CANDIDATE_MINTS:
            return mint
    return None


@dataclass
class PairMetrics:
    mint: str
    name: str
    symbol: str
    pair_address: str
    dex_url: str
    price_usd: float
    market_cap: float
    liquidity: float
    volume_5m: float
    buys_5m: int
    sells_5m: int
    change_5m: float
    age_minutes: float
    fdv: float
    source_pair: dict[str, Any]
    market_cap_is_fdv: bool = False
    change_1h: float = 0.0
    change_24h: float = 0.0
    website_count: int = 0
    social_count: int = 0
    boosts_active: int = 0

    @property
    def txns_5m(self) -> int:
        return self.buys_5m + self.sells_5m

    @property
    def buy_share_5m(self) -> float:
        total = self.txns_5m
        return self.buys_5m / total if total else 0.0

    @property
    def volume_liquidity_ratio(self) -> float:
        return self.volume_5m / self.liquidity if self.liquidity > 0 else 0.0


def load_env_file() -> None:
    """Load simple KEY=VALUE entries from .env without requiring a dependency.

    Existing operating-system environment variables win over .env values.
    """
    env_path = ROOT / ".env"
    if not env_path.exists():
        return
    try:
        for raw_line in env_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value
    except OSError as exc:
        logging.warning(".env konnte nicht gelesen werden: %s", exc)


def load_config() -> dict[str, Any]:
    cfg = DEFAULT_CONFIG.copy()
    if CONFIG_PATH.exists():
        try:
            user_cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(user_cfg, dict):
                cfg.update(user_cfg)
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"config.json konnte nicht gelesen werden: {exc}") from exc
    # Public/PWA deployment runs behind a TLS reverse proxy (Caddy). Only allow a
    # non-loopback bind when the app password is configured; SwarmEngine checks this.
    if os.getenv("R1H_PUBLIC_HOSTING", "").strip().lower() in {"1", "true", "yes"}:
        cfg["dashboard_host"] = os.getenv("R1H_DASHBOARD_HOST", "0.0.0.0").strip() or "0.0.0.0"
    elif os.getenv("R1H_DASHBOARD_HOST", "").strip():
        cfg["dashboard_host"] = os.getenv("R1H_DASHBOARD_HOST", "").strip()
    # Early-entry safeguard: an older config.json must not silently re-enable
    # late $60k-$120k calls. Users can lower the ceiling but cannot accidentally
    # raise it above the configured early-entry cap while this mode is enabled.
    if bool(cfg.get("early_entry_mode", True)):
        cap = max(5_000.0, number(cfg.get("early_entry_max_market_cap_usd", 25_000), 25_000))
        configured_max = number(cfg.get("max_market_cap_usd", cap), cap)
        cfg["max_market_cap_usd"] = min(configured_max, cap)
    return cfg


class Store:
    def __init__(self, path: Path):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.Lock()
        self._init_db()

    def _init_db(self) -> None:
        with self.conn:
            self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS tokens (
                mint TEXT PRIMARY KEY,
                name TEXT NOT NULL DEFAULT '',
                symbol TEXT NOT NULL DEFAULT '',
                first_discovered TEXT NOT NULL,
                last_discovered TEXT NOT NULL,
                last_scanned TEXT,
                alerted INTEGER NOT NULL DEFAULT 0,
                last_score REAL,
                last_stage TEXT,
                last_price REAL,
                last_market_cap REAL,
                last_liquidity REAL,
                last_dex_url TEXT
            );
            CREATE TABLE IF NOT EXISTS snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mint TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                price REAL,
                market_cap REAL,
                liquidity REAL,
                volume_5m REAL,
                buys_5m INTEGER,
                sells_5m INTEGER,
                score REAL,
                FOREIGN KEY(mint) REFERENCES tokens(mint)
            );
            CREATE INDEX IF NOT EXISTS idx_snapshots_mint_time ON snapshots(mint,timestamp);
            CREATE TABLE IF NOT EXISTS risk_cache (
                mint TEXT PRIMARY KEY,
                checked_at TEXT NOT NULL,
                risk_score REAL,
                verdict TEXT,
                risk_json TEXT
            );
            CREATE TABLE IF NOT EXISTS scan_details (
                mint TEXT PRIMARY KEY,
                observed_at TEXT NOT NULL,
                fdv REAL,
                market_cap_is_fdv INTEGER NOT NULL DEFAULT 0,
                change_5m REAL,
                change_1h REAL,
                change_24h REAL,
                age_minutes REAL,
                website_count INTEGER,
                social_count INTEGER,
                boosts_active INTEGER,
                risk_score REAL,
                risk_verdict TEXT,
                holder_count REAL,
                top_holder_pct REAL,
                top10_pct REAL,
                lp_locked_pct REAL,
                local_change_1m REAL,
                local_change_5m REAL,
                local_change_15m REAL,
                volume_momentum_x REAL,
                liquidity_change_pct REAL,
                buy_share_delta_pp REAL,
                volatility_pct REAL,
                sparkline TEXT,
                reasons_json TEXT,
                ai_verdict TEXT,
                ai_confidence REAL,
                ai_thesis TEXT,
                FOREIGN KEY(mint) REFERENCES tokens(mint)
            );
            CREATE TABLE IF NOT EXISTS ai_reviews (
                mint TEXT PRIMARY KEY,
                checked_at TEXT NOT NULL,
                verdict TEXT NOT NULL DEFAULT 'UNCERTAIN',
                confidence REAL,
                thesis TEXT NOT NULL DEFAULT '',
                risks_json TEXT NOT NULL DEFAULT '[]',
                entry_quality TEXT NOT NULL DEFAULT '',
                raw_text TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS signals (
                mint TEXT PRIMARY KEY,
                signal_time TEXT NOT NULL,
                initial_price REAL NOT NULL,
                high_price REAL NOT NULL,
                low_price REAL NOT NULL,
                score REAL NOT NULL,
                name TEXT,
                symbol TEXT,
                market_cap REAL,
                liquidity REAL,
                price_5m REAL,
                price_15m REAL,
                price_1h REAL,
                price_6h REAL,
                price_24h REAL,
                dex_url TEXT
            );
            """)
            # Lightweight schema migrations for local databases created by earlier releases.
            existing_detail_columns = {row[1] for row in self.conn.execute("PRAGMA table_info(scan_details)")}
            for column, declaration in (("volume_momentum_x", "REAL"), ("liquidity_change_pct", "REAL"),
                                        ("buy_share_delta_pp", "REAL"), ("volatility_pct", "REAL")):
                if column not in existing_detail_columns:
                    self.conn.execute(f"ALTER TABLE scan_details ADD COLUMN {column} {declaration}")

    def discover(self, mint: str, name: str = "", symbol: str = "") -> None:
        if not mint or mint in NON_CANDIDATE_MINTS:
            return
        now = iso_now()
        with self.lock, self.conn:
            self.conn.execute("""
                INSERT INTO tokens(mint,name,symbol,first_discovered,last_discovered)
                VALUES(?,?,?,?,?)
                ON CONFLICT(mint) DO UPDATE SET
                    name=CASE WHEN excluded.name!='' THEN excluded.name ELSE tokens.name END,
                    symbol=CASE WHEN excluded.symbol!='' THEN excluded.symbol ELSE tokens.symbol END,
                    last_discovered=excluded.last_discovered
            """, (mint, name or "", symbol or "", now, now))

    def active_mints(self, lookback_hours: int, cap: int) -> list[str]:
        cutoff = (utc_now() - timedelta(hours=lookback_hours)).isoformat(timespec="seconds")
        with self.lock:
            rows = self.conn.execute("""
                SELECT mint FROM tokens
                WHERE first_discovered >= ? OR (alerted=1 AND last_scanned >= ?)
                ORDER BY alerted DESC, last_discovered DESC LIMIT ?
            """, (cutoff, (utc_now() - timedelta(hours=24)).isoformat(timespec="seconds"), cap)).fetchall()
        return [r["mint"] for r in rows]

    def scanned(self, m: PairMetrics, score: float, stage: str) -> None:
        now = iso_now()
        with self.lock, self.conn:
            self.conn.execute("""
                UPDATE tokens SET name=?,symbol=?,last_scanned=?,last_score=?,last_stage=?,
                    last_price=?,last_market_cap=?,last_liquidity=?,last_dex_url=?
                WHERE mint=?
            """, (m.name,m.symbol,now,score,stage,m.price_usd,m.market_cap,m.liquidity,m.dex_url,m.mint))
            self.conn.execute("""
                INSERT INTO snapshots(mint,timestamp,price,market_cap,liquidity,volume_5m,buys_5m,sells_5m,score)
                VALUES(?,?,?,?,?,?,?,?,?)
            """, (m.mint,now,m.price_usd,m.market_cap,m.liquidity,m.volume_5m,m.buys_5m,m.sells_5m,score))
            self._update_signal_locked(m)

    def has_alerted(self, mint: str) -> bool:
        with self.lock:
            row = self.conn.execute("SELECT alerted FROM tokens WHERE mint=?", (mint,)).fetchone()
        return bool(row and row["alerted"])

    def mark_alert(self, m: PairMetrics, score: float) -> None:
        now = iso_now()
        with self.lock, self.conn:
            self.conn.execute("UPDATE tokens SET alerted=1,last_stage='CALL' WHERE mint=?", (m.mint,))
            self.conn.execute("""
                INSERT OR IGNORE INTO signals(mint,signal_time,initial_price,high_price,low_price,score,
                    name,symbol,market_cap,liquidity,dex_url)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)
            """, (m.mint,now,m.price_usd,m.price_usd,m.price_usd,score,m.name,m.symbol,m.market_cap,m.liquidity,m.dex_url))

    def get_risk(self, mint: str, cache_minutes: int) -> Optional[dict[str, Any]]:
        cutoff = (utc_now() - timedelta(minutes=cache_minutes)).isoformat(timespec="seconds")
        with self.lock:
            row = self.conn.execute("SELECT * FROM risk_cache WHERE mint=? AND checked_at>=?", (mint,cutoff)).fetchone()
        if not row:
            return None
        try:
            details = json.loads(row["risk_json"] or "{}")
        except json.JSONDecodeError:
            details = {}
        return {"score": row["risk_score"], "verdict": row["verdict"], "details": details, "cached": True}

    def put_risk(self, mint: str, score: Optional[float], verdict: str, details: dict[str, Any]) -> None:
        with self.lock, self.conn:
            self.conn.execute("""
                INSERT INTO risk_cache(mint,checked_at,risk_score,verdict,risk_json) VALUES(?,?,?,?,?)
                ON CONFLICT(mint) DO UPDATE SET checked_at=excluded.checked_at,
                    risk_score=excluded.risk_score,verdict=excluded.verdict,risk_json=excluded.risk_json
            """, (mint,iso_now(),score,verdict,json.dumps(details,ensure_ascii=False)))

    def _update_signal_locked(self, m: PairMetrics) -> None:
        row = self.conn.execute("SELECT * FROM signals WHERE mint=?", (m.mint,)).fetchone()
        if not row:
            return
        sig_time = parse_iso(row["signal_time"])
        if not sig_time or m.price_usd <= 0 or row["initial_price"] <= 0:
            return
        elapsed = (utc_now() - sig_time).total_seconds()
        kwargs: dict[str, Any] = {
            "high_price": max(number(row["high_price"]), m.price_usd),
            "low_price": min(number(row["low_price"], m.price_usd), m.price_usd),
        }
        for col, sec in (("price_5m",300),("price_15m",900),("price_1h",3600),("price_6h",21600),("price_24h",86400)):
            if elapsed >= sec and row[col] is None:
                kwargs[col] = m.price_usd
        sets = ",".join(f"{k}=?" for k in kwargs)
        self.conn.execute(f"UPDATE signals SET {sets} WHERE mint=?", (*kwargs.values(), m.mint))

    def save_scan_detail(self, m: PairMetrics, score: float, stage: str, risk: Optional[dict[str, Any]],
                         trend: dict[str, Any], review: Optional[dict[str, Any]], reasons: list[str]) -> None:
        details = (risk or {}).get("details", {}) or {}
        top1 = details.get("topHolderPct", details.get("top_holder_pct"))
        top10 = details.get("top10HoldersPct", details.get("topHoldersPct", details.get("top10_holders_pct")))
        lp_locked = details.get("lpLockedPct", details.get("lp_locked_pct"))
        holders = details.get("totalHolders", details.get("total_holders"))
        with self.lock, self.conn:
            self.conn.execute("""
                INSERT INTO scan_details(mint,observed_at,fdv,market_cap_is_fdv,change_5m,change_1h,change_24h,
                    age_minutes,website_count,social_count,boosts_active,risk_score,risk_verdict,holder_count,
                    top_holder_pct,top10_pct,lp_locked_pct,local_change_1m,local_change_5m,local_change_15m,
                    volume_momentum_x,liquidity_change_pct,buy_share_delta_pp,volatility_pct,
                    sparkline,reasons_json,ai_verdict,ai_confidence,ai_thesis)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(mint) DO UPDATE SET observed_at=excluded.observed_at,fdv=excluded.fdv,
                    market_cap_is_fdv=excluded.market_cap_is_fdv,change_5m=excluded.change_5m,
                    change_1h=excluded.change_1h,change_24h=excluded.change_24h,age_minutes=excluded.age_minutes,
                    website_count=excluded.website_count,social_count=excluded.social_count,boosts_active=excluded.boosts_active,
                    risk_score=excluded.risk_score,risk_verdict=excluded.risk_verdict,holder_count=excluded.holder_count,
                    top_holder_pct=excluded.top_holder_pct,top10_pct=excluded.top10_pct,lp_locked_pct=excluded.lp_locked_pct,
                    local_change_1m=excluded.local_change_1m,local_change_5m=excluded.local_change_5m,
                    local_change_15m=excluded.local_change_15m,volume_momentum_x=excluded.volume_momentum_x,
                    liquidity_change_pct=excluded.liquidity_change_pct,buy_share_delta_pp=excluded.buy_share_delta_pp,
                    volatility_pct=excluded.volatility_pct,sparkline=excluded.sparkline,reasons_json=excluded.reasons_json,
                    ai_verdict=excluded.ai_verdict,ai_confidence=excluded.ai_confidence,ai_thesis=excluded.ai_thesis
            """, (m.mint, iso_now(), m.fdv, int(m.market_cap_is_fdv), m.change_5m, m.change_1h, m.change_24h,
                  m.age_minutes, m.website_count, m.social_count, m.boosts_active,
                  (risk or {}).get("score"), (risk or {}).get("verdict"), holders, top1, top10, lp_locked,
                  trend.get("change_1m"), trend.get("change_5m"), trend.get("change_15m"),
                  trend.get("volume_momentum_x"), trend.get("liquidity_change_pct"), trend.get("buy_share_delta_pp"),
                  trend.get("volatility_pct"), trend.get("sparkline"), json.dumps(reasons, ensure_ascii=False),
                  (review or {}).get("verdict"), (review or {}).get("confidence"), (review or {}).get("thesis")))

    def recent_snapshots(self, mint: str, limit: int = 40) -> list[dict[str, Any]]:
        with self.lock:
            rows = self.conn.execute(
                "SELECT timestamp,price,market_cap,liquidity,volume_5m,buys_5m,sells_5m,score "
                "FROM snapshots WHERE mint=? ORDER BY timestamp DESC LIMIT ?", (mint, limit)
            ).fetchall()
        return [dict(row) for row in rows]

    def get_ai_review(self, mint: str, cache_minutes: int) -> Optional[dict[str, Any]]:
        cutoff = (utc_now() - timedelta(minutes=cache_minutes)).isoformat(timespec="seconds")
        with self.lock:
            row = self.conn.execute(
                "SELECT * FROM ai_reviews WHERE mint=? AND checked_at>=?", (mint, cutoff)
            ).fetchone()
        if not row:
            return None
        try:
            risks = json.loads(row["risks_json"] or "[]")
        except json.JSONDecodeError:
            risks = []
        return {"verdict": row["verdict"], "confidence": row["confidence"],
                "thesis": row["thesis"], "risks": risks,
                "entry_quality": row["entry_quality"], "raw_text": row["raw_text"], "cached": True}

    def put_ai_review(self, mint: str, review: dict[str, Any]) -> None:
        with self.lock, self.conn:
            self.conn.execute("""
                INSERT INTO ai_reviews(mint,checked_at,verdict,confidence,thesis,risks_json,entry_quality,raw_text)
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(mint) DO UPDATE SET checked_at=excluded.checked_at,
                    verdict=excluded.verdict,confidence=excluded.confidence,thesis=excluded.thesis,
                    risks_json=excluded.risks_json,entry_quality=excluded.entry_quality,raw_text=excluded.raw_text
            """, (mint, iso_now(), str(review.get("verdict", "UNCERTAIN")),
                  number(review.get("confidence"), 0), str(review.get("thesis", "")),
                  json.dumps(review.get("risks", []), ensure_ascii=False),
                  str(review.get("entry_quality", "")), str(review.get("raw_text", ""))))

    def export_csv(self) -> None:
        import csv
        with self.lock:
            rows = self.conn.execute("""
                SELECT s.*, t.last_stage FROM signals s LEFT JOIN tokens t USING(mint)
                ORDER BY signal_time DESC
            """).fetchall()
        path = DATA_ROOT / "signal_outcomes.csv"
        fields = ["mint","name","symbol","signal_time","score","market_cap","liquidity","initial_price",
                  "return_5m_pct","return_15m_pct","return_1h_pct","return_6h_pct","return_24h_pct",
                  "max_return_pct","max_drawdown_pct","dex_url"]
        with path.open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for r in rows:
                record = {k: r[k] for k in ("mint","name","symbol","signal_time","score","market_cap","liquidity","initial_price","dex_url")}
                base = number(r["initial_price"])
                pairs = {"return_5m_pct":"price_5m", "return_15m_pct":"price_15m", "return_1h_pct":"price_1h",
                         "return_6h_pct":"price_6h", "return_24h_pct":"price_24h", "max_return_pct":"high_price",
                         "max_drawdown_pct":"low_price"}
                for out_col, price_col in pairs.items():
                    pval = number(r[price_col], -1)
                    record[out_col] = round((pval / base - 1) * 100, 2) if pval > 0 and base > 0 else ""
                writer.writerow(record)


class RunnerIntel:
    def __init__(self, cfg: dict[str, Any]):
        self.cfg = cfg
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "R1_H-Runner-Intel/2.0 (read-only research tool)"})
        self.store = Store(DB_PATH)
        self.live_mints: queue.Queue[str] = queue.Queue()
        self.latest_profiles: dict[str, dict[str, Any]] = {}
        self.rug_checks_this_cycle = 0
        self.rugcheck_enabled = bool(cfg.get("enable_rugcheck", True))
        self.pump_stream_running = False
        self._setup_logging()
        from swarm_intelligence import SwarmEngine
        from discord_bot import DiscordBot
        self.swarm = SwarmEngine(self.cfg, ROOT)
        self.discord = DiscordBot(ROOT)
        self.discord.set_status("Scanner gestartet; erster Scan steht noch aus.")

    def _setup_logging(self) -> None:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s | %(levelname)s | %(message)s",
            handlers=[logging.FileHandler(LOG_PATH, encoding="utf-8"), logging.StreamHandler(sys.stdout)],
        )

    def get_json(self, url: str, params: Optional[dict[str, Any]] = None, tries: int = 2) -> Any:
        for attempt in range(tries):
            try:
                response = self.session.get(url, params=params, timeout=int(self.cfg["request_timeout_seconds"]))
                if response.status_code == 429:
                    if attempt + 1 < tries:
                        time.sleep(2 + attempt * 2)
                        continue
                    logging.warning("Rate limit from %s", response.url)
                    return None
                response.raise_for_status()
                return response.json()
            except (requests.RequestException, ValueError) as exc:
                if attempt + 1 < tries:
                    time.sleep(0.8 * (attempt + 1))
                    continue
                logging.debug("Request failed for %s: %s", url, exc)
        return None

    def _read_dex_list(self, endpoint: str) -> list[dict[str, Any]]:
        data = self.get_json(f"{DEX_BASE}{endpoint}")
        if isinstance(data, list):
            return [x for x in data if isinstance(x, dict)]
        return []

    def discover(self) -> tuple[int, list[str]]:
        found: dict[str, tuple[str, str]] = {}
        self.latest_profiles = {}

        # Preserve recent profile text/links rather than discarding the strongest
        # narrative metadata before the analysis layer sees it.
        profile_endpoints = (
            "/token-profiles/latest/v1",
            "/token-profiles/recent-updates/v1",
            "/token-boosts/latest/v1",
            "/community-takeovers/latest/v1",
        )
        for endpoint in profile_endpoints:
            for item in self._read_dex_list(endpoint):
                if str(item.get("chainId", "")).lower() != "solana":
                    continue
                mint = item.get("tokenAddress")
                if not mint or mint in NON_CANDIDATE_MINTS:
                    continue
                if endpoint.startswith("/token-profiles/"):
                    self.latest_profiles[mint] = item
                found.setdefault(mint, ("", ""))

        # GeckoTerminal/Gecko on-chain DEX feed, optional. It has a public 30 calls/min ceiling.
        if self.cfg.get("enable_geckoterminal", True):
            data = self.get_json(f"{GECKO_BASE}/networks/solana/new_pools", params={"page": 1})
            if isinstance(data, dict):
                for pool in data.get("data", []) or []:
                    relationships = pool.get("relationships") or {}
                    attrs = pool.get("attributes") or {}
                    for rel_name in ("base_token",):  # base is safer than blindly using the quote side
                        rel = relationships.get(rel_name) or {}
                        ref = rel.get("data") or {}
                        mint = mint_from_gecko_id(ref.get("id"))
                        if mint:
                            found.setdefault(mint, ("", ""))

        # Optional real-time PumpPortal launch feed; no trade subscriptions, so no trade-event meter.
        while True:
            try:
                mint = self.live_mints.get_nowait()
            except queue.Empty:
                break
            if mint and mint not in NON_CANDIDATE_MINTS:
                found.setdefault(mint, ("", ""))

        now = iso_now()
        for mint, (name, symbol) in found.items():
            self.store.discover(mint, name, symbol)

        # Recheck fresh candidates and tokens already alerted so performance tracking is maintained.
        active = self.store.active_mints(int(self.cfg["candidate_lookback_hours"]), int(self.cfg["tracked_token_cap"]))
        # Keep already-signaled tokens in the batch so outcome tracking continues even
        # when fresh launches flood the discovery feed.
        priority = [mint for mint in active if self.store.has_alerted(mint)]
        merged = list(dict.fromkeys(priority + list(found.keys()) + active))
        return len(found), merged[:int(self.cfg["max_candidates_per_cycle"])]

    def start_pumpportal_stream(self) -> None:
        api_key = os.getenv("PUMPPORTAL_API_KEY", "").strip()
        if not api_key or not self.cfg.get("enable_pumpportal_stream", False):
            return
        try:
            import websocket  # provided by websocket-client
        except ImportError:
            logging.warning("PumpPortal stream requested but websocket-client is not installed.")
            return

        def run() -> None:
            self.pump_stream_running = True
            uri = PUMPPORTAL_WS.format(api_key)

            def on_open(ws: Any) -> None:
                logging.info("PumpPortal event stream connected (new tokens/migrations only).")
                ws.send(json.dumps({"method": "subscribeNewToken"}))
                ws.send(json.dumps({"method": "subscribeMigration"}))

            def on_message(ws: Any, message: str) -> None:
                try:
                    item = json.loads(message)
                    mint = item.get("mint") or item.get("tokenMint") or item.get("token_address")
                    if isinstance(mint, str) and mint:
                        self.live_mints.put(mint)
                        self.store.discover(mint, str(item.get("name", "")), str(item.get("symbol", "")))
                except (json.JSONDecodeError, AttributeError):
                    return

            def on_error(ws: Any, error: Any) -> None:
                logging.warning("PumpPortal stream error: %s", error)

            def on_close(ws: Any, code: Any, message: Any) -> None:
                logging.warning("PumpPortal stream closed (%s). It will reconnect.", code)

            while True:
                try:
                    app = websocket.WebSocketApp(uri, on_open=on_open, on_message=on_message,
                                                 on_error=on_error, on_close=on_close)
                    app.run_forever(ping_interval=20, ping_timeout=10)
                except Exception as exc:  # keep optional feed from killing scanner
                    logging.warning("PumpPortal reconnect after error: %s", exc)
                time.sleep(5)

        threading.Thread(target=run, name="pumpportal-stream", daemon=True).start()

    def get_pair_batch(self, mints: list[str]) -> list[dict[str, Any]]:
        all_pairs: list[dict[str, Any]] = []
        # The documented DEX Screener token batch accepts up to 30 token addresses.
        for start in range(0, len(mints), 30):
            batch = mints[start:start+30]
            if not batch:
                continue
            path = ",".join(batch)
            data = self.get_json(f"{DEX_BASE}/tokens/v1/solana/{path}")
            if isinstance(data, list):
                all_pairs.extend(x for x in data if isinstance(x, dict))
        return all_pairs

    def pair_metrics(self, pair: dict[str, Any]) -> Optional[PairMetrics]:
        base = pair.get("baseToken") or {}
        mint = base.get("address")
        if not mint or mint in NON_CANDIDATE_MINTS:
            return None
        created_ms = number(pair.get("pairCreatedAt"))
        age_minutes = max(0.0, (time.time() - created_ms / 1000) / 60) if created_ms > 0 else 1e9
        txn = pair.get("txns") or {}
        m5 = txn.get("m5") or {}
        vol = pair.get("volume") or {}
        liq = pair.get("liquidity") or {}
        change = pair.get("priceChange") or {}
        raw_mcap = pair.get("marketCap")
        fdv = number(pair.get("fdv"))
        mcap_missing = raw_mcap is None or number(raw_mcap) <= 0
        # Use FDV as a discovery proxy only when circulating market cap is absent;
        # every display labels that distinction so it is not mistaken for true MC.
        mcap = fdv if mcap_missing else number(raw_mcap)
        info = dict(pair.get("info") or {})
        profile = self.latest_profiles.get(mint) or {}
        if not info.get("description") and profile.get("description"):
            info["description"] = profile.get("description")
        profile_links = [x for x in (profile.get("links") or []) if isinstance(x, dict) and x.get("url")]
        merged_websites = list(info.get("websites") or [])
        merged_socials = list(info.get("socials") or [])
        for link in profile_links:
            link_type = str(link.get("type") or link.get("label") or "link").casefold()
            record = {"url": link.get("url"), "type": link_type, "label": link.get("label") or link_type}
            if any(key in link_type for key in ("website", "web", "docs", "homepage")):
                merged_websites.append(record)
            else:
                merged_socials.append(record)
        info["websites"] = merged_websites
        info["socials"] = merged_socials
        src_pair = dict(pair)
        src_pair["info"] = info
        boosts = pair.get("boosts") or {}
        return PairMetrics(
            mint=mint,
            name=str(base.get("name") or "Unknown"),
            symbol=str(base.get("symbol") or "???"),
            pair_address=str(pair.get("pairAddress") or ""),
            dex_url=str(pair.get("url") or f"https://dexscreener.com/solana/{pair.get('pairAddress','')}"),
            price_usd=number(pair.get("priceUsd")),
            market_cap=mcap,
            liquidity=number(liq.get("usd")),
            volume_5m=number(vol.get("m5")),
            buys_5m=int(number(m5.get("buys"))),
            sells_5m=int(number(m5.get("sells"))),
            change_5m=number(change.get("m5")),
            age_minutes=age_minutes,
            fdv=fdv if fdv > 0 else mcap,
            source_pair=src_pair,
            market_cap_is_fdv=mcap_missing,
            change_1h=number(change.get("h1")),
            change_24h=number(change.get("h24")),
            website_count=sum(1 for x in merged_websites if isinstance(x, dict) and x.get("url")),
            social_count=sum(1 for x in merged_socials if isinstance(x, dict) and (x.get("url") or x.get("handle"))),
            boosts_active=int(number(boosts.get("active"))),
        )

    def choose_pairs(self, raw_pairs: list[dict[str, Any]], requested: set[str]) -> dict[str, PairMetrics]:
        best: dict[str, PairMetrics] = {}
        for pair in raw_pairs:
            metrics = self.pair_metrics(pair)
            if not metrics or metrics.mint not in requested:
                continue
            # If multiple pools exist, choose the token's highest-liquidity pool.
            old = best.get(metrics.mint)
            if old is None or metrics.liquidity > old.liquidity:
                best[metrics.mint] = metrics
        return best

    def trend_metrics(self, m: PairMetrics) -> dict[str, Any]:
        """Calculate observed returns from this process's own timestamped snapshots."""
        rows = self.store.recent_snapshots(m.mint, limit=40)
        now = utc_now()
        prior = []
        complete = []
        for row in rows:
            stamp = parse_iso(row.get("timestamp"))
            price = number(row.get("price"))
            if stamp and price > 0:
                prior.append((stamp, price))
                complete.append((stamp, row))
        result: dict[str, Any] = {"change_1m": None, "change_5m": None, "change_15m": None,
                                  "volume_momentum_x": None, "liquidity_change_pct": None,
                                  "buy_share_delta_pp": None, "volatility_pct": None,
                                  "sparkline": "·", "samples": len(prior)}
        if complete:
            latest_ts, latest_row = complete[0]
            previous_volume = number(latest_row.get("volume_5m"))
            if previous_volume > 0 and m.volume_5m >= 0:
                result["volume_momentum_x"] = m.volume_5m / previous_volume
            previous_liquidity = number(latest_row.get("liquidity"))
            if previous_liquidity > 0:
                result["liquidity_change_pct"] = (m.liquidity / previous_liquidity - 1.0) * 100.0
            previous_buys = int(number(latest_row.get("buys_5m")))
            previous_sells = int(number(latest_row.get("sells_5m")))
            prev_total = previous_buys + previous_sells
            if prev_total > 0 and m.txns_5m >= 0:
                result["buy_share_delta_pp"] = (m.buy_share_5m - previous_buys / prev_total) * 100.0
            recent_prices = [price for _, price in sorted(prior, key=lambda item: item[0])[-12:]]
            returns = [(b / a - 1) * 100 for a, b in zip(recent_prices, recent_prices[1:]) if a > 0]
            if len(returns) >= 3:
                mean = sum(returns) / len(returns)
                result["volatility_pct"] = math.sqrt(sum((x - mean) ** 2 for x in returns) / len(returns))
        for label, seconds in (("change_1m", 60), ("change_5m", 300), ("change_15m", 900)):
            target = now - timedelta(seconds=seconds)
            eligible = [(ts, px) for ts, px in prior if ts <= target]
            if eligible and m.price_usd > 0:
                ts, px = max(eligible, key=lambda item: item[0])
                # Don't report stale snapshots as if they were exact short-window data.
                if (target - ts).total_seconds() <= max(240, seconds * 1.25):
                    result[label] = (m.price_usd / px - 1.0) * 100.0
        prices = [px for _, px in sorted(prior, key=lambda item: item[0])[-11:]]
        if m.price_usd > 0:
            prices.append(m.price_usd)
        if len(prices) >= 2:
            glyphs = "▁▂▃▄▅▆▇█"
            low, high = min(prices), max(prices)
            if high > low:
                result["sparkline"] = "".join(glyphs[min(7, int((p - low) / (high - low) * 7))] for p in prices)
            else:
                result["sparkline"] = glyphs[0] * min(len(prices), 12)
        return result

    @staticmethod
    def ai_text_from_response(data: dict[str, Any]) -> str:
        direct = data.get("output_text")
        if isinstance(direct, str) and direct.strip():
            return direct.strip()
        texts: list[str] = []
        for item in data.get("output", []) or []:
            if not isinstance(item, dict):
                continue
            for content in item.get("content", []) or []:
                if isinstance(content, dict) and content.get("type") == "output_text":
                    text = content.get("text")
                    if isinstance(text, str):
                        texts.append(text)
        return "\n".join(texts).strip()

    def ai_review(self, m: PairMetrics, score: float, reasons: list[str],
                  risk: Optional[dict[str, Any]], trend: dict[str, Any]) -> Optional[dict[str, Any]]:
        """Optional OpenAI review of supplied evidence only; never a profit oracle."""
        if not self.cfg.get("enable_ai_analysis", True):
            return None
        api_key = os.getenv("OPENAI_API_KEY", "").strip()
        if not api_key or score < float(self.cfg.get("ai_min_score", 65)):
            return None
        cached = self.store.get_ai_review(m.mint, int(self.cfg.get("ai_cache_minutes", 360)))
        if cached:
            return cached
        if not hasattr(self, "ai_calls_this_cycle"):
            self.ai_calls_this_cycle = 0
        if self.ai_calls_this_cycle >= int(self.cfg.get("max_full_analysis_per_cycle", 3)):
            return None
        self.ai_calls_this_cycle += 1
        risk_details = (risk or {}).get("details", {})
        payload = {
            "token": {"name": m.name, "symbol": m.symbol, "mint": m.mint},
            "market": {"market_cap_or_fdv_usd": m.market_cap, "market_cap_is_fdv_proxy": m.market_cap_is_fdv,
                       "fdv_usd": m.fdv, "price_usd": m.price_usd, "liquidity_usd": m.liquidity,
                       "volume_5m_usd": m.volume_5m, "buys_5m": m.buys_5m, "sells_5m": m.sells_5m,
                       "buy_share_5m": round(m.buy_share_5m, 4), "change_5m_pct": m.change_5m,
                       "change_1h_pct": m.change_1h, "change_24h_pct": m.change_24h,
                       "pool_age_minutes": m.age_minutes, "website_count": m.website_count,
                       "social_count": m.social_count, "active_boosts": m.boosts_active},
            "local_observed_trend": trend,
            "deterministic_score_0_100": score,
            "score_reasons": reasons,
            "rugcheck_summary": risk_details,
        }
        body = {
            "model": os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            "instructions": (
                "You are a conservative on-chain meme-token risk analyst. Analyze only evidence in the supplied JSON. "
                "Do not claim certain future price direction, upcoming exchange listings, unique buyers, holder safety, "
                "or sellability unless directly shown by fields. Separate observed facts from inference. Return only valid JSON "
                "with keys verdict (PROMISING/WATCH/AVOID/UNCERTAIN), confidence (0-100, confidence in this qualitative assessment, "
                "not probability of profit), thesis (max 240 chars), risks (array of max 5 short strings), "
                "entry_quality (EARLY/NEUTRAL/CHASED/INSUFFICIENT_DATA), and agent_reviews with keys MOMENTUM, FLOW, SAFETY, CHART, NARRATIVE, SKEPTIC, ONCHAIN, CATALYST, DATA_QUALITY. "
                "Each agent_reviews value must contain score (0-100: favorable evidence for that specialty, NOT profit probability) and note (max 180 chars). "
                "Assess momentum; buy/sell flow; security and liquidity; local chart; project narrative/social evidence; skeptical counter-case; holder/LP/wallet signals; public catalyst/social proof; and data completeness respectively. "
                "Do not invent observations. Missing evidence must be called out. A missing risk report is a major uncertainty."
            ),
            "input": json.dumps(payload, ensure_ascii=False),
            "max_output_tokens": 900,
        }
        try:
            response = self.session.post("https://api.openai.com/v1/responses", json=body,
                                         headers={"Authorization": f"Bearer {api_key}"}, timeout=20)
            response.raise_for_status()
            data = response.json()
            text = self.ai_text_from_response(data)
            parsed: dict[str, Any]
            try:
                # tolerate code fences while still validating output structure
                cleaned = text.strip()
                if cleaned.startswith("```"):
                    cleaned = cleaned.split("\n", 1)[1].rsplit("```", 1)[0].strip()
                maybe = json.loads(cleaned)
                parsed = maybe if isinstance(maybe, dict) else {}
            except (ValueError, TypeError):
                parsed = {}
            verdict = str(parsed.get("verdict", "UNCERTAIN")).upper()
            if verdict not in {"PROMISING", "WATCH", "AVOID", "UNCERTAIN"}:
                verdict = "UNCERTAIN"
            risks = parsed.get("risks", [])
            if not isinstance(risks, list):
                risks = [str(risks)]
            agent_reviews = parsed.get("agent_reviews") or {}
            if not isinstance(agent_reviews, dict):
                agent_reviews = {}
            review = {"verdict": verdict, "confidence": max(0, min(100, number(parsed.get("confidence"), 0))),
                      "thesis": str(parsed.get("thesis", "AI konnte keine strukturierte Einschätzung liefern."))[:400],
                      "risks": [str(x)[:160] for x in risks[:5]],
                      "missing_data": [str(x)[:180] for x in (parsed.get("missing_data") or [])[:5]] if isinstance(parsed.get("missing_data") or [], list) else [],
                      "entry_quality": str(parsed.get("entry_quality", "INSUFFICIENT_DATA")).upper(),
                      "agent_reviews": {str(k).upper(): {"score": max(0, min(100, number((v or {}).get("score"), 50))),
                                                          "note": str((v or {}).get("note", ""))[:260]}
                                        for k, v in agent_reviews.items() if isinstance(v, dict)},
                      "provider": "OpenAI API", "model": os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
                      "raw_text": text[:1200], "cached": False}
            self.store.put_ai_review(m.mint, review)
            return review
        except (requests.RequestException, ValueError) as exc:
            logging.debug("KI-Analyse für %s nicht verfügbar: %s", m.symbol, exc)
            return None

    @staticmethod
    def _fmt_pct(value: Optional[float]) -> str:
        return "n/a" if value is None else f"{value:+.1f}%"

    def format_candidate(self, m: PairMetrics, score: float, stage: str,
                         risk: Optional[dict[str, Any]], reasons: list[str],
                         trend: dict[str, Any], review: Optional[dict[str, Any]],
                         narrative_analysis: Optional[dict[str, Any]] = None) -> str:
        mc_label = "FDV-proxy" if m.market_cap_is_fdv else "MC"
        risk_score = (risk or {}).get("score")
        risk_text = f"{number(risk_score):.0f}/100" if risk_score is not None else "UNKNOWN"
        details = (risk or {}).get("details", {})
        top10 = details.get("topHoldersPct", details.get("top10HoldersPct", details.get("top10_holders_pct")))
        top1 = details.get("topHolderPct", details.get("top_holder_pct"))
        lp_locked = details.get("lpLockedPct", details.get("lp_locked_pct"))
        holders = details.get("totalHolders", details.get("total_holders"))
        spark = trend.get("sparkline", "·")
        review_text = "KI: nicht konfiguriert" if not os.getenv("OPENAI_API_KEY", "").strip() else "KI: nicht ausgeführt"
        if review:
            review_text = f"KI: {review.get('verdict','UNCERTAIN')} {number(review.get('confidence')):.0f}/100 · {review.get('entry_quality','')}: {review.get('thesis','')[:170]}"
        lines = [
            f"[{stage:<8}] {score:5.1f}/100 | {m.symbol} — {m.name}",
            f"  CA: {m.mint}",
            f"  {mc_label}: {short_usd(m.market_cap)} | FDV: {short_usd(m.fdv)} | Preis: ${m.price_usd:.10g}",
            f"  Liquidität: {short_usd(m.liquidity)} | Vol 5m: {short_usd(m.volume_5m)} | Vol/Liq: {m.volume_liquidity_ratio:.2f}x",
            f"  Käufe/Verkäufe 5m: {m.buys_5m}/{m.sells_5m} | Buy-Anteil: {m.buy_share_5m*100:.0f}% | TX: {m.txns_5m}",
            f"  Bewegung: 5m {m.change_5m:+.1f}% | 1h {m.change_1h:+.1f}% | 24h {m.change_24h:+.1f}% | lokal 1m/5m/15m {self._fmt_pct(trend.get('change_1m'))}/{self._fmt_pct(trend.get('change_5m'))}/{self._fmt_pct(trend.get('change_15m'))}",
            f"  Chart-Verlauf: {spark} | Vol-Momentum: {str(round(number(trend['volume_momentum_x']),2))+'x' if trend.get('volume_momentum_x') is not None else 'n/a'} | Liq Δ: {self._fmt_pct(trend.get('liquidity_change_pct'))} | Pool-Alter: {m.age_minutes:.1f} min",
            f"  Links: {m.website_count} Website(s)/{m.social_count} Social(s) | Boosts: {m.boosts_active} | Buy-Anteil Δ: {('n/a' if trend.get('buy_share_delta_pp') is None else f"{number(trend.get('buy_share_delta_pp')):+.1f} Prozentpunkte")} | Volatilität: {self._fmt_pct(trend.get('volatility_pct'))}",
            f"  RugCheck: {risk_text} | Holder: {holders if holders is not None else 'n/a'} | Top Holder: {str(top1)+'%' if top1 is not None else 'n/a'} | Top10: {str(top10)+'%' if top10 is not None else 'n/a'} | LP locked: {str(lp_locked)+'%' if lp_locked is not None else 'n/a'}",
            f"  Signale: {'; '.join(reasons[:5]) if reasons else 'keine'}",
            f"  {review_text}",
            f"  Chart/DEX: {m.dex_url}",
        ]
        if narrative_analysis:
            lines.insert(-1, f"  Narrative {narrative_analysis.get('narrative_score', 'n/a')}/100 | organische Aufmerksamkeit {narrative_analysis.get('social_attention_score', 'n/a')}/100 | Pre-Hype {narrative_analysis.get('pre_hype_score', 'n/a')}/100 | Community-Posts {narrative_analysis.get('matched_posts', 0)} von {narrative_analysis.get('unique_community_authors', 0)} Autoren")
            if narrative_analysis.get("failed_gates"):
                lines.insert(-1, "  Narrative-Gates: " + "; ".join(narrative_analysis["failed_gates"][:3]))
        return "\n".join(lines)

    def preliminary_gate(self, m: PairMetrics) -> tuple[bool, str]:
        if m.market_cap <= 0:
            return False, "market cap / FDV missing"
        if bool(m.market_cap_is_fdv):
            return False, "true market cap unavailable; strict CALLs do not use FDV proxies"
        if m.market_cap < float(self.cfg["min_market_cap_usd"]) or m.market_cap > float(self.cfg["max_market_cap_usd"]):
            return False, "outside configured market-cap band"
        if m.age_minutes < float(self.cfg.get("narrative_min_pool_age_minutes", 3)):
            return False, "pool too new for minimum history window"
        if m.age_minutes > float(self.cfg["max_pair_age_minutes"]):
            return False, "pool too old"
        if m.liquidity < float(self.cfg["min_liquidity_usd"]):
            return False, "liquidity too low"
        # Filter crash/vertical-pump behavior before spending API quota on social enrichment.
        if m.change_5m > float(self.cfg.get("narrative_max_5m_runup_pct", 4.5)):
            return False, "5m move already overextended; not a pre-hype entry"
        if m.change_1h > float(self.cfg.get("narrative_max_1h_runup_pct", 12)):
            return False, "1h move already overextended; not a pre-hype entry"
        max_24h = float(self.cfg.get("narrative_max_24h_runup_pct", 35))
        if m.change_24h > max_24h:
            return False, f"24h move +{m.change_24h:.1f}% already extended; anti-chase filter"
        if m.change_24h < -60:
            return False, f"24h drawdown {m.change_24h:.1f}% too severe; crash/rug-like price action filter"
        if m.change_5m < -18 or m.change_1h < -45:
            return False, "sharp recent decline; crash/rug-like price action filter"
        if m.volume_5m < float(self.cfg["min_volume_5m_usd"]):
            return False, "5m volume too low"
        if m.txns_5m < int(self.cfg["min_transactions_5m"]):
            return False, "not enough 5m transactions"
        if m.buys_5m < int(self.cfg["min_buys_5m"]):
            return False, "not enough buys"
        if m.buy_share_5m < float(self.cfg["min_buy_share_5m"]):
            return False, "buy share too low"
        return True, "pre-filters passed"

    def rugcheck(self, mint: str) -> Optional[dict[str, Any]]:
        cached = self.store.get_risk(mint, int(self.cfg["risk_cache_minutes"]))
        if cached:
            return cached
        if not self.rugcheck_enabled or self.rug_checks_this_cycle >= int(self.cfg["max_rug_checks_per_cycle"]):
            return None
        self.rug_checks_this_cycle += 1
        data = self.get_json(f"{RUGCHECK_BASE}/tokens/{mint}/report/summary", tries=1)
        if not isinstance(data, dict):
            return None
        raw_score = data.get("score_normalised", data.get("score_normalized"))
        score: Optional[float] = None
        if raw_score is not None:
            val = number(raw_score, -1)
            if 0 <= val <= 100:
                score = val
        risks = data.get("risks") or []
        risk_levels = [str((r or {}).get("level", "")).lower() for r in risks if isinstance(r, dict)]
        risk_names = [str((r or {}).get("name") or (r or {}).get("description") or "") for r in risks if isinstance(r, dict)]
        rugged = bool(data.get("rugged", False))
        if rugged or "danger" in risk_levels or (score is not None and score > float(self.cfg["max_rugcheck_score"])):
            verdict = "HIGH_RISK"
        elif score is not None:
            verdict = "LOWER_REPORTED_RISK"
        else:
            verdict = "RISK_UNKNOWN"
        summary = {"score": score, "verdict": verdict, "rugged": rugged,
                   "risk_levels": risk_levels[:12], "risk_names": risk_names[:12],
                   "lpLockedPct": data.get("lpLockedPct", data.get("lp_locked_pct")),
                   "topHoldersPct": data.get("topHoldersPct", data.get("top10_holders_pct")),
                   "top10HoldersPct": data.get("top10HoldersPct", data.get("top10_holders_pct")),
                   "topHolderPct": data.get("topHolderPct", data.get("top_holder_pct")),
                   "totalHolders": data.get("totalHolders", data.get("total_holders")),
                   "insiderPct": data.get("insiderPct", data.get("insider_pct")),
                   "mintAuthority": data.get("mintAuthority", data.get("mint_authority_active")),
                   "freezeAuthority": data.get("freezeAuthority", data.get("freeze_authority_active")),
                   "raw": data}
        self.store.put_risk(mint, score, verdict, summary)
        return {"score": score, "verdict": verdict, "details": summary, "cached": False}

    def score(self, m: PairMetrics, risk: Optional[dict[str, Any]], trend: Optional[dict[str, Any]] = None) -> tuple[float, list[str], str]:
        """Explainable heuristic: candidate quality, not a calibrated probability of profit."""
        score = 0.0
        reasons: list[str] = []
        cfg = self.cfg
        trend = trend or {}

        early_cap = float(cfg.get("early_entry_max_market_cap_usd", 25_000))
        if 5_000 <= m.market_cap <= 12_000:
            score += 18; reasons.append("early MC $5k–$12k")
        elif 12_000 < m.market_cap <= early_cap:
            score += 12; reasons.append(f"early MC $12k–${early_cap/1000:.0f}k")
        elif m.market_cap <= 60_000:
            score += 4; reasons.append("market cap above preferred early band")
        else:
            score -= 8; reasons.append("market cap well above early-entry range")
        if m.market_cap_is_fdv:
            score -= 3; reasons.append("true market cap unavailable; using FDV proxy")

        if m.liquidity >= 25_000:
            score += 13; reasons.append("liquidity $25k+")
        elif m.liquidity >= 10_000:
            score += 10; reasons.append("liquidity $10k+")
        elif m.liquidity >= 5_000:
            score += 7; reasons.append("minimum liquidity reached")
        else:
            score -= 18; reasons.append("thin liquidity")

        if m.volume_5m >= 10_000:
            score += 12; reasons.append("strong 5m volume")
        elif m.volume_5m >= 4_000:
            score += 10; reasons.append("rising 5m volume")
        elif m.volume_5m >= float(cfg["min_volume_5m_usd"]):
            score += 6; reasons.append("minimum 5m volume reached")
        else:
            score -= 6; reasons.append("weak 5m volume")

        if m.txns_5m >= 60:
            score += 10; reasons.append("broad 5m transaction activity")
        elif m.txns_5m >= 30:
            score += 8; reasons.append("active 5m tape")
        elif m.txns_5m >= int(cfg["min_transactions_5m"]):
            score += 5
        else:
            score -= 5; reasons.append("few recent transactions")

        if m.buy_share_5m >= 0.72:
            score += 10; reasons.append("strong buy pressure")
        elif m.buy_share_5m >= 0.62:
            score += 8; reasons.append("buyers lead")
        elif m.buy_share_5m >= float(cfg["min_buy_share_5m"]):
            score += 4
        else:
            score -= 12; reasons.append("sell pressure dominates")

        max_early_5m = float(cfg.get("narrative_max_5m_runup_pct", 4.5))
        if 0.5 <= m.change_5m <= max_early_5m:
            score += 10; reasons.append("early positive move without a vertical candle")
        elif 0 < m.change_5m < 0.5:
            score += 3; reasons.append("early price discovery; momentum not yet confirmed")
        elif max_early_5m < m.change_5m <= max_early_5m * 2:
            score -= 12; reasons.append("anti-chase: early move already extended")
        elif m.change_5m > max_early_5m * 2:
            score -= 24; reasons.append("anti-chase: sharp 5m pump")
        elif m.change_5m < -8:
            score -= 10; reasons.append("negative 5m trend")

        max_early_24h = float(cfg.get("narrative_max_24h_runup_pct", 35))
        if m.change_24h > max_early_24h:
            score -= 18; reasons.append("anti-chase: 24h move already extended")
        elif m.change_24h > max_early_24h * 0.65:
            score -= 5; reasons.append("24h move elevated; entry risk increased")
        elif 0 <= m.change_24h <= 15:
            score += 3; reasons.append("24h chart still relatively early")

        observed_1m = trend.get("change_1m")
        observed_5m = trend.get("change_5m")
        observed_15m = trend.get("change_15m")
        available_returns = [x for x in (observed_1m, observed_5m, observed_15m) if isinstance(x, (int, float))]
        if len(available_returns) >= int(cfg.get("min_history_for_trend_points", 2)):
            if all(x > 0 for x in available_returns):
                score += 7; reasons.append("local multi-window trend confirms")
            elif all(x < 0 for x in available_returns):
                score -= 12; reasons.append("local multi-window trend is negative")
            elif observed_1m is not None and observed_1m < -5:
                score -= 7; reasons.append("latest local momentum rolling over")
            elif observed_1m is not None and observed_1m > 0 and (observed_5m or 0) > 0:
                score += 3; reasons.append("short-term trend improving")
        else:
            reasons.append("local chart history still building")

        ratio = m.volume_liquidity_ratio
        if 0.05 <= ratio <= 1.5:
            score += 5; reasons.append("volume/liquidity within plausible band")
        elif ratio > 4:
            score -= 12; reasons.append("volume/liquidity anomaly; possible churn")
        elif ratio > 1.5:
            score -= 3; reasons.append("high volume relative to liquidity")

        volume_momentum = trend.get("volume_momentum_x")
        if volume_momentum is not None:
            if volume_momentum >= 1.5:
                score += 5; reasons.append("5m volume expanded vs prior sample")
            elif volume_momentum <= 0.55:
                score -= 4; reasons.append("5m volume fading vs prior sample")
        liquidity_delta = trend.get("liquidity_change_pct")
        if liquidity_delta is not None:
            if liquidity_delta <= -35:
                score -= 25; reasons.append("severe observed liquidity drop")
            elif liquidity_delta <= -15:
                score -= 12; reasons.append("liquidity dropped materially since prior sample")
        if trend.get("volatility_pct") is not None and number(trend.get("volatility_pct")) > 18:
            score -= 5; reasons.append("high local price volatility")

        if 3 <= m.age_minutes <= 30:
            score += 6; reasons.append("young pool with some history")
        elif m.age_minutes < 3:
            score += 1; reasons.append("very fresh pool; insufficient history")
        elif m.age_minutes > 60:
            score -= 5; reasons.append("older pool for early-entry strategy")

        if m.website_count == 0 and m.social_count == 0:
            score -= 3; reasons.append("no website/social links reported")
        elif m.website_count > 0 and m.social_count > 0:
            score += 2; reasons.append("website and social links listed (not independently verified)")
        if m.boosts_active > 0:
            reasons.append(f"DEX boosts reported: {m.boosts_active} (paid promotion is not quality evidence)")

        # Explicit on-chain risk information where the provider exposes it.
        if not risk or risk.get("score") is None:
            score -= 15; reasons.append("security score unavailable: CALL disabled")
            stage = "WATCH"
        else:
            details = risk.get("details", {}) or {}
            rscore = number(risk.get("score"), 101)
            risk_names = " ".join(details.get("risk_names", [])).lower()
            critical_names = ("mint authority", "freeze authority", "rugged", "honeypot", "mutable supply")
            has_critical_risk = any(item in risk_names for item in critical_names)
            if details.get("rugged") or risk.get("verdict") == "HIGH_RISK" or rscore > float(cfg["max_rugcheck_score"]):
                score -= 30; reasons.append("RugCheck risk gate failed")
                stage = "BLOCK"
            elif rscore <= 10:
                score += 12; reasons.append("low reported RugCheck score")
                stage = "WATCH"
            elif rscore <= 20:
                score += 8; reasons.append("moderate-low reported RugCheck score")
                stage = "WATCH"
            else:
                score += 2; reasons.append("RugCheck below configured ceiling")
                stage = "WATCH"
            if has_critical_risk:
                score -= 10; reasons.append("authority/rug risk named in report")
                if any(x in risk_names for x in ("rugged", "honeypot")):
                    stage = "BLOCK"
            top10 = details.get("top10HoldersPct", details.get("topHoldersPct", details.get("top10_holders_pct")))
            top1 = details.get("topHolderPct", details.get("top_holder_pct"))
            lp_locked = details.get("lpLockedPct", details.get("lp_locked_pct"))
            if top10 is not None:
                h10 = number(top10)
                if h10 >= 70:
                    score -= 14; reasons.append("very concentrated top-10 holders")
                elif h10 >= 50:
                    score -= 8; reasons.append("top-10 holder concentration elevated")
            if top1 is not None and number(top1) >= 20:
                score -= 8; reasons.append("single top holder concentration elevated")
            if lp_locked is not None:
                lp = number(lp_locked)
                if lp < 20:
                    score -= 12; reasons.append("little/no LP lock reported")
                elif lp < 50:
                    score -= 5; reasons.append("LP lock below 50% reported")

        score = max(0.0, min(100.0, score))
        if stage != "BLOCK":
            if risk and risk.get("score") is not None and score >= float(cfg["min_signal_score"]):
                stage = "CALL"
            else:
                stage = "WATCH"
        return score, reasons, stage

    def format_alert(self, m: PairMetrics, score: float, reasons: list[str], risk: dict[str, Any],
                     trend: Optional[dict[str, Any]] = None, review: Optional[dict[str, Any]] = None,
                     narrative_analysis: Optional[dict[str, Any]] = None) -> str:
        risk_score = risk.get("score")
        risk_text = f"{risk_score:.0f}/100 (lower reported risk is better)" if risk_score is not None else "unknown"
        trend = trend or {}
        details = (risk or {}).get("details", {}) or {}
        age = f"{m.age_minutes:.1f} min" if m.age_minutes < 99999 else "unknown"
        mc_label = "FDV PROXY (true MC missing)" if m.market_cap_is_fdv else "MARKET CAP"
        lines = [
            f"🚨 R1_H RUNNER SIGNAL — {m.symbol} ({m.name})",
            f"Score: {score:.0f}/100 · status: research signal, NOT a prediction",
            f"CA: {m.mint}",
            f"{mc_label}: {short_usd(m.market_cap)} · FDV: {short_usd(m.fdv)} · Price: ${m.price_usd:.10g}",
            f"Liquidity: {short_usd(m.liquidity)} · Volume 5m: {short_usd(m.volume_5m)} · Vol/Liq: {m.volume_liquidity_ratio:.2f}x",
            f"5m tx: {m.txns_5m} (buys {m.buys_5m}/sells {m.sells_5m}) · buy share {m.buy_share_5m*100:.0f}%",
            f"Price change: 5m {m.change_5m:+.1f}% · 1h {m.change_1h:+.1f}% · 24h {m.change_24h:+.1f}%",
            f"Local trend 1m/5m/15m: {self._fmt_pct(trend.get('change_1m'))}/{self._fmt_pct(trend.get('change_5m'))}/{self._fmt_pct(trend.get('change_15m'))} · chart {trend.get('sparkline','·')}",
            f"Pool age: {age} · Website/Social links: {m.website_count}/{m.social_count} · DEX boosts: {m.boosts_active}",
            f"RugCheck: {risk_text} · top holders: {details.get('top10HoldersPct', details.get('top10_holders_pct', 'n/a'))} · LP locked: {details.get('lpLockedPct', 'n/a')}",
        ]
        nreport = narrative_analysis or {}
        if nreport:
            lines.append(f"Narrative quality: {nreport.get('narrative_score', 'n/a')}/100 · organic attention: {nreport.get('social_attention_score', 'n/a')}/100 · pre-hype setup: {nreport.get('pre_hype_score', 'n/a')}/100 · combined potential rank: {nreport.get('runner_potential_score', 'n/a')}/100 (not a probability)")
            view_text = f"{nreport.get('views_total'):,}" if nreport.get('views_observed') and nreport.get('views_total') is not None else "not exposed by provider"
            lines.append(f"Public social evidence: {nreport.get('matched_posts', 0)} matched posts · {nreport.get('unique_community_authors', 0)} community authors · {nreport.get('independent_sources', 0)} sources · observed views {view_text} · posts last 1h/15m {nreport.get('posts_last_hour', 0)}/{nreport.get('posts_last_15m', 0)}")
            if nreport.get('narrative_evidence'):
                lines.append("Narrative evidence: " + "; ".join(nreport["narrative_evidence"][:4]))
            if nreport.get('narrative_warnings'):
                lines.append("Narrative warnings: " + "; ".join(nreport["narrative_warnings"][:4]))
            if nreport.get('failed_gates'):
                lines.append("Narrative/social gates: " + "; ".join(nreport["failed_gates"][:5]))
            for post in (nreport.get("matched_post_details") or [])[:3]:
                if post.get("url", "").startswith("https://"):
                    lines.append("Social evidence link: " + str(post["url"]))
        lines.append("Evidence: " + "; ".join(reasons[:8]))
        if review:
            lines.append(f"AI qualitative review: {review.get('verdict','UNCERTAIN')} ({number(review.get('confidence')):.0f}/100 reviewer confidence, not a profit probability)")
            if review.get("thesis"):
                lines.append("AI: " + str(review["thesis"])[:240])
            for item in review.get("risks", [])[:4]:
                lines.append("AI risk: " + str(item)[:180])
        lines.extend([
            f"DEX chart: {m.dex_url}",
            f"Pump.fun: https://pump.fun/coin/{m.mint}",
            "Risk: very early tokens can lose almost all value; public-data filters cannot prove sellability or future price action.",
        ])
        return "\n".join(lines)

    def play_call_sound(self) -> None:
        """Play a short local alert when a NEW CALL is emitted. Works on Windows without extra packages."""
        def _play() -> None:
            try:
                if sys.platform == "win32":
                    import winsound
                    winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                    time.sleep(0.08)
                    winsound.Beep(880, 180)
                    time.sleep(0.06)
                    winsound.Beep(1175, 300)
                else:
                    sys.stdout.write("\a")
                    sys.stdout.flush()
            except Exception:
                # Sound is best-effort and must never interrupt a market scan.
                try:
                    sys.stdout.write("\a")
                    sys.stdout.flush()
                except Exception:
                    pass
        threading.Thread(target=_play, name="r1h-call-sound", daemon=True).start()

    def send_alert(self, text: str) -> None:
        # This method is called only after a previously unalerted token passes all CALL gates.
        # Play a local sound even when the browser dashboard is closed.
        self.play_call_sound()
        logging.info("🔔 CALL-Soundalarm ausgelöst.")
        # The Discord app bot stores each signal and broadcasts a rich embed to configured servers.
        self.discord.send_alert(text)

    @staticmethod
    def _apply_agency_status(base_stage: str, agency_status: Optional[str]) -> str:
        """Fail closed: a failed/missing agency review must never pass a base CALL through."""
        if base_stage in {"BLOCK", "FILTERED"}:
            return base_stage
        status = str(agency_status or "WATCH").upper()
        if status == "BLOCKED":
            return "BLOCK"
        if base_stage == "CALL":
            return "CALL" if status == "CALL" else "WATCH"
        if base_stage == "WATCH":
            # The coordinator can promote a safe, sufficiently scored WATCH into a
            # narrative-first CALL only after all independent social/security gates pass.
            if status == "CALL":
                return "CALL"
            return "WATCH" if status != "LOW_SIGNAL" else "LOW_SIGNAL"
        return base_stage

    def scan_cycle(self) -> dict[str, int]:
        self.rug_checks_this_cycle = 0
        self.ai_calls_this_cycle = 0
        new_count, mints = self.discover()
        raw_pairs = self.get_pair_batch(mints)
        pairs = self.choose_pairs(raw_pairs, set(mints))
        counts = {"discovered": new_count, "tracked": len(mints), "pairs": len(pairs), "call": 0,
                  "watch": 0, "block": 0, "filtered": 0, "risk_checks": 0, "ai_reviews": 0}
        logging.info("=" * 130)
        logging.info("SCAN | entdeckt=%d | Kandidaten=%d | Paare mit Live-Daten=%d | Datenquelle=DEX Screener/GeckoTerminal%s",
                     new_count, len(mints), len(pairs), " + PumpPortal" if self.pump_stream_running else "")

        # API budgets are limited. Prioritize viable early setups (reasonable cap/liquidity,
        # real activity, an informative profile, and not-yet-explosive price action) instead
        # of burning external/social checks on zero-liquidity micro-pools.
        def priority(m: PairMetrics) -> tuple[float, float]:
            in_band = float(self.cfg["min_market_cap_usd"]) <= m.market_cap <= float(self.cfg["max_market_cap_usd"])
            liq_ok = m.liquidity >= float(self.cfg["min_liquidity_usd"]) * 0.75
            age_ok = self.cfg.get("narrative_min_pool_age_minutes", 3) <= m.age_minutes <= float(self.cfg["max_pair_age_minutes"])
            price_ok = m.price_usd > 0
            info = (m.source_pair.get("info") or {})
            desc = str(info.get("description") or "")
            links = len(info.get("socials") or []) + len(info.get("websites") or [])
            # Narrative-first ordering deliberately avoids prioritizing only tokens
            # already showing a vertical price candle. Paid boosts are not quality proof.
            ch5 = number(m.change_5m)
            ch1 = number(m.change_1h)
            max_early_5m = float(self.cfg.get("narrative_max_5m_runup_pct", 4.5))
            if 0 <= ch5 <= max_early_5m:
                early_move = 14
            elif max_early_5m < ch5 <= max_early_5m * 2:
                early_move = -10
            elif ch5 > max_early_5m * 2:
                early_move = -25
            else:
                early_move = -8 if ch5 < -8 else 0
            max_early_1h = float(self.cfg.get("narrative_max_1h_runup_pct", 12))
            late_move = -20 if ch1 > max_early_1h else (4 if 0 <= ch1 <= max_early_1h else -2)
            max_early_24h = float(self.cfg.get("narrative_max_24h_runup_pct", 35))
            if m.change_24h > max_early_24h:
                late_move -= 20
            elif m.change_24h > max_early_24h * 0.65:
                late_move -= 6
            cap_priority = 12 if 5_000 <= m.market_cap <= 12_000 else 8 if 12_000 < m.market_cap <= 25_000 else -20
            value = cap_priority + (28 if in_band else -35) + (18 if liq_ok else -28) + (8 if age_ok else -8) + (8 if price_ok else -20)
            value += min(22, len(desc) / 16) + min(10, links * 2)
            value += min(10, m.volume_5m / max(1, float(self.cfg["min_volume_5m_usd"])))
            value += min(6, m.txns_5m * .20) + early_move + late_move
            value += 5 if .52 <= m.buy_share_5m <= .80 else -8 if m.buy_share_5m > .92 else 0
            if m.boosts_active > 0:
                value -= min(8, 2 + m.boosts_active)
            return (-value, m.market_cap if m.market_cap > 0 else 1e15)
        ordered = sorted(pairs.values(), key=priority)
        for m in ordered:
            pre_ok, pre_reason = self.preliminary_gate(m)
            trend = self.trend_metrics(m)
            risk: Optional[dict[str, Any]] = None
            if pre_ok:
                risk = self.rugcheck(m.mint)
                if risk and not risk.get("cached"):
                    counts["risk_checks"] += 1
            score, reasons, stage = self.score(m, risk, trend)
            if trend.get("liquidity_change_pct") is not None and number(trend.get("liquidity_change_pct")) <= -35:
                stage = "BLOCK"
                reasons = reasons + ["hard safety gate: liquidity down 35%+ since prior sample"]
            if not pre_ok and stage != "BLOCK":
                stage = "FILTERED"
                reasons = [pre_reason]
            review: Optional[dict[str, Any]] = None
            if pre_ok and stage != "BLOCK" and score >= float(self.cfg.get("ai_min_score", 65)):
                review = self.ai_review(m, score, reasons, risk, trend)
                if review and not review.get("cached"):
                    counts["ai_reviews"] += 1
            base_stage = stage
            agency_result = None
            social_band_ok = (not bool(m.market_cap_is_fdv)
                              and float(self.cfg["min_market_cap_usd"]) <= m.market_cap <= float(self.cfg["max_market_cap_usd"])
                              and m.liquidity >= float(self.cfg.get("social_min_liquidity_usd", 2500))
                              and float(self.cfg.get("narrative_min_pool_age_minutes", 3)) <= m.age_minutes <= float(self.cfg["max_pair_age_minutes"])
                              and m.price_usd > 0
                              and -18 <= m.change_5m <= float(self.cfg.get("narrative_max_5m_runup_pct", 4.5))
                              and -45 <= m.change_1h <= float(self.cfg.get("narrative_max_1h_runup_pct", 12))
                              and -60 <= m.change_24h <= float(self.cfg.get("narrative_max_24h_runup_pct", 35)))
            collect_external = social_band_ok and score >= float(self.cfg.get("social_scan_min_base_score", 35))
            try:
                agency_result = self.swarm.process(m, score, base_stage, risk, trend, review, reasons,
                                                   collect_external=collect_external)
                agency_status = agency_result.get("status") if isinstance(agency_result, dict) else None
            except Exception:
                # Closed-by-default: if the coordinated room fails, do not emit a base-only CALL.
                logging.exception("Swarm room update failed for %s", m.mint)
                agency_status = "WATCH"
            final_stage = self._apply_agency_status(base_stage, agency_status)
            if final_stage != base_stage:
                if final_stage == "WATCH" and base_stage == "CALL":
                    agency_meta = (agency_result or {}).get("agency", {}) if isinstance(agency_result, dict) else {}
                    gate_notes = agency_meta.get("failed_gates", [])
                    reasons = list(reasons) + ["Agency-Koordination hat Basis-CALL auf WATCH herabgestuft."]
                    reasons.extend(["Agency-Gate: " + str(x) for x in gate_notes[:4]])
                elif final_stage == "BLOCK":
                    reasons = list(reasons) + ["Agency-Koordination: Sicherheits-Gate blockiert Kandidaten."]
            stage = final_stage
            self.store.scanned(m, score, stage)
            self.store.save_scan_detail(m, score, stage, risk, trend, review, reasons)

            # Avoid a log firehose of zero-liquidity/rug-like micro-pools. The CSV/dashboard
            # retain scan details; CMD focuses on CALLs and higher-quality WATCH candidates.
            narrative_brief = (agency_result or {}).get("narrative_analysis", {}) if isinstance(agency_result, dict) else {}
            if self.cfg.get("show_every_candidate", False) or stage == "CALL" or (
                stage == "WATCH" and (score >= float(self.cfg.get("candidate_watch_log_score", 55))
                                      or number(narrative_brief.get("runner_potential_score")) >= float(self.cfg.get("candidate_watch_log_potential", 52)))
            ):
                logging.info("\n%s", self.format_candidate(m, score, stage, risk, reasons, trend, review, narrative_brief))

            if stage == "BLOCK":
                counts["block"] += 1
                continue
            if not pre_ok:
                counts["filtered"] += 1
                continue
            if stage == "CALL" and not self.store.has_alerted(m.mint):
                self.store.mark_alert(m, score)
                message = self.format_alert(m, score, reasons, risk or {}, trend, review, (agency_result or {}).get("narrative_analysis"))
                logging.info("\n%s", message)
                # Keep PWA push independent from Discord delivery; one transport failing
                # must not suppress the other notification channel.
                try:
                    self.swarm.notify_call(m.mint, m.name, m.symbol, m.market_cap, score)
                except Exception:
                    logging.exception("PWA-Push für CALL fehlgeschlagen; Scan läuft weiter.")
                try:
                    self.send_alert(message)
                except Exception:
                    logging.exception("Discord/CMD-Alert für CALL fehlgeschlagen; Scan läuft weiter.")
                counts["call"] += 1
            elif stage == "WATCH":
                counts["watch"] += 1

        if self.cfg.get("export_csv", True):
            try:
                self.store.export_csv()
                self.export_scan_csv()
            except OSError as exc:
                logging.warning("CSV export failed: %s", exc)
        return counts

    def export_scan_csv(self) -> None:
        """Export the latest full available scan view; missing source fields stay blank."""
        import csv
        with self.store.lock:
            rows = self.store.conn.execute("""
                SELECT t.mint,t.name,t.symbol,t.last_scanned,t.last_score,t.last_stage,t.last_price,
                       t.last_market_cap,t.last_liquidity,t.last_dex_url,
                       (SELECT volume_5m FROM snapshots s WHERE s.mint=t.mint ORDER BY timestamp DESC LIMIT 1) AS volume_5m,
                       (SELECT buys_5m FROM snapshots s WHERE s.mint=t.mint ORDER BY timestamp DESC LIMIT 1) AS buys_5m,
                       (SELECT sells_5m FROM snapshots s WHERE s.mint=t.mint ORDER BY timestamp DESC LIMIT 1) AS sells_5m,
                       d.*
                FROM tokens t LEFT JOIN scan_details d ON d.mint=t.mint
                WHERE t.last_scanned IS NOT NULL ORDER BY t.last_score DESC LIMIT 2000
            """).fetchall()
        path = DATA_ROOT / "latest_scan.csv"
        fields = ["mint","name","symbol","last_scanned","score","stage","price_usd","market_cap_or_fdv_usd",
                  "market_cap_is_fdv_proxy","fdv_usd","liquidity_usd","volume_5m_usd","buys_5m","sells_5m",
                  "change_5m_pct","change_1h_pct","change_24h_pct","local_change_1m_pct","local_change_5m_pct",
                  "local_change_15m_pct","volume_momentum_x","liquidity_change_pct","buy_share_delta_pp","local_volatility_pct",
                  "pool_age_minutes","website_count","social_count","active_boosts",
                  "rugcheck_score","risk_verdict","holder_count","top_holder_pct","top10_holder_pct","lp_locked_pct",
                  "chart_sparkline","ai_verdict","ai_confidence","ai_thesis","reasons","dex_url"]
        with path.open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for r in rows:
                writer.writerow({
                    "mint":r["mint"], "name":r["name"], "symbol":r["symbol"], "last_scanned":r["last_scanned"],
                    "score":r["last_score"], "stage":r["last_stage"], "price_usd":r["last_price"],
                    "market_cap_or_fdv_usd":r["last_market_cap"], "market_cap_is_fdv_proxy":r["market_cap_is_fdv"],
                    "fdv_usd":r["fdv"], "liquidity_usd":r["last_liquidity"], "volume_5m_usd":r["volume_5m"],
                    "buys_5m":r["buys_5m"], "sells_5m":r["sells_5m"], "change_5m_pct":r["change_5m"],
                    "change_1h_pct":r["change_1h"], "change_24h_pct":r["change_24h"],
                    "local_change_1m_pct":r["local_change_1m"], "local_change_5m_pct":r["local_change_5m"],
                    "local_change_15m_pct":r["local_change_15m"], "volume_momentum_x":r["volume_momentum_x"],
                    "liquidity_change_pct":r["liquidity_change_pct"], "buy_share_delta_pp":r["buy_share_delta_pp"],
                    "local_volatility_pct":r["volatility_pct"], "pool_age_minutes":r["age_minutes"],
                    "website_count":r["website_count"], "social_count":r["social_count"], "active_boosts":r["boosts_active"],
                    "rugcheck_score":r["risk_score"], "risk_verdict":r["risk_verdict"], "holder_count":r["holder_count"],
                    "top_holder_pct":r["top_holder_pct"], "top10_holder_pct":r["top10_pct"], "lp_locked_pct":r["lp_locked_pct"],
                    "chart_sparkline":r["sparkline"], "ai_verdict":r["ai_verdict"], "ai_confidence":r["ai_confidence"],
                    "ai_thesis":r["ai_thesis"], "reasons":r["reasons_json"], "dex_url":r["last_dex_url"]
                })

    def run(self) -> None:
        self.discord.start()
        self.start_pumpportal_stream()
        if not os.getenv("PUMPPORTAL_API_KEY", "").strip():
            logging.warning("New-pair Stream nicht verbunden: PUMPPORTAL_API_KEY fehlt. DEX-Screener-Profilfeed + GeckoTerminal-New-Pools-Polling bleiben aktiv.")
        self.swarm.start_dashboard()
        logging.info("R1_H Runner Intel Agency 5.1 Web + Call-Sound gestartet | read-only | keine Trades/Wallet-Keys")
        logging.info("Market-cap Band: %s–%s USD | early-entry mode=%s | min score %s | poll %ss",
                     short_usd(float(self.cfg["min_market_cap_usd"])), short_usd(float(self.cfg["max_market_cap_usd"])),
                     self.cfg.get("early_entry_mode", True), self.cfg["min_signal_score"], self.cfg["poll_seconds"])
        logging.info("Alert-Kanäle: CMD + %s",
                     "Discord Bot (Kanal ggf. per /setchannel festlegen)" if os.getenv("DISCORD_BOT_TOKEN") else "Discord nicht konfiguriert")
        logging.info("KI-Analyse: %s | Modell: %s | KI schreibt keine Kursprognose-Garantie aus",
                     "aktiv (bei OPENAI_API_KEY)" if self.cfg.get("enable_ai_analysis", True) and os.getenv("OPENAI_API_KEY") else "aus (OPENAI_API_KEY fehlt/deaktiviert)",
                     os.getenv("OPENAI_MODEL", "gpt-4.1-mini"))
        logging.info("Dashboard: http://127.0.0.1:%s | pro Coin ein persistenter Analysten-Raum", self.cfg.get("dashboard_port", 8765))
        logging.info("New-pair Discovery: DEX Screener latest profiles + GeckoTerminal new pools; PumpPortal Stream=%s",
                     "bereit (API-Key konfiguriert)" if os.getenv("PUMPPORTAL_API_KEY", "").strip() and self.cfg.get("enable_pumpportal_stream", True) else "Polling-Fallback (PUMPPORTAL_API_KEY optional)")
        logging.info("iPhone Web-Push: %s", "VAPID konfiguriert; Abos werden bei CALL benachrichtigt" if self.swarm.web_push.enabled else "nicht konfiguriert; für iPhone-Push HTTPS-Hosting + setup_push.py erforderlich")
        logging.info("Agency-Schwarm: neun lokale Spezialisten + Konsens-Koordinator aktiv; Social-/KI-Daten werden nur mit API-Zugang live ergänzt")
        social_keys = bool(os.getenv("X_BEARER_TOKEN", "").strip() or
                           (os.getenv("REDDIT_CLIENT_ID", "").strip() and os.getenv("REDDIT_CLIENT_SECRET", "").strip()))
        if bool(self.cfg.get("require_social_proof_for_call", True)) and not social_keys:
            logging.warning("STRICT NARRATIVE MODE: X_BEARER_TOKEN oder Reddit API-Zugang fehlt. Kandidaten bleiben WATCH; es werden keine Calls ohne echte öffentliche Social-Belege ausgegeben.")
        if bool(self.cfg.get("require_social_proof_for_call", True)):
            logging.info("CALL-Policy: narrative-first; unabhängige Community-Erwähnungen, frische Aktivität, Risikoprüfung und Pre-Hype-Gates erforderlich")
        while True:
            started = time.monotonic()
            try:
                c = self.scan_cycle()
                last_cycle = iso_now()
                self.discord.set_status(
                    f"RUNNING\nLetzter Zyklus: {last_cycle}\n"
                    f"Neue Kandidaten: {c['discovered']} | verfolgt: {c['tracked']} | Pools: {c['pairs']}\n"
                    f"WATCH: {c['watch']} | CALL: {c['call']} | Risk checks: {c['risk_checks']}\n"
                    f"Scanintervall: {self.cfg['poll_seconds']} Sekunden"
                )
                logging.info("cycle | discovery=%d tracked=%d pools=%d watch=%d call=%d risk checks=%d",
                             c["discovered"], c["tracked"], c["pairs"], c["watch"], c["call"], c["risk_checks"])
            except KeyboardInterrupt:
                raise
            except Exception as exc:
                self.discord.set_status(f"RUNNING MIT FEHLER BEIM LETZTEN SCAN\n{type(exc).__name__}: {str(exc)[:300]}\nDer nächste Zyklus wird erneut versucht.")
                logging.exception("Scan-Zyklus fehlgeschlagen; der Bot läuft weiter.")
            duration = time.monotonic() - started
            time.sleep(max(1, float(self.cfg["poll_seconds"]) - duration))


def main() -> int:
    try:
        load_env_file()
        cfg = load_config()
        RunnerIntel(cfg).run()
    except KeyboardInterrupt:
        print("\nR1_H Runner Intel beendet.")
        return 0
    except Exception as exc:
        print(f"FEHLER: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
