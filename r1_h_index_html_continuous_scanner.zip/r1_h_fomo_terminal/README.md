# R1_H Early Signal Terminal — FOMO-inspired UI + iPhone PWA

Dieses Paket enthält das bestehende read-only Solana-Research-System mit `index.html` als kanonischer Startseite und einem FOMO-Terminal-inspirierten Drei-Spalten-Dashboard: Token Discovery links, ausgewählter Coin/Research in der Mitte und Signal/Call-Pulse rechts. Es nutzt weiterhin die existierenden Backend-APIs, Coin-Räume, Discord-Alerts, iPhone-PWA und Web-Push. Keine Trades oder Wallet-Private-Keys.

## Wichtig: Was du für iPhone-Push brauchst

- iPhone mit **iOS/iPadOS 16.4 oder neuer**.
- Eine öffentliche Domain, die auf einen **dauerhaft laufenden Ubuntu-VPS** zeigt.
- HTTPS. Die mitgelieferte Caddy-Konfiguration beschafft/erneuert TLS-Zertifikate automatisch, sobald die Domain auf den VPS zeigt und Ports 80/443 offen sind.
- Der Scanner muss auf dem VPS laufen. Wenn er nur auf dem heimischen PC läuft und der PC ausgeschaltet ist, kann er keine neuen Calls erkennen.
- VAPID-Schlüssel und Dashboard-Passwort. Das Setup erstellt beides sicher lokal auf dem Server.

Eine ZIP-Datei lässt sich nicht direkt wie eine native App installieren. Die Website wird als **Progressive Web App (PWA)** auf dem iPhone zum Home-Bildschirm hinzugefügt. Danach können Web-Push-Nachrichten erscheinen, auch wenn die App gerade nicht offen ist. Apple verlangt die Home-Screen-Installation und eine ausdrückliche Erlaubnis durch eine Nutzeraktion.

## A. Schnellstart auf Windows (lokale Tests)

1. ZIP entpacken.
2. `install.bat` ausführen.
3. Optional Discord konfigurieren: `setup_discord.bat`.
4. `start.bat` starten und im Browser `http://127.0.0.1:8765/index.html` öffnen. Der Backend-Prozess scannt fortlaufend im konfigurierten Poll-Intervall, solange das CMD-Fenster/der Prozess läuft.

Der Localhost-Modus eignet sich zum Testen des Dashboards und Scanners, aber **nicht** für Push an dein iPhone von überall. Dafür verwende Abschnitt B.

## B. iPhone-App + 24/7-Push auf einem Ubuntu-VPS

### 1. Domain und Server vorbereiten

- Richte eine Domain/Subdomain ein, z. B. `r1h.deinedomain.de`.
- Erstelle einen Ubuntu-VPS und setze beim Domain-Anbieter einen DNS-A-Record auf seine öffentliche IPv4-Adresse (ggf. auch AAAA für IPv6).
- Erlaube beim VPS-Anbieter die eingehenden Ports **80/tcp** und **443/tcp** (optional `443/udp`).
- Lade den kompletten entpackten Projektordner per SCP/WinSCP auf den VPS. Nicht die alte `.env`-Datei in ein öffentliches Repository hochladen.

### 2. Docker installieren

Auf dem Ubuntu-VPS:

```bash
sudo apt update
sudo apt install -y ca-certificates curl python3-venv python3-pip
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
sudo tee /etc/apt/sources.list.d/docker.sources >/dev/null <<EOF2
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: $(. /etc/os-release && echo "${UBUNTU_CODENAME:-$VERSION_CODENAME}")
Components: stable
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/docker.asc
EOF2
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
```

Öffne auf dem VPS eine Shell im Projektordner.

### 3. Push-Schlüssel und Passwort erzeugen

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python setup_push.py
```

Gib deine Domain **ohne** `https://` ein, z. B. `r1h.deinedomain.de`, und richte ein starkes Dashboard-Passwort ein. Der Befehl erzeugt `vapid_private.pem` und ergänzt `.env`. Bewahre `.env` und `vapid_private.pem` geheim auf.

### 4. API-Zugangsdaten eintragen

Öffne `.env` auf dem VPS (z. B. `nano .env`) und trage deine bereits vorhandenen Discord-Einstellungen sowie optional X-/Reddit-Zugangsdaten ein. Für den strengen Narrative-Modus ist mindestens eine echte öffentliche Social-Quelle nötig; sonst bleibt der Scanner absichtlich bei WATCH. Teile API-Schlüssel niemals im Chat.

### 5. System starten

```bash
mkdir -p state
sudo docker compose up -d --build
sudo docker compose logs -f app
```

Caddy stellt die Website unter `https://DEINE-DOMAIN` bereit. Prüfe DNS, Server-Firewall und dass die Domain auf diesen VPS zeigt, falls TLS nicht innerhalb weniger Minuten bereitsteht.

Status/Neustart:

```bash
sudo docker compose ps
sudo docker compose restart app
```

### 6. Als iPhone-App installieren und Push aktivieren

1. Öffne **Safari auf dem iPhone** und rufe `https://DEINE-DOMAIN` auf.
2. Tippe auf **Teilen** → **Zum Home-Bildschirm** → **Hinzufügen**.
3. Öffne R1_H über das neue Symbol auf dem Home-Bildschirm (nicht nur in einem normalen Safari-Tab).
4. Melde dich mit dem Dashboard-Passwort an, das `setup_push.py` eingerichtet hat.
5. Tippe auf **„iPhone-Push aktivieren“** und erlaube Mitteilungen.
6. Tippe auf **„Push testen“**. Du solltest eine Test-Mitteilung vom Server erhalten.

Wenn ein Coin alle Scanner-, Risiko- und Narrative-Gates besteht und als neuer `CALL` gespeichert wird, sendet der laufende VPS eine Web-Push-Mitteilung mit Symbol, Market Cap, Score und einem Link zur Coin-Detailseite. WATCH/FILTERED/BLOCK werden nicht als CALL-Push verschickt.

## New-pair Discovery / Early Entry

Der Scanner prüft im 15-Sekunden-Takt DEX-Screener-Latest-Token-Profile und GeckoTerminal-New-Pools; die optionale PumpPortal-Stream-Verbindung liefert mit `PUMPPORTAL_API_KEY` zusätzlich New-Token-/Migration-Events. `config.json` beginnt mit einem $5k–$25k MC-Band. Ein API-Feed kann nicht garantieren, jedes einzelne Pair zu erfassen. Reine FDV-Proxys, fehlende Sicherheitsdaten, extreme Bewegungen oder fehlende Social-Belege blockieren weiterhin einen CALL.

## Sicherheit / Grenzen

- Dashboard für externen Zugriff nur über HTTPS/Caddy bereitstellen. `R1H_APP_PASSWORD` ist bei öffentlichem Hosting Pflicht; der Backend-Code verweigert eine öffentliche Bindung ohne Passwort.
- `vapid_private.pem`, `.env`, SQLite-Dateien und `state/` nicht veröffentlichen.
- Der Scanner ist read-only; er signiert keine Transaktionen und führt keine Trades aus.
- Push setzt voraus, dass der VPS und Scanner laufen und Push im PWA-Client aktiviert wurde. Push ist kein nativer App Store Build und kein Garant für sofortige Zustellung auf jedem Gerät.
- Ein CALL ist ein Research-Signal, keine Garantie eines Pumps oder Profits. Memecoins können sehr schnell fast ihren gesamten Wert verlieren.


## UI-Refresh: FOMO-inspired Trading Terminal

- Kompaktes Terminal-Topbar-Layout mit Solana-Mainnet-/Scannerstatus.
- Linke Token-Discovery-Liste mit Suche, Statusfilter und Views: Discover, New Pairs, Trending, Calls und Watchlist.
- Mittlerer Asset-Terminal-Bereich mit bestehenden Marktdaten, lokalen Preis-Snapshots, Risiko-/Narrative-/Agentenanalysen und Forecast-Ledger.
- Rechte Seitenleiste: Selected Asset, High-signal Watch, Call Feed und Quick Links.
- Responsive für Desktop und iPhone; vorhandene PWA-Installation, Browser-Sound, Desktop-Hinweise und serverseitige Web-Push bleiben erhalten.
- Nur tatsächliche Backend-Daten werden als Marktwerte angezeigt. Demo-/FOMO-Branding oder fremde Original-Assets sind nicht enthalten.

### In ein bestehendes GitHub-Repository übernehmen

Wenn dein bestehendes Repository bereits das R1_H-Backend aus diesem Paket enthält, sichere deine Dateien und ersetze nur `dashboard.html` und `manifest.webmanifest` mit den gleichnamigen Dateien aus diesem Paket. Für eine komplette Deployment-Kopie lade den gesamten entpackten Projektordner in ein privates GitHub-Repository hoch. Niemals `.env`, `vapid_private.pem` oder `state/`-Datenbanken committen.


## `index.html` und Dauerbetrieb

- `index.html` ist die primäre Dashboard-Datei und wird unter `/` sowie `/index.html` ausgeliefert. `dashboard.html` bleibt als Kompatibilitätskopie für ältere Links erhalten.
- Der Scanner ist **kein statischer HTML-Prozess**: `sharky_runner.py` fragt Discovery-Quellen wiederholt gemäß `poll_seconds` ab. Unter Windows läuft er, solange `start.bat`/das Python-Programm offen ist.
- Für echten 24/7-Betrieb auch bei ausgeschaltetem PC muss das komplette Backend auf einem dauerhaft laufenden VPS/Server betrieben werden; dafür ist das enthaltene Docker-Compose-Setup gedacht.
- GitHub kann die Dateien versionieren. GitHub Pages allein kann den Python-Scanner nicht ausführen und deshalb nicht rund um die Uhr New Pairs suchen oder serverseitige Push-Notifications erzeugen.
- Keine API-Schlüssel, `.env`, VAPID-Private-Keys oder Laufzeitdatenbanken in ein öffentliches Repository hochladen.
