#!/usr/bin/env python3
"""Secure local Discord bot setup. Never prints the bot token."""
from __future__ import annotations

import getpass
import os
from pathlib import Path
import re
import sys
import requests

ROOT = Path(__file__).resolve().parent
ENV_PATH = ROOT / ".env"
API = "https://discord.com/api/v10"


def update_env(key: str, value: str) -> None:
    lines = ENV_PATH.read_text(encoding="utf-8").splitlines() if ENV_PATH.exists() else []
    prefix = key + "="
    replacement = f"{key}={value}"
    out = []
    found = False
    for line in lines:
        if line.strip().startswith(prefix):
            if not found:
                out.append(replacement)
                found = True
        else:
            out.append(line)
    if not found:
        out.append(replacement)
    ENV_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")


def main() -> int:
    print("=" * 58)
    print(" R1_H // DISCORD BOT SETUP")
    print("=" * 58)
    if not ENV_PATH.exists():
        example = ROOT / ".env.example"
        if example.exists():
            ENV_PATH.write_text(example.read_text(encoding="utf-8"), encoding="utf-8")
        else:
            ENV_PATH.write_text("DISCORD_BOT_TOKEN=\nDISCORD_GUILD_ID=\n", encoding="utf-8")

    token = getpass.getpass("Discord Bot Token (Eingabe bleibt verborgen): ").strip()
    if not token:
        print("Kein Token eingegeben. Setup abgebrochen.")
        return 1

    print("Prüfe Token bei Discord …")
    try:
        response = requests.get(
            f"{API}/users/@me",
            headers={"Authorization": f"Bot {token}", "User-Agent": "R1_H-Discord-Caller/1.0"},
            timeout=12,
        )
        if response.status_code != 200:
            print("Discord hat den Token abgelehnt. Erzeuge im Developer Portal einen neuen Bot-Token und versuche erneut.")
            return 1
        info = response.json()
        username = str(info.get("username") or "Discord Bot")
        bot_id = str(info.get("id") or "")
    except requests.RequestException:
        print("Discord war nicht erreichbar. Prüfe die Internetverbindung und versuche erneut.")
        return 1
    except ValueError:
        print("Discord lieferte keine gültige Antwort. Setup abgebrochen.")
        return 1

    guild_id = input(
        "Optional: numerische Server-ID für sofortige Slash-Befehle eingeben (Enter überspringt): "
    ).strip()
    if guild_id and not re.fullmatch(r"\d{15,25}", guild_id):
        print("Die Server-ID muss eine numerische Discord-ID sein. Setup abgebrochen.")
        return 1

    update_env("DISCORD_BOT_TOKEN", token)
    update_env("DISCORD_GUILD_ID", guild_id)
    print("\n✅ Token geprüft und lokal in .env gespeichert (nicht angezeigt).")
    print(f"Bot: {username} (ID {bot_id})")
    if guild_id:
        print("Slash-Befehle werden auf diesem Server synchronisiert.")
    else:
        print("Ohne Server-ID werden globale Slash-Befehle synchronisiert; sie können verzögert erscheinen.")
    print("Als Nächstes:")
    print("1) Bot in deinen Server einladen.")
    print("2) Einen Textkanal exakt #coin-calls erstellen (oder #r1-h-calls, #runner-calls, #calls).")
    print("3) start.bat ausführen. Der Bot erkennt den Call-Kanal automatisch und sendet jeden neuen CALL direkt.")
    print("/setchannel bleibt optional, falls du später einen anderen Zielkanal möchtest.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
