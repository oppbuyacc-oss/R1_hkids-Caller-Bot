@echo off
cd /d "%~dp0"
echo R1_H iPhone Push Setup
py setup_push.py
if errorlevel 1 pause
