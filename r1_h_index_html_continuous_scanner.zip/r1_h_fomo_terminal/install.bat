@echo off
cd /d "%~dp0"
echo R1_H Runner Intel // Discord Caller installer
py --version
if errorlevel 1 (
  echo Python 3.10+ was not found. Install it from https://www.python.org/downloads/ and enable Add Python to PATH.
  pause
  exit /b 1
)
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo Dependency installation failed. Check the error above.
  pause
  exit /b 1
)
if not exist .env copy .env.example .env >nul
echo.
echo Install complete. Next run setup_discord.bat, then start.bat.
pause
