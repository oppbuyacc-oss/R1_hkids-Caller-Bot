#!/usr/bin/env python3
"""R1_H Discord bot bridge: rich CALL embeds, slash commands, per-server channels.

This module sends research alerts only. It never trades, holds wallets, or signs transactions.
The discord.py dependency is imported only when the client thread starts so pure helpers
can be unit-tested without a connected Discord account.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse


# The bot can select a destination automatically when a server has one of these
# conventional channel names. Prefer the explicit `coin-calls` name.
AUTO_CALL_CHANNEL_NAMES = ("coin-calls", "r1-h-calls", "runner-calls", "calls")


def _line(text: str, prefix: str) -> str:
    for item in str(text).splitlines():
        if item.startswith(prefix):
            return item[len(prefix):].strip()
    return ""


def _valid_web_url(value: str) -> bool:
    try:
        parts = urlparse(str(value).strip())
        return parts.scheme in {"https", "http"} and bool(parts.netloc)
    except ValueError:
        return False


def parse_call_text(text: str) -> dict[str, Any]:
    """Turn the scanner's plain-text signal into safe, structured presentation fields."""
    lines = str(text).splitlines()
    title_line = lines[0].strip() if lines else "R1_H RUNNER SIGNAL"
    title = title_line.split("—", 1)[1].strip() if "—" in title_line else title_line
    title = title[:250] or "R1_H RUNNER SIGNAL"

    score_line = _line(text, "Score:")
    ca = _line(text, "CA:")
    cap_line = next((x for x in lines if x.startswith("MARKET CAP:") or x.startswith("FDV PROXY (true MC missing):")), "")
    if cap_line.startswith("MARKET CAP:"):
        market_label = "Market Cap"
    elif cap_line.startswith("FDV PROXY (true MC missing):"):
        market_label = "FDV proxy (Market Cap unavailable)"
    else:
        market_label = "Market Cap / FDV"
    market_value = cap_line.split(":", 1)[1].split("·", 1)[0].strip() if ":" in cap_line else "unknown"
    fdv_match = re.search(r"FDV:\s*([^·]+)", cap_line)
    price_match = re.search(r"Price:\s*(.+)$", cap_line)

    liquidity_line = _line(text, "Liquidity:")
    tx_line = _line(text, "5m tx:")
    change_line = _line(text, "Price change:")
    trend_line = _line(text, "Local trend 1m/5m/15m:")
    age_line = _line(text, "Pool age:")
    risk_line = _line(text, "RugCheck:")
    evidence = _line(text, "Evidence:")
    ai_review = _line(text, "AI qualitative review:")
    thesis = _line(text, "AI:")
    ai_risks = [x[len("AI risk:"):].strip() for x in lines if x.startswith("AI risk:")][:4]
    narrative_score = _line(text, "Narrative quality:")
    social_evidence = _line(text, "Public social evidence:")
    narrative_evidence = _line(text, "Narrative evidence:")
    narrative_warnings = _line(text, "Narrative warnings:")
    narrative_gates = _line(text, "Narrative/social gates:")
    social_links = [x[len("Social evidence link:"):].strip() for x in lines if x.startswith("Social evidence link:")][:4]
    chart_url = _line(text, "DEX chart:")
    pump_url = _line(text, "Pump.fun:")

    return {
        "title": title,
        "score": score_line or "not provided",
        "ca": ca or "not provided",
        "market_label": market_label,
        "market_value": market_value or "unknown",
        "fdv": fdv_match.group(1).strip() if fdv_match else "unknown",
        "price": price_match.group(1).strip() if price_match else "unknown",
        "liquidity": liquidity_line,
        "transactions": tx_line,
        "price_change": change_line,
        "trend": trend_line,
        "pool_age": age_line,
        "risk": risk_line,
        "evidence": evidence,
        "ai_review": ai_review,
        "thesis": thesis,
        "ai_risks": ai_risks,
        "narrative_score": narrative_score,
        "social_evidence": social_evidence,
        "narrative_evidence": narrative_evidence,
        "narrative_warnings": narrative_warnings,
        "narrative_gates": narrative_gates,
        "social_links": [url for url in social_links if _valid_web_url(url)],
        "chart_url": chart_url if _valid_web_url(chart_url) else "",
        "pump_url": pump_url if _valid_web_url(pump_url) else "",
        "raw": str(text)[:12000],
    }


class DiscordBot:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.token = os.getenv("DISCORD_BOT_TOKEN", "").strip()
        self.guild_id = os.getenv("DISCORD_GUILD_ID", "").strip()
        self.default_channel_id = os.getenv("DISCORD_CHANNEL_ID", "").strip()
        self.state_path = self.root / "discord_state.json"
        self.lock = threading.RLock()
        self.thread: Optional[threading.Thread] = None
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.client: Any = None
        self.tree: Any = None
        self.status_text = "Scanner startet; der erste Scan steht noch aus."
        self.latest_alerts: list[dict[str, str]] = []
        self.channels: dict[str, str] = {}
        self.muted_guilds: set[str] = set()
        self._synced = False
        self._load_state()

    def _load_state(self) -> None:
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                return
            alerts = data.get("latest_alerts", [])
            if isinstance(alerts, list):
                self.latest_alerts = [x for x in alerts if isinstance(x, dict) and x.get("text")][-25:]
            channels = data.get("channels", {})
            if isinstance(channels, dict):
                self.channels = {str(k): str(v) for k, v in channels.items() if str(k).isdigit() and str(v).isdigit()}
            muted = data.get("muted_guilds", [])
            if isinstance(muted, list):
                self.muted_guilds = {str(x) for x in muted}
        except FileNotFoundError:
            pass
        except (OSError, json.JSONDecodeError) as exc:
            logging.warning("Discord-Zustand konnte nicht geladen werden: %s", type(exc).__name__)

        # An environment-provided channel is useful for unattended setups. A channel
        # selected with /setchannel is stored per server and does not need .env edits.
        if self.default_channel_id and self.guild_id and self.default_channel_id.isdigit() and self.guild_id.isdigit():
            self.channels.setdefault(self.guild_id, self.default_channel_id)

    def _save_state(self) -> None:
        payload = {
            "latest_alerts": self.latest_alerts[-25:],
            "channels": self.channels,
            "muted_guilds": sorted(self.muted_guilds),
        }
        temp = self.state_path.with_suffix(".tmp")
        try:
            temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            temp.replace(self.state_path)
        except OSError as exc:
            logging.warning("Discord-Zustand konnte nicht gespeichert werden: %s", type(exc).__name__)

    def _autodiscover_call_channels(self) -> None:
        """Automatically route future CALLs to a conventional channel.

        Existing per-server selections and DISCORD_CHANNEL_ID take priority. If no
        destination is configured for a guild, choose a channel named #coin-calls
        (or one of the documented fallbacks) and persist that mapping. This avoids
        requiring a user to run /setchannel after the one-time bot setup.
        """
        client = self.client
        if client is None:
            return
        guilds = list(getattr(client, "guilds", []) or [])
        with self.lock:
            configured = dict(self.channels)
        for guild in guilds:
            guild_id = str(getattr(guild, "id", ""))
            if not guild_id.isdigit():
                continue
            if self.guild_id.isdigit() and guild_id != self.guild_id:
                continue
            if guild_id in configured:
                continue

            text_channels = list(getattr(guild, "text_channels", []) or [])
            selected = None
            for target_name in AUTO_CALL_CHANNEL_NAMES:
                selected = next(
                    (ch for ch in text_channels if str(getattr(ch, "name", "")).casefold() == target_name),
                    None,
                )
                if selected is not None:
                    break
            if selected is None:
                logging.warning(
                    "Kein Call-Ziel im Server %s gefunden. Erstelle einen Textkanal namens #coin-calls; "
                    "danach den Bot neu starten. /setchannel bleibt optional.",
                    getattr(guild, "name", guild_id),
                )
                continue

            # Select only a channel where the bot can actually publish embeds.
            member = getattr(guild, "me", None)
            if member is not None and hasattr(selected, "permissions_for"):
                try:
                    permissions = selected.permissions_for(member)
                    if not (permissions.view_channel and permissions.send_messages and permissions.embed_links):
                        logging.warning(
                            "Kanal #%s gefunden, aber R1_H fehlen Berechtigungen: View Channel, Send Messages, Embed Links.",
                            getattr(selected, "name", "coin-calls"),
                        )
                        continue
                except Exception:
                    # Let delivery report a precise permission error if a custom/fake
                    # channel wrapper doesn't expose a standard permissions object.
                    pass

            channel_id = str(getattr(selected, "id", ""))
            did_set = False
            with self.lock:
                if guild_id not in self.channels and channel_id.isdigit():
                    self.channels[guild_id] = channel_id
                    self._save_state()
                    did_set = True
            if did_set:
                logging.info(
                    "Automatischer Call-Kanal gesetzt: #%s im Server %s. Neue CALLs werden dort direkt gepostet.",
                    getattr(selected, "name", "coin-calls"),
                    getattr(guild, "name", guild_id),
                )
                configured[guild_id] = channel_id

    def set_status(self, text: str) -> None:
        with self.lock:
            self.status_text = str(text)[:1500]

    def start(self) -> None:
        if not self.token:
            logging.info("Discord Bot deaktiviert: DISCORD_BOT_TOKEN fehlt; lokaler Scanner läuft weiter.")
            return
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._thread_main, name="r1-h-discord", daemon=True)
        self.thread.start()
        logging.info("Discord Bot wird verbunden. Der Bot erkennt #coin-calls automatisch und sendet neue CALLs ohne manuelle Bestätigung.")

    def _thread_main(self) -> None:
        try:
            asyncio.run(self._client_main())
        except Exception as exc:
            logging.error("Discord Bot wurde beendet (%s). Prüfe Token und Bot-Konfiguration.", type(exc).__name__)

    async def _client_main(self) -> None:
        import discord
        from discord import app_commands

        self.loop = asyncio.get_running_loop()
        intents = discord.Intents.none()
        intents.guilds = True
        client = discord.Client(intents=intents)
        tree = app_commands.CommandTree(client)
        self.client = client
        self.tree = tree

        def target_guild(interaction: Any) -> Optional[str]:
            return str(interaction.guild_id) if interaction.guild_id is not None else None

        async def require_guild(interaction: Any) -> bool:
            if interaction.guild_id is None:
                await interaction.response.send_message("Dieser Befehl funktioniert nur auf einem Server.", ephemeral=True)
                return False
            return True

        @tree.command(name="help", description="Zeigt die R1_H Caller-Befehle.")
        @app_commands.guild_only()
        async def help_command(interaction: discord.Interaction) -> None:
            embed = discord.Embed(
                title="R1_H RUNNER INTEL — Hilfe",
                description=(
                    "`/setchannel` — aktuellen Kanal für automatische Calls festlegen\n"
                    "`/status` — Status und letzter Scan\n"
                    "`/latest` — letzten CALL im Detail\n"
                    "`/calls` — letzte fünf CALLs\n"
                    "`/alerts enabled:true/false` — Alerts an/aus\n"
                    "`/help` — diese Anleitung\n\n"
                    "Research-Alerts sind keine Gewinn- oder Kaufgarantie. Der Bot handelt nicht automatisch."
                ),
                color=discord.Color.blurple(),
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

        @tree.command(name="setchannel", description="Legt diesen Textkanal als Call-Kanal fest (Server verwalten erforderlich).")
        @app_commands.guild_only()
        async def setchannel(interaction: discord.Interaction) -> None:
            if not await require_guild(interaction):
                return
            permissions = getattr(interaction.user, "guild_permissions", None)
            if not permissions or not permissions.manage_guild:
                await interaction.response.send_message("Dafür benötigst du die Berechtigung „Server verwalten“.", ephemeral=True)
                return
            guild_key = str(interaction.guild_id)
            channel_key = str(interaction.channel_id)
            with self.lock:
                self.channels[guild_key] = channel_key
                self._save_state()
            await interaction.response.send_message(
                f"✅ Automatische R1_H-Calls werden in {interaction.channel.mention} gesendet.", ephemeral=True
            )

        @tree.command(name="status", description="Zeigt Scannerstatus, letzten Zyklus und konfigurierte Call-Kanäle.")
        @app_commands.guild_only()
        async def status_command(interaction: discord.Interaction) -> None:
            if not await require_guild(interaction):
                return
            guild_key = target_guild(interaction)
            with self.lock:
                status = self.status_text
                channel_id = self.channels.get(guild_key or "")
                count = len(self.latest_alerts)
                muted = guild_key in self.muted_guilds if guild_key else False
            channel_line = f"<#{channel_id}>" if channel_id else "nicht festgelegt — verwende /setchannel"
            embed = discord.Embed(title="🟢 R1_H Caller Status", color=discord.Color.green())
            embed.add_field(name="Scanner", value=status[:1024], inline=False)
            embed.add_field(name="Call-Kanal", value=channel_line, inline=True)
            embed.add_field(name="Gespeicherte Alerts", value=str(count), inline=True)
            embed.add_field(name="Benachrichtigungen", value="PAUSIERT" if muted else "AKTIV", inline=True)
            await interaction.response.send_message(embed=embed, ephemeral=True)

        @tree.command(name="latest", description="Zeigt den letzten gespeicherten Runner-Call.")
        @app_commands.guild_only()
        async def latest_command(interaction: discord.Interaction) -> None:
            with self.lock:
                latest = self.latest_alerts[-1] if self.latest_alerts else None
            if not latest:
                await interaction.response.send_message("Noch kein CALL gespeichert. Der Scanner muss zuerst ein Signal erzeugen.", ephemeral=True)
                return
            embed, view = self._build_embed(discord, latest.get("text", ""))
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

        @tree.command(name="calls", description="Zeigt die letzten fünf gespeicherten Runner-Calls.")
        @app_commands.guild_only()
        async def calls_command(interaction: discord.Interaction) -> None:
            with self.lock:
                alerts = list(reversed(self.latest_alerts[-5:]))
            if not alerts:
                await interaction.response.send_message("Noch keine CALLs gespeichert.", ephemeral=True)
                return
            embed = discord.Embed(title="📡 R1_H — Letzte Calls", color=discord.Color.blurple())
            for item in alerts:
                parsed = parse_call_text(item.get("text", ""))
                ca = parsed["ca"]
                value = f"{parsed['score']}\nCA: `{ca[:200]}`\nZeit: {item.get('timestamp', 'unbekannt')}"
                embed.add_field(name=parsed["title"][:256], value=value[:1024], inline=False)
            embed.set_footer(text="Historische Calls sind keine Aussage über künftige Rendite.")
            await interaction.response.send_message(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

        @tree.command(name="alerts", description="Schaltet automatische CALL-Benachrichtigungen für diesen Server an oder aus.")
        @app_commands.guild_only()
        async def alerts_command(interaction: discord.Interaction, enabled: bool) -> None:
            if not await require_guild(interaction):
                return
            guild_key = str(interaction.guild_id)
            with self.lock:
                if enabled:
                    self.muted_guilds.discard(guild_key)
                else:
                    self.muted_guilds.add(guild_key)
                self._save_state()
            await interaction.response.send_message(
                "🔔 Alerts aktiviert." if enabled else "🔕 Alerts pausiert. Verwende `/alerts enabled:true`, um sie wieder einzuschalten.",
                ephemeral=True,
            )

        @client.event
        async def on_ready() -> None:
            # Discord has populated guilds/channels by on_ready; pick #coin-calls
            # automatically so ongoing scanner signals are posted without a command.
            self._autodiscover_call_channels()
            if self._synced:
                logging.info("Discord verbunden als %s", client.user)
                return
            try:
                if self.guild_id.isdigit():
                    guild_obj = discord.Object(id=int(self.guild_id))
                    tree.copy_global_to(guild=guild_obj)
                    commands = await tree.sync(guild=guild_obj)
                    logging.info("Discord verbunden als %s; %d Slash-Befehle für Server %s synchronisiert.", client.user, len(commands), self.guild_id)
                else:
                    commands = await tree.sync()
                    logging.info("Discord verbunden als %s; %d globale Slash-Befehle synchronisiert. Globale Verfügbarkeit kann verzögert sein.", client.user, len(commands))
                self._synced = True
            except Exception as exc:
                logging.error("Discord-Slash-Befehle konnten nicht synchronisiert werden (%s). Lade dieselbe Anwendung mit OAuth2-Scopes bot UND applications.commands erneut ein. Automatische Nachrichten benötigen unabhängig davon Kanal ansehen, Nachrichten senden und Links einbetten.", type(exc).__name__)

        await client.start(self.token)

    def _build_embed(self, discord: Any, text: str) -> tuple[Any, Any]:
        data = parse_call_text(text)
        score_match = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*/\s*100", data["score"])
        score = float(score_match.group(1)) if score_match else 0
        color = discord.Color.green() if score >= 85 else discord.Color.gold() if score >= 76 else discord.Color.blurple()
        embed = discord.Embed(
            title=f"🚨 R1_H RUNNER CALL — {data['title']}"[:256],
            description="Frühes Research-Signal · kein garantierter Runner und keine Kaufempfehlung.",
            color=color,
            timestamp=datetime.now(timezone.utc),
        )
        embed.add_field(name="⭐ Score", value=data["score"][:1024], inline=True)
        embed.add_field(name=data["market_label"][:256], value=data["market_value"][:1024], inline=True)
        embed.add_field(name="FDV", value=data["fdv"][:1024], inline=True)
        embed.add_field(name="Preis", value=data["price"][:1024], inline=True)
        if data["liquidity"]:
            embed.add_field(name="💧 Liquidität / Volumen", value=data["liquidity"][:1024], inline=True)
        if data["transactions"]:
            embed.add_field(name="🛒 Transaktionen", value=data["transactions"][:1024], inline=True)
        if data["price_change"]:
            embed.add_field(name="📈 Kursbewegung", value=data["price_change"][:1024], inline=False)
        if data["trend"]:
            embed.add_field(name="Lokaler Trend", value=data["trend"][:1024], inline=False)
        if data["pool_age"]:
            embed.add_field(name="Pool / soziale Links", value=data["pool_age"][:1024], inline=False)
        if data["ca"]:
            embed.add_field(name="🧾 Contract Address (CA)", value=f"`{data['ca'][:180]}`", inline=False)
        if data["thesis"]:
            embed.add_field(name="🧠 KI-These", value=data["thesis"][:1024], inline=False)
        elif data["evidence"]:
            embed.add_field(name="Signalgründe", value=data["evidence"][:1024], inline=False)
        if data["ai_review"]:
            embed.add_field(name="KI-Review", value=data["ai_review"][:1024], inline=False)
        if data["risk"]:
            embed.add_field(name="🛡 Risiko / Holder / LP", value=data["risk"][:1024], inline=False)
        if data["narrative_score"]:
            embed.add_field(name="🧭 Narrative / Pre-Hype Score", value=data["narrative_score"][:1024], inline=False)
        if data["social_evidence"]:
            embed.add_field(name="🌐 Organische Aufmerksamkeit", value=data["social_evidence"][:1024], inline=False)
        if data["narrative_evidence"]:
            embed.add_field(name="🧠 Narrative-Belege", value=data["narrative_evidence"][:1024], inline=False)
        if data["narrative_warnings"]:
            embed.add_field(name="⚠️ Narrative-Warnungen", value=data["narrative_warnings"][:1024], inline=False)
        if data["narrative_gates"]:
            embed.add_field(name="⏳ Warum noch kein früher CALL?", value=data["narrative_gates"][:1024], inline=False)
        if data["ai_risks"]:
            embed.add_field(name="⚠️ KI-Warnungen", value="\n".join(f"• {item}" for item in data["ai_risks"])[:1024], inline=False)
        embed.set_footer(text="R1_H Runner Intel • öffentliche Daten, Unsicherheit bleibt • keine Gewinnzusage")

        view = discord.ui.View(timeout=None)
        for idx, url in enumerate(data["social_links"][:2]):
            view.add_item(discord.ui.Button(label=f"🌐 Social Evidence {idx+1}", style=discord.ButtonStyle.link, url=url[:500]))
        if data["chart_url"]:
            view.add_item(discord.ui.Button(label="📈 Chart ansehen", style=discord.ButtonStyle.link, url=data["chart_url"][:500]))
        if data["pump_url"]:
            view.add_item(discord.ui.Button(label="🪙 Pump.fun", style=discord.ButtonStyle.link, url=data["pump_url"][:500]))
        return embed, view

    async def _deliver_alert(self, text: str) -> None:
        import discord

        if not self.client or not self.client.is_ready():
            return
        with self.lock:
            channels = dict(self.channels)
            muted = set(self.muted_guilds)
        targets: list[tuple[str, str]] = []
        for guild_id, channel_id in channels.items():
            if guild_id not in muted:
                targets.append((guild_id, channel_id))
        if not targets:
            logging.info(
                "Discord-Call lokal gespeichert, aber noch nicht gesendet: kein Call-Kanal konfiguriert. "
                "Erstelle #coin-calls und starte den Bot neu, oder verwende optional /setchannel."
            )
            return
        embed, view = self._build_embed(discord, text)
        for guild_id, channel_id in targets:
            try:
                channel = self.client.get_channel(int(channel_id))
                if channel is None:
                    channel = await self.client.fetch_channel(int(channel_id))
                await channel.send(embed=embed, view=view, allowed_mentions=discord.AllowedMentions.none())
            except Exception as exc:
                logging.warning("Discord-Call konnte nicht an Server %s gesendet werden (%s). Prüfe Kanalrechte.", guild_id, type(exc).__name__)

    def send_alert(self, text: str) -> None:
        """Persist every emitted signal, then dispatch a structured embed to configured channels."""
        timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
        with self.lock:
            self.latest_alerts.append({"timestamp": timestamp, "text": str(text)[:12000]})
            self.latest_alerts = self.latest_alerts[-25:]
            self._save_state()
            loop = self.loop
        if loop and loop.is_running() and self.client:
            try:
                asyncio.run_coroutine_threadsafe(self._deliver_alert(str(text)), loop)
            except RuntimeError:
                logging.warning("Discord-Event-Loop ist nicht verfügbar; Call wurde lokal gespeichert.")


__all__ = ["DiscordBot", "parse_call_text"]
